/* APP_CONFIG seeded values exported from source environment. */
/* Adjust schema prefix (oci_focus_reports) if needed before running manually. */

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'ADB_COMPUTE_COUNT_DOWN' config_key, '2' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'ADB_COMPUTE_COUNT_UP' config_key, '8' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'AVAILABILITY_DAYS_BACK' config_key, '7' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'AVAILABILITY_METRICS_TABLE' config_key, 'OCI_AVAILABILITY_METRICS_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'AVAILABILITY_METRIC_GROUPS_JSON' config_key, '[
  {
    "namespace":"oci_computeagent",
    "resource_group":null,
    "metrics":["CpuUtilization","MemoryUtilization"],
    "resource_display_keys":["resourceDisplayName","instanceId"]
  }
]
' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'AVAILABILITY_QUERY_SUFFIX' config_key, '.mean()' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'AVAILABILITY_RESOLUTION' config_key, '1h' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'COMPARTMENTS_TABLE' config_key, 'OCI_COMPARTMENTS_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'CREDENTIAL_NAME' config_key, 'OCI$RESOURCE_PRINCIPAL' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'CSV_FIELD_LIST' config_key, 'AVAILABILITYZONE CHAR(4000),
BILLEDCOST DECIMAL(38,12),
BILLINGACCOUNTID INTEGER,
BILLINGACCOUNTNAME VARCHAR(32767),
BILLINGCURRENCY CHAR(4000),
BILLINGPERIODEND VARCHAR(64),
BILLINGPERIODSTART VARCHAR(64),
CHARGECATEGORY CHAR(4000),
CHARGEDESCRIPTION CHAR(4000),
CHARGEFREQUENCY VARCHAR(32767),
CHARGEPERIODEND VARCHAR(64),
CHARGEPERIODSTART VARCHAR(64),
CHARGESUBCATEGORY VARCHAR(32767),
COMMITMENTDISCOUNTCATEGORY VARCHAR(32767),
COMMITMENTDISCOUNTID VARCHAR(32767),
COMMITMENTDISCOUNTNAME VARCHAR(32767),
COMMITMENTDISCOUNTTYPE VARCHAR(32767),
EFFECTIVECOST DECIMAL(38,12),
INVOICEISSUER CHAR(4000),
LISTCOST DECIMAL(38,12),
LISTUNITPRICE DECIMAL(38,12),
PRICINGCATEGORY VARCHAR(32767),
PRICINGQUANTITY DECIMAL(38,12),
PRICINGUNIT CHAR(4000),
PROVIDER CHAR(4000),
PUBLISHER CHAR(4000),
REGION CHAR(4000),
RESOURCEID CHAR(4000),
RESOURCENAME VARCHAR(32767),
RESOURCETYPE CHAR(4000),
SERVICECATEGORY CHAR(4000),
SERVICENAME CHAR(4000),
SKUID CHAR(4000),
SKUPRICEID VARCHAR(32767),
SUBACCOUNTID CHAR(4000),
SUBACCOUNTNAME CHAR(4000),
TAGS VARCHAR(32767),
USAGEQUANTITY DECIMAL(38,12),
USAGEUNIT CHAR(4000),
OCI_REFERENCENUMBER CHAR(4000),
OCI_COMPARTMENTID CHAR(4000),
OCI_COMPARTMENTNAME CHAR(4000),
OCI_OVERAGEFLAG CHAR(4000),
OCI_UNITPRICEOVERAGE VARCHAR(32767),
OCI_BILLEDQUANTITYOVERAGE VARCHAR(32767),
OCI_COSTOVERAGE VARCHAR(32767),
OCI_ATTRIBUTEDUSAGE DECIMAL(38,12),
OCI_ATTRIBUTEDCOST DECIMAL(38,12),
OCI_BACKREFERENCENUMBER CHAR(4000)' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'DAYS_BACK' config_key, '1' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'EXA_MAINTENANCE_METRICS_TABLE' config_key, 'OCI_EXA_MAINTENANCE_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'FILE_SUFFIX' config_key, '.csv.gz' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'FILTER_BY_CREATED_SINCE' config_key, 'Y' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'KEY_COLUMN' config_key, 'OCI_REFERENCENUMBER' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'POST_PROCS' config_key, '[
  "PAGE1_CONS_WRKLD_MONTH_CHART_DATA_PROC",
  "PAGE1_CONS_WRKLD_WEEK_CHART_DATA_PROC",
  "COST_USAGE_TS_PKG.REFRESH_COST_USAGE_TS",
  "REFRESH_CREDIT_USAGE_AGG_PROC",
  "REFRESH_CREDIT_CONSUMPTION_STATE_PROC",
  "DBMS_MVIEW.REFRESH(''FILTER_VALUES_MV'', METHOD => ''C'')"]' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'POST_SUBS_PROC_1' config_key, 'UPDATE_OCI_SUBSCRIPTION_DETAILS' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'POST_SUBS_PROC_2' config_key, 'REFRESH_CREDIT_CONSUMPTION_STATE_PROC' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'PREFIX_BASE' config_key, 'FOCUS Reports' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'PREFIX_FILE' config_key, CAST(NULL AS VARCHAR2(32767)) config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'RESOURCES_TABLE' config_key, 'OCI_RESOURCES_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'RESOURCE_OKE_RELATIONSHIPS_PROC' config_key, 'POPULATE_OKE_RELATIONSHIPS_PROC' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'RESOURCE_RELATIONSHIPS_PROC' config_key, 'POPULATE_RESOURCE_RELATIONSHIPS_PROC' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'STAGE_TABLE' config_key, 'FOCUS_REPORTS_STAGE' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'SUBSCRIPTIONS_TARGET_TABLE' config_key, 'OCI_SUBSCRIPTIONS_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'SUBSCRIPTION_COMMIT_TARGET_TABLE' config_key, 'OCI_SUBSCRIPTION_COMMITMENTS' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'TARGET_TABLE' config_key, 'FOCUS_REPORTS_PY' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

MERGE INTO oci_focus_reports.app_config c
USING (SELECT 'USE_DYNAMIC_PREFIX' config_key, 'Y' config_value FROM dual) s
ON (c.config_key = s.config_key)
WHEN MATCHED THEN UPDATE SET c.config_value = s.config_value, c.updated_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
VALUES (s.config_key, s.config_value, SYSDATE);

