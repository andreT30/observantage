
  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_NL2SQL_LOG_AU_FINISH_COST" 
AFTER UPDATE OF finished_at, status ON chatbot_nl2sql_log
FOR EACH ROW
DECLARE
  v_is_terminal BOOLEAN := (
    :NEW.finished_at IS NOT NULL
    OR UPPER(:NEW.status) IN ('SUCCEEDED','FAILED')
  );
  v_was_terminal BOOLEAN := (
    :OLD.finished_at IS NOT NULL
    OR UPPER(:OLD.status) IN ('SUCCEEDED','FAILED')
  );
BEGIN
  IF v_is_terminal AND NOT v_was_terminal THEN
    MERGE INTO chatbot_cost_archive c
    USING (
      SELECT :NEW.id                  AS log_id,
             :NEW.chat_id             AS chat_id,
             :NEW.app_user            AS app_user,
             :NEW.started_at          AS started_at,
             :NEW.model_id            AS model_id,
             :NEW.input_chars_total   AS in_chr,
             :NEW.output_chars_total  AS out_chr,
             :NEW.input_tokens_total  AS in_tok,
             :NEW.output_tokens_total AS out_tok
      FROM dual
    ) s
    ON (c.log_id = s.log_id)
    WHEN MATCHED THEN
      UPDATE SET
        c.chat_id             = s.chat_id,
        c.app_user            = s.app_user,
        c.started_at          = s.started_at,
        c.model_id            = s.model_id,
        c.input_chars_total   = s.in_chr,
        c.output_chars_total  = s.out_chr,
        c.input_tokens_total  = s.in_tok,
        c.output_tokens_total = s.out_tok,
        c.snapshot_reason     = 'FINISH',
        c.snapshot_at         = SYSTIMESTAMP
    WHEN NOT MATCHED THEN
      INSERT (
        log_id,
        chat_id,
        app_user,
        started_at,
        model_id,
        input_chars_total,
        output_chars_total,
        input_tokens_total,
        output_tokens_total,
        snapshot_reason,
        snapshot_at
      )
      VALUES (
        s.log_id,
        s.chat_id,
        s.app_user,
        s.started_at,
        s.model_id,
        s.in_chr,
        s.out_chr,
        s.in_tok,
        s.out_tok,
        'FINISH',
        SYSTIMESTAMP
      );
  END IF;
END;
/
ALTER TRIGGER "TRG_NL2SQL_LOG_AU_FINISH_COST" ENABLE;

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_NL2SQL_LOG_BD_COST" 
BEFORE DELETE ON chatbot_nl2sql_log
FOR EACH ROW
BEGIN
  MERGE INTO chatbot_cost_archive c
  USING (
    SELECT :OLD.id                  AS log_id,
           :OLD.chat_id             AS chat_id,
           :OLD.app_user            AS app_user,
           :OLD.started_at          AS started_at,
           :OLD.model_id            AS model_id,
           :OLD.input_chars_total   AS in_chr,
           :OLD.output_chars_total  AS out_chr,
           :OLD.input_tokens_total  AS in_tok,
           :OLD.output_tokens_total AS out_tok
    FROM dual
  ) s
  ON (c.log_id = s.log_id)
  WHEN MATCHED THEN
    UPDATE SET
      c.chat_id             = s.chat_id,
      c.app_user            = s.app_user,
      c.started_at          = s.started_at,
      c.model_id            = s.model_id,
      c.input_chars_total   = s.in_chr,
      c.output_chars_total  = s.out_chr,
      c.input_tokens_total  = s.in_tok,
      c.output_tokens_total = s.out_tok,
      c.snapshot_reason     = 'DELETE',
      c.snapshot_at         = SYSTIMESTAMP
  WHEN NOT MATCHED THEN
    INSERT (
      log_id,
      chat_id,
      app_user,
      started_at,
      model_id,
      input_chars_total,
      output_chars_total,
      input_tokens_total,
      output_tokens_total,
      snapshot_reason,
      snapshot_at
    )
    VALUES (
      s.log_id,
      s.chat_id,
      s.app_user,
      s.started_at,
      s.model_id,
      s.in_chr,
      s.out_chr,
      s.in_tok,
      s.out_tok,
      'DELETE',
      SYSTIMESTAMP
    );
END;
/
ALTER TRIGGER "TRG_NL2SQL_LOG_BD_COST" ENABLE;
