DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'MODEL_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (MODEL_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'MODEL_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (MODEL_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'API_FORMAT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (API_FORMAT VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'IS_DEFAULT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (IS_DEFAULT VARCHAR2(1))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (REGION VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'TEMPERATURE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (TEMPERATURE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'TOP_P'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (TOP_P NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'TOP_K'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (TOP_K NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'FREQUENCY_PENALTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (FREQUENCY_PENALTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'AI_MODEL_CONFIG'
     AND column_name = 'PRESENCE_PENALTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE AI_MODEL_CONFIG ADD (PRESENCE_PENALTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'APP_CONFIG'
     AND column_name = 'CONFIG_KEY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE APP_CONFIG ADD (CONFIG_KEY VARCHAR2(100) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'APP_CONFIG'
     AND column_name = 'CONFIG_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE APP_CONFIG ADD (CONFIG_VALUE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'APP_CONFIG'
     AND column_name = 'UPDATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE APP_CONFIG ADD (UPDATED_AT DATE DEFAULT SYSDATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'LOG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (LOG_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (CHAT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'MODEL_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (MODEL_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'INPUT_TOKENS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (INPUT_TOKENS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'OUTPUT_TOKENS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (OUTPUT_TOKENS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'SNAPSHOT_REASON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (SNAPSHOT_REASON VARCHAR2(12))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'SNAPSHOT_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (SNAPSHOT_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'APP_USER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (APP_USER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'STARTED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (STARTED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'INPUT_CHARS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (INPUT_CHARS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_COST_ARCHIVE'
     AND column_name = 'OUTPUT_CHARS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_COST_ARCHIVE ADD (OUTPUT_CHARS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_KEYWORDS'
     AND column_name = 'RULE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_KEYWORDS ADD (RULE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_KEYWORDS'
     AND column_name = 'ORD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_KEYWORDS ADD (ORD NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_KEYWORDS'
     AND column_name = 'KEYWORD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_KEYWORDS ADD (KEYWORD VARCHAR2(400) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'DATASET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (DATASET VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (ENVIRONMENT VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'ACTIVE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (ACTIVE VARCHAR2(5) DEFAULT 'TRUE')~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'MATCH_MODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (MATCH_MODE VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'ROLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (ROLE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'PRIORITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (PRIORITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (DESCRIPTION VARCHAR2(2000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'TARGET_TABLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (TARGET_TABLE VARCHAR2(261))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'TARGET_COLUMN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (TARGET_COLUMN VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'TARGET_ROLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (TARGET_ROLE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'TARGET_FILTER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (TARGET_FILTER CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'FILTER_RULE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (FILTER_RULE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (CREATED_BY VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'UPDATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (UPDATED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_GLOSSARY_RULES'
     AND column_name = 'UPDATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_GLOSSARY_RULES ADD (UPDATED_BY VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'REQ_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (REQ_ID VARCHAR2(32))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'LOG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (LOG_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (CHAT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'LEVEL_TXT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (LEVEL_TXT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (MESSAGE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'PAYLOAD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (PAYLOAD CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_JOB_DEBUG'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_JOB_DEBUG ADD (CREATED_AT TIMESTAMP(6) WITH TIME ZONE DEFAULT systimestamp)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (CHAT_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'APP_USER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (APP_USER VARCHAR2(255) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'FRIENDLY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (FRIENDLY_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'LAST_ACTIVITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (LAST_ACTIVITY TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_CONVERSATION'
     AND column_name = 'ARCHIVED_YN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_CONVERSATION ADD (ARCHIVED_YN VARCHAR2(1) DEFAULT 'N')~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (CHAT_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'SESSION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (SESSION_ID VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'APP_USER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (APP_USER VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'INSTRUCTION_IDS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (INSTRUCTION_IDS VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'EXAMPLE_IDS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (EXAMPLE_IDS VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'USER_PROMPT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (USER_PROMPT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'GENERATED_SQL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (GENERATED_SQL CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'EXECUTION_DATA'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (EXECUTION_DATA CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'RAW_RESPONSE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (RAW_RESPONSE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'SUMMARY_TEXT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (SUMMARY_TEXT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'REASONING_IDS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (REASONING_IDS VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'REASONED_MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (REASONED_MESSAGE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'REASONING_OUTPUT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (REASONING_OUTPUT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'ATTEMPT_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (ATTEMPT_NUMBER NUMBER DEFAULT 1)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'REASONING_COLUMN_USED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (REASONING_COLUMN_USED VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'ASSISTANT_TEXT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (ASSISTANT_TEXT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'CODE_LANGUAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (CODE_LANGUAGE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'CODE_BLOCK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (CODE_BLOCK CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (STATUS VARCHAR2(20) DEFAULT 'QUEUED' NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'JOB_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (JOB_NAME VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'STARTED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (STARTED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'FINISHED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (FINISHED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'ERROR_MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (ERROR_MESSAGE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'MODEL_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (MODEL_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (COMPARTMENT_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'USE_HISTORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (USE_HISTORY VARCHAR2(1))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'INPUT_CHARS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (INPUT_CHARS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'OUTPUT_CHARS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (OUTPUT_CHARS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'INPUT_TOKENS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (INPUT_TOKENS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'OUTPUT_TOKENS_TOTAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (OUTPUT_TOKENS_TOTAL NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'COST_TOTAL_USD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (COST_TOTAL_USD NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'METRICS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (METRICS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'INTENT_SCORE10'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (INTENT_SCORE10 NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'INTENT_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (INTENT_LABEL VARCHAR2(40))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'EXEC_MODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (EXEC_MODE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'PARENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (PARENT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'SUMMARY_PREVIEW_JSON_TOKEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (SUMMARY_PREVIEW_JSON_TOKEN CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'SUMMARY_TEXT_RAW'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (SUMMARY_TEXT_RAW CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_LOG'
     AND column_name = 'CHART_SPEC_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_LOG ADD (CHART_SPEC_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (CHAT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'LOG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (LOG_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'INPUT_MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (INPUT_MESSAGE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'REASONING_OUTPUT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (REASONING_OUTPUT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'ATTEMPT_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (ATTEMPT_NUMBER NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'APP_USER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (APP_USER VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REASONING_LOG'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REASONING_LOG ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'LOG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (LOG_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'TOKEN_MAP_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (TOKEN_MAP_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'CHAT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (CHAT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'MAP_VERSION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (MAP_VERSION NUMBER DEFAULT 1)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'DATASET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (DATASET VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (ENVIRONMENT VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'REDACTED_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (REDACTED_VALUE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_REDACTION'
     AND column_name = 'ORIGINAL_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_REDACTION ADD (ORIGINAL_VALUE CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'DATASET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (DATASET VARCHAR2(100) DEFAULT '#')~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (ENVIRONMENT VARCHAR2(20) DEFAULT '#')~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'TABLE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (TABLE_NAME VARCHAR2(128) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'LAST_REFRESHED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (LAST_REFRESHED TIMESTAMP(6) DEFAULT systimestamp)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'SUMMARY_TEXT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (SUMMARY_TEXT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_NL2SQL_SUMMARY'
     AND column_name = 'PARAM_SET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_NL2SQL_SUMMARY ADD (PARAM_SET_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'COMPONENT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (COMPONENT_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'CONTENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (CONTENT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'ACTIVE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (ACTIVE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'DATASET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (DATASET VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (CREATED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (ENVIRONMENT VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETERS'
     AND column_name = 'PARAM_SET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETERS ADD (PARAM_SET_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETER_COMPONENT'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETER_COMPONENT ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CHATBOT_PARAMETER_COMPONENT'
     AND column_name = 'COMPONENT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CHATBOT_PARAMETER_COMPONENT ADD (COMPONENT_TYPE VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'DATE_BUCKET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (DATE_BUCKET DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (BILLINGACCOUNTID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (SUBACCOUNTNAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (INVOICEISSUER VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (REGION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (BILLINGCURRENCY VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (SERVICECATEGORY VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (SERVICENAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (CHARGEDESCRIPTION VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (RESOURCETYPE VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (RESOURCEID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (RESOURCENAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (SKUID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (PRICINGUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (OCI_COMPARTMENTID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (OCI_COMPARTMENTNAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'OCI_COMPARTMENT_PATH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (OCI_COMPARTMENT_PATH VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (USAGEUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (COST NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'USAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (USAGE NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'LAST_REFRESH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (LAST_REFRESH DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (CREATED_BY VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'IMPLEMENTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (IMPLEMENTOR VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'COSTCENTER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (COSTCENTER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_DAILY'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_DAILY ADD (ENVIRONMENT VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'DATE_BUCKET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (DATE_BUCKET DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (BILLINGACCOUNTID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (SUBACCOUNTNAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (INVOICEISSUER VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (REGION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (BILLINGCURRENCY VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (SERVICECATEGORY VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (SERVICENAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (CHARGEDESCRIPTION VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (RESOURCETYPE VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (RESOURCEID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (RESOURCENAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (SKUID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (PRICINGUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (OCI_COMPARTMENTID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (OCI_COMPARTMENTNAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'OCI_COMPARTMENT_PATH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (OCI_COMPARTMENT_PATH VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (USAGEUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (COST NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'USAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (USAGE NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'LAST_REFRESH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (LAST_REFRESH DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (CREATED_BY VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'IMPLEMENTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (IMPLEMENTOR VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'COSTCENTER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (COSTCENTER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_MONTHLY'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_MONTHLY ADD (ENVIRONMENT VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'DATE_BUCKET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (DATE_BUCKET DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (BILLINGACCOUNTID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (SUBACCOUNTNAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (INVOICEISSUER VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (REGION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (BILLINGCURRENCY VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (SERVICECATEGORY VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (SERVICENAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (CHARGEDESCRIPTION VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (RESOURCETYPE VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (RESOURCEID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (RESOURCENAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (SKUID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (PRICINGUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (OCI_COMPARTMENTID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (OCI_COMPARTMENTNAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'OCI_COMPARTMENT_PATH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (OCI_COMPARTMENT_PATH VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (USAGEUNIT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (COST NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'USAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (USAGE NUMBER(20,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'LAST_REFRESH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (LAST_REFRESH DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (CREATED_BY VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'IMPLEMENTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (IMPLEMENTOR VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'COSTCENTER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (COSTCENTER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'COST_USAGE_TIMESERIES_WEEKLY'
     AND column_name = 'ENVIRONMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE COST_USAGE_TIMESERIES_WEEKLY ADD (ENVIRONMENT VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'SUBSCRIPTION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (SUBSCRIPTION_ID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (BILLINGACCOUNTID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'ORDER_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (ORDER_NUMBER VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'TIME_START'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (TIME_START DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'TIME_END'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (TIME_END DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'ORIGINAL_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (ORIGINAL_QUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'REMAINING_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (REMAINING_QUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'DEPLETED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (DEPLETED BOOLEAN)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'LAST_CONSUMED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (LAST_CONSUMED_AT DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'ISO_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (ISO_CODE VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'LAST_UPDATED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (LAST_UPDATED DATE DEFAULT SYSDATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_CONSUMPTION_STATE'
     AND column_name = 'SUBSCRIPTION_LINE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_CONSUMPTION_STATE ADD (SUBSCRIPTION_LINE_ID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_USAGE_AGG'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_USAGE_AGG ADD (BILLINGACCOUNTID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_USAGE_AGG'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_USAGE_AGG ADD (CHARGEPERIODEND DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_USAGE_AGG'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_USAGE_AGG ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_USAGE_AGG'
     AND column_name = 'HOURLY_COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_USAGE_AGG ADD (HOURLY_COST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'CREDIT_USAGE_AGG'
     AND column_name = 'INSERTED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE CREDIT_USAGE_AGG ADD (INSERTED_AT DATE DEFAULT SYSDATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'HASH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (HASH CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (CREATED_BY VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'CREATED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (CREATED_ON TIMESTAMP(6) WITH TIME ZONE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'UPDATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (UPDATED_BY VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'UPDATED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (UPDATED_ON TIMESTAMP(6) WITH TIME ZONE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'STATEMENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (STATEMENT CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DBTOOLS$EXECUTION_HISTORY'
     AND column_name = 'TIMES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DBTOOLS$EXECUTION_HISTORY ADD (TIMES NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'APPLIED_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (APPLIED_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'BUNDLE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (BUNDLE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'APPLIED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (APPLIED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'APPLIED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (APPLIED_BY VARCHAR2(128) DEFAULT USER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'RESULT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (RESULT VARCHAR2(20) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_APPLIED'
     AND column_name = 'DETAILS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_APPLIED ADD (DETAILS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'BUNDLE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (BUNDLE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'APP_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (APP_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'VERSION_TAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (VERSION_TAG VARCHAR2(64) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (CREATED_BY VARCHAR2(128) DEFAULT USER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'MANIFEST_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (MANIFEST_JSON CLOB NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'BUNDLE_ZIP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (BUNDLE_ZIP BLOB NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_BUNDLES'
     AND column_name = 'SHA256'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_BUNDLES ADD (SHA256 VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_MIGRATION_SCRIPTS'
     AND column_name = 'MIGRATION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_MIGRATION_SCRIPTS ADD (MIGRATION_ID VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_MIGRATION_SCRIPTS'
     AND column_name = 'SCRIPT_CLOB'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_MIGRATION_SCRIPTS ADD (SCRIPT_CLOB CLOB NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_MIGRATION_SCRIPTS'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_MIGRATION_SCRIPTS ADD (CREATED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_MIGRATION_SCRIPTS'
     AND column_name = 'CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_MIGRATION_SCRIPTS ADD (CREATED_BY VARCHAR2(128) DEFAULT USER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_MIGRATION_SCRIPTS'
     AND column_name = 'ACTIVE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_MIGRATION_SCRIPTS ADD (ACTIVE CHAR(1) DEFAULT 'Y')~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'RUN_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (RUN_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'BUNDLE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (BUNDLE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'ACTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (ACTION VARCHAR2(30) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (STATUS VARCHAR2(20) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'STARTED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (STARTED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'ENDED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (ENDED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'ERROR_STACK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (ERROR_STACK CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_RUNS'
     AND column_name = 'LOG_CLOB'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_RUNS ADD (LOG_CLOB CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
     AND column_name = 'MIGRATION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_SCHEMA_MIGRATIONS ADD (MIGRATION_ID VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
     AND column_name = 'APPLIED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_SCHEMA_MIGRATIONS ADD (APPLIED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
     AND column_name = 'APPLIED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_SCHEMA_MIGRATIONS ADD (APPLIED_BY VARCHAR2(128) DEFAULT USER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
     AND column_name = 'BUNDLE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_SCHEMA_MIGRATIONS ADD (BUNDLE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
     AND column_name = 'NOTES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE DEPLOY_SCHEMA_MIGRATIONS ADD (NOTES VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (SUBACCOUNTNAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (BILLINGACCOUNTID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (REGION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (OCI_COMPARTMENTID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (SERVICECATEGORY VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (SERVICENAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (CHARGEDESCRIPTION VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (RESOURCETYPE VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (RESOURCEID VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (RESOURCENAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FILTER_VALUES_MV'
     AND column_name = 'COSTCENTER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FILTER_VALUES_MV ADD (COSTCENTER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'FILENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (FILENAME VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'LOAD_DATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (LOAD_DATE TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'TOTAL_ROWS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (TOTAL_ROWS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'INSERTED_ROWS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (INSERTED_ROWS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'FAILED_ROWS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (FAILED_ROWS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (STATUS VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_LOAD_LOG'
     AND column_name = 'ERROR_MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_LOAD_LOG ADD (ERROR_MESSAGE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'AVAILABILITYZONE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (AVAILABILITYZONE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLINGACCOUNTID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLINGACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLINGACCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLINGCURRENCY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLINGPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLINGPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'BILLINGPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (BILLINGPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGEFREQUENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGEFREQUENCY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGEPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGEPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGEPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'CHARGESUBCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (CHARGESUBCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'COMMITMENTDISCOUNTCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (COMMITMENTDISCOUNTCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'COMMITMENTDISCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (COMMITMENTDISCOUNTID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'COMMITMENTDISCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (COMMITMENTDISCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'COMMITMENTDISCOUNTTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (COMMITMENTDISCOUNTTYPE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'EFFECTIVECOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (EFFECTIVECOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (INVOICEISSUER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'LISTCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (LISTCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'PRICINGCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (PRICINGCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'PRICINGQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (PRICINGQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'PROVIDER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (PROVIDER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'PUBLISHER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (PUBLISHER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (REGION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (RESOURCEID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (RESOURCENAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (RESOURCETYPE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SERVICECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SERVICENAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SKUPRICEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SKUPRICEID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SUBACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SUBACCOUNTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (SUBACCOUNTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'USAGEQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (USAGEQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (USAGEUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_REFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_REFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_COMPARTMENTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_COMPARTMENTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_OVERAGEFLAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_OVERAGEFLAG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_UNITPRICEOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_UNITPRICEOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_BILLEDQUANTITYOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_BILLEDQUANTITYOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_COSTOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_COSTOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_ATTRIBUTEDUSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_ATTRIBUTEDUSAGE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_ATTRIBUTEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_ATTRIBUTEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY'
     AND column_name = 'OCI_BACKREFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY ADD (OCI_BACKREFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'AVAILABILITYZONE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (AVAILABILITYZONE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLINGACCOUNTID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLINGACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLINGACCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLINGCURRENCY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLINGPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLINGPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'BILLINGPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (BILLINGPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGEFREQUENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGEFREQUENCY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGEPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGEPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGEPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'CHARGESUBCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (CHARGESUBCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'COMMITMENTDISCOUNTCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (COMMITMENTDISCOUNTCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'COMMITMENTDISCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (COMMITMENTDISCOUNTID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'COMMITMENTDISCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (COMMITMENTDISCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'COMMITMENTDISCOUNTTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (COMMITMENTDISCOUNTTYPE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'EFFECTIVECOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (EFFECTIVECOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (INVOICEISSUER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'LISTCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (LISTCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'PRICINGCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (PRICINGCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'PRICINGQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (PRICINGQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'PROVIDER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (PROVIDER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'PUBLISHER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (PUBLISHER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (REGION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (RESOURCEID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (RESOURCENAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (RESOURCETYPE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SERVICECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SERVICENAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SKUPRICEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SKUPRICEID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SUBACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SUBACCOUNTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (SUBACCOUNTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'USAGEQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (USAGEQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (USAGEUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_REFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_REFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_COMPARTMENTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_COMPARTMENTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_OVERAGEFLAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_OVERAGEFLAG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_UNITPRICEOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_UNITPRICEOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_BILLEDQUANTITYOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_BILLEDQUANTITYOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_COSTOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_COSTOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_ATTRIBUTEDUSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_ATTRIBUTEDUSAGE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_ATTRIBUTEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_ATTRIBUTEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_ARCHIVE'
     AND column_name = 'OCI_BACKREFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_ARCHIVE ADD (OCI_BACKREFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'AVAILABILITYZONE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (AVAILABILITYZONE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLINGACCOUNTID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLINGACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLINGACCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLINGCURRENCY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLINGPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLINGPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'BILLINGPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (BILLINGPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGEFREQUENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGEFREQUENCY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGEPERIODEND TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGEPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGEPERIODSTART TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'CHARGESUBCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (CHARGESUBCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'COMMITMENTDISCOUNTCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (COMMITMENTDISCOUNTCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'COMMITMENTDISCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (COMMITMENTDISCOUNTID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'COMMITMENTDISCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (COMMITMENTDISCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'COMMITMENTDISCOUNTTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (COMMITMENTDISCOUNTTYPE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'EFFECTIVECOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (EFFECTIVECOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (INVOICEISSUER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'LISTCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (LISTCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'PRICINGCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (PRICINGCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'PRICINGQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (PRICINGQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'PROVIDER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (PROVIDER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'PUBLISHER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (PUBLISHER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (REGION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (RESOURCEID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (RESOURCENAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (RESOURCETYPE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SERVICECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SERVICENAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SKUPRICEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SKUPRICEID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SUBACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SUBACCOUNTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (SUBACCOUNTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'USAGEQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (USAGEQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (USAGEUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_REFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_REFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_COMPARTMENTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_COMPARTMENTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_OVERAGEFLAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_OVERAGEFLAG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_UNITPRICEOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_UNITPRICEOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_BILLEDQUANTITYOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_BILLEDQUANTITYOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_COSTOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_COSTOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_ATTRIBUTEDUSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_ATTRIBUTEDUSAGE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_ATTRIBUTEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_ATTRIBUTEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_PY_TEST'
     AND column_name = 'OCI_BACKREFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_PY_TEST ADD (OCI_BACKREFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'AVAILABILITYZONE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (AVAILABILITYZONE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLINGACCOUNTID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLINGACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLINGACCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLINGCURRENCY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLINGPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLINGPERIODEND VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'BILLINGPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (BILLINGPERIODSTART VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGEFREQUENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGEFREQUENCY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGEPERIODEND VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGEPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGEPERIODSTART VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'CHARGESUBCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (CHARGESUBCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'COMMITMENTDISCOUNTCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (COMMITMENTDISCOUNTCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'COMMITMENTDISCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (COMMITMENTDISCOUNTID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'COMMITMENTDISCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (COMMITMENTDISCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'COMMITMENTDISCOUNTTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (COMMITMENTDISCOUNTTYPE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'EFFECTIVECOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (EFFECTIVECOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (INVOICEISSUER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'LISTCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (LISTCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'PRICINGCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (PRICINGCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'PRICINGQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (PRICINGQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'PROVIDER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (PROVIDER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'PUBLISHER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (PUBLISHER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (REGION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (RESOURCEID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (RESOURCENAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (RESOURCETYPE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SERVICECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SERVICENAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SKUPRICEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SKUPRICEID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SUBACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SUBACCOUNTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (SUBACCOUNTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'USAGEQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (USAGEQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (USAGEUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_REFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_REFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_COMPARTMENTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_COMPARTMENTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_OVERAGEFLAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_OVERAGEFLAG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_UNITPRICEOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_UNITPRICEOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_BILLEDQUANTITYOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_BILLEDQUANTITYOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_COSTOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_COSTOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_ATTRIBUTEDUSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_ATTRIBUTEDUSAGE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_ATTRIBUTEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_ATTRIBUTEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE'
     AND column_name = 'OCI_BACKREFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE ADD (OCI_BACKREFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'AVAILABILITYZONE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (AVAILABILITYZONE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLINGACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLINGACCOUNTID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLINGACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLINGACCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLINGCURRENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLINGCURRENCY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLINGPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLINGPERIODEND VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'BILLINGPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (BILLINGPERIODSTART VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGEFREQUENCY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGEFREQUENCY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGEPERIODEND'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGEPERIODEND VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGEPERIODSTART'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGEPERIODSTART VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'CHARGESUBCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (CHARGESUBCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'COMMITMENTDISCOUNTCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (COMMITMENTDISCOUNTCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'COMMITMENTDISCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (COMMITMENTDISCOUNTID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'COMMITMENTDISCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (COMMITMENTDISCOUNTNAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'COMMITMENTDISCOUNTTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (COMMITMENTDISCOUNTTYPE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'EFFECTIVECOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (EFFECTIVECOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'INVOICEISSUER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (INVOICEISSUER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'LISTCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (LISTCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'PRICINGCATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (PRICINGCATEGORY VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'PRICINGQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (PRICINGQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'PROVIDER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (PROVIDER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'PUBLISHER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (PUBLISHER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (REGION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'RESOURCEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (RESOURCEID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'RESOURCENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (RESOURCENAME VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'RESOURCETYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (RESOURCETYPE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SERVICECATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SERVICECATEGORY VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SERVICENAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SERVICENAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SKUPRICEID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SKUPRICEID VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SUBACCOUNTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SUBACCOUNTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'SUBACCOUNTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (SUBACCOUNTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'USAGEQUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (USAGEQUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'USAGEUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (USAGEUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_REFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_REFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_COMPARTMENTID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_COMPARTMENTID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_COMPARTMENTNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_COMPARTMENTNAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_OVERAGEFLAG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_OVERAGEFLAG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_UNITPRICEOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_UNITPRICEOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_BILLEDQUANTITYOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_BILLEDQUANTITYOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_COSTOVERAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_COSTOVERAGE VARCHAR2(32767))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_ATTRIBUTEDUSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_ATTRIBUTEDUSAGE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_ATTRIBUTEDCOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_ATTRIBUTEDCOST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FOCUS_REPORTS_STAGE_TEST'
     AND column_name = 'OCI_BACKREFERENCENUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FOCUS_REPORTS_STAGE_TEST ADD (OCI_BACKREFERENCENUMBER VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FR_AUTHZ_GROUPS'
     AND column_name = 'GROUP_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FR_AUTHZ_GROUPS ADD (GROUP_CODE VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FR_AUTHZ_GROUPS'
     AND column_name = 'APEX_GROUP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FR_AUTHZ_GROUPS ADD (APEX_GROUP VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FR_AUTHZ_GROUPS'
     AND column_name = 'SSO_GROUP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FR_AUTHZ_GROUPS ADD (SSO_GROUP VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'FR_AUTHZ_GROUPS'
     AND column_name = 'WORKLOAD_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE FR_AUTHZ_GROUPS ADD (WORKLOAD_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'GENAI_MODEL_PRICE_MAP'
     AND column_name = 'MODEL_KEY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE GENAI_MODEL_PRICE_MAP ADD (MODEL_KEY VARCHAR2(1000) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'GENAI_MODEL_PRICE_MAP'
     AND column_name = 'PRICING_MODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE GENAI_MODEL_PRICE_MAP ADD (PRICING_MODE VARCHAR2(20) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'GENAI_MODEL_PRICE_MAP'
     AND column_name = 'INPUT_PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE GENAI_MODEL_PRICE_MAP ADD (INPUT_PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'GENAI_MODEL_PRICE_MAP'
     AND column_name = 'OUTPUT_PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE GENAI_MODEL_PRICE_MAP ADD (OUTPUT_PART_NUMBER VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'RESOURCEDISPLAYNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (RESOURCEDISPLAYNAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'TIMESTAMP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (TIMESTAMP TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'NAMESPACE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (NAMESPACE VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (COMPARTMENT_ID VARCHAR2(256))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (VALUE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY'
     AND column_name = 'METRIC_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY ADD (METRIC_NAME VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'RESOURCEDISPLAYNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (RESOURCEDISPLAYNAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'TIMESTAMP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (TIMESTAMP TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'NAMESPACE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (NAMESPACE VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (COMPARTMENT_ID VARCHAR2(256))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (VALUE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE'
     AND column_name = 'METRIC_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_PY_ARCHIVE ADD (METRIC_NAME VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'RESOURCEDISPLAYNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (RESOURCEDISPLAYNAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'TIMESTAMP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (TIMESTAMP TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'NAMESPACE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (NAMESPACE VARCHAR2(64))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (COMPARTMENT_ID VARCHAR2(256))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (VALUE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_AVAILABILITY_METRICS_STG'
     AND column_name = 'METRIC_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_AVAILABILITY_METRICS_STG ADD (METRIC_NAME VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (COMPARTMENT_ID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (NAME VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (DESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'LIFECYCLE_STATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (LIFECYCLE_STATE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'TIME_CREATED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (TIME_CREATED VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'PARENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (PARENT_ID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'PARENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (PARENT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'PATH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (PATH VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_COMPARTMENTS_PY'
     AND column_name = 'TENANCY_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_COMPARTMENTS_PY ADD (TENANCY_ID VARCHAR2(2000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_CURRENCY_CATALOG'
     AND column_name = 'CURRENCY_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_CURRENCY_CATALOG ADD (CURRENCY_CODE VARCHAR2(10) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_CURRENCY_CATALOG'
     AND column_name = 'CURRENCY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_CURRENCY_CATALOG ADD (CURRENCY_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_CURRENCY_CATALOG'
     AND column_name = 'EXCHANGE_RATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_CURRENCY_CATALOG ADD (EXCHANGE_RATE NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_CURRENCY_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_CURRENCY_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'TEMPLATE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (TEMPLATE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'CODE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (CODE_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (DESCRIPTION VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'TEMPLATE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (TEMPLATE_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (HIDDEN NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'TAGS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (TAGS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'CATEGORIES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (CATEGORIES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'DOCUMENT_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (DOCUMENT_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_ESTIMATE_TEMPLATE'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_ESTIMATE_TEMPLATE ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_CONFIG'
     AND column_name = 'EST_CONFIG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_CONFIG ADD (EST_CONFIG_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_CONFIG'
     AND column_name = 'EST_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_CONFIG ADD (EST_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_CONFIG'
     AND column_name = 'CONFIG_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_CONFIG ADD (CONFIG_LABEL VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_CONFIG'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_CONFIG ADD (PRESET_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_CONFIG'
     AND column_name = 'ADD_BY_SEARCH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_CONFIG ADD (ADD_BY_SEARCH NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'EST_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (EST_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'EST_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (EST_NAME VARCHAR2(300) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'OWNER_USERNAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (OWNER_USERNAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'CURRENCY_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (CURRENCY_CODE VARCHAR2(10) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'TIMEFRAME_MONTHS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (TIMEFRAME_MONTHS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'START_DATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (START_DATE DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'END_DATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (END_DATE DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'SOURCE_TEMPLATE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (SOURCE_TEMPLATE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (STATUS VARCHAR2(30) DEFAULT 'DRAFT' NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'CREATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (CREATED_AT TIMESTAMP(6) DEFAULT systimestamp NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_HEADER'
     AND column_name = 'UPDATED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_HEADER ADD (UPDATED_AT TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'EST_ITEM_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (EST_ITEM_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'EST_SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (EST_SERVICE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (QUANTITY NUMBER(18,6) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'MIN_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (MIN_QUANTITY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'IN_PRESET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (IN_PRESET NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'UNIT_PRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (UNIT_PRICE NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_ITEM'
     AND column_name = 'MONTHLY_COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_ITEM ADD (MONTHLY_COST NUMBER(18,2))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'EST_SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (EST_SERVICE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'EST_CONFIG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (EST_CONFIG_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (SERVICE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (PRESET_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (LABEL VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'INSTANCES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (INSTANCES NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'HOURS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (HOURS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'DAYS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (DAYS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'HOURS_PER_MONTH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (HOURS_PER_MONTH NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'IS_FROM_SHAPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (IS_FROM_SHAPE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EST_SERVICE'
     AND column_name = 'UI_STATE_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EST_SERVICE ADD (UI_STATE_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'EXADATA_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (EXADATA_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'SYSTEM_GENERATION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (SYSTEM_GENERATION VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'SYSTEM_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (SYSTEM_MODEL VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'NOTES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (NOTES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'FLEXIBLE_SYSTEM'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (FLEXIBLE_SYSTEM NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'ADDITIONAL_OCPU'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (ADDITIONAL_OCPU NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'DB_SERVERS_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (DB_SERVERS_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'STORAGE_SERVERS_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (STORAGE_SERVERS_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'OCPU_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (OCPU_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'OCPU_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (OCPU_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'OCPU_MIN_FACTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (OCPU_MIN_FACTOR NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'OCPU_MAX_FACTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (OCPU_MAX_FACTOR NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'BASE_DB_SERVERS_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (BASE_DB_SERVERS_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'BASE_STORAGE_SERVERS_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (BASE_STORAGE_SERVERS_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'TOTAL_PERSISTENT_MEMORY_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (TOTAL_PERSISTENT_MEMORY_CAPACITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'TOTAL_FLASH_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (TOTAL_FLASH_CAPACITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'TOTAL_USABLE_DISK_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (TOTAL_USABLE_DISK_CAPACITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'EXA_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (EXA_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'SYS_GEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (SYS_GEN VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'SYS_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (SYS_MODEL VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'DESCR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (DESCR CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'NOTES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (NOTES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'FLEX_SYS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (FLEX_SYS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'ADD_OCPU'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (ADD_OCPU NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'DB_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (DB_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'STG_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (STG_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'OCPU_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (OCPU_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'OCPU_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (OCPU_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'OCPU_MIN_F'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (OCPU_MIN_F NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'OCPU_MAX_F'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (OCPU_MAX_F NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'BASE_DB_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (BASE_DB_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'BASE_STG_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (BASE_STG_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'TPM_CAP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (TPM_CAP NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'FLASH_CAP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (FLASH_CAP NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'DISK_CAP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (DISK_CAP NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_CATALOG_LD'
     AND column_name = 'WT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_CATALOG_LD ADD (WT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_PRODUCT'
     AND column_name = 'EXADATA_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_PRODUCT ADD (EXADATA_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_PRODUCT'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_PRODUCT ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_PRODUCT'
     AND column_name = 'PRODUCT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_PRODUCT ADD (PRODUCT_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXADATA_PRODUCT'
     AND column_name = 'PRESET_NAMES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXADATA_PRODUCT ADD (PRESET_NAMES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (COMPARTMENT_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'CURRENT_CUSTOM_ACTION_TIMEOUT_IN_MINS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (CURRENT_CUSTOM_ACTION_TIMEOUT_IN_MINS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'CURRENT_PATCHING_COMPONENT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (CURRENT_PATCHING_COMPONENT VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'CUSTOM_ACTION_TIMEOUT_IN_MINS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (CUSTOM_ACTION_TIMEOUT_IN_MINS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'DATABASE_SOFTWARE_IMAGE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (DATABASE_SOFTWARE_IMAGE_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (DESCRIPTION VARCHAR2(10000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (DISPLAY_NAME VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'ESTIMATED_DB_SERVER_PATCHING_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (ESTIMATED_DB_SERVER_PATCHING_TIME NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'ESTIMATED_NETWORK_SWITCHES_PATCHING_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (ESTIMATED_NETWORK_SWITCHES_PATCHING_TIME NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'ESTIMATED_STORAGE_SERVER_PATCHING_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (ESTIMATED_STORAGE_SERVER_PATCHING_TIME NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TOTAL_ESTIMATED_PATCHING_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TOTAL_ESTIMATED_PATCHING_TIME NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'IS_CUSTOM_ACTION_TIMEOUT_ENABLED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (IS_CUSTOM_ACTION_TIMEOUT_ENABLED VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'IS_DST_FILE_UPDATE_ENABLED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (IS_DST_FILE_UPDATE_ENABLED VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'IS_MAINTENANCE_RUN_GRANULAR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (IS_MAINTENANCE_RUN_GRANULAR VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'LIFECYCLE_DETAILS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (LIFECYCLE_DETAILS VARCHAR2(10000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'LIFECYCLE_STATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (LIFECYCLE_STATE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'MAINTENANCE_SUBTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (MAINTENANCE_SUBTYPE VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'MAINTENANCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (MAINTENANCE_TYPE VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCH_FAILURE_COUNT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCH_FAILURE_COUNT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCH_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCH_ID VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCHING_END_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCHING_END_TIME TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCHING_MODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCHING_MODE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCHING_START_TIME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCHING_START_TIME TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PATCHING_STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PATCHING_STATUS VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PEER_MAINTENANCE_RUN_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PEER_MAINTENANCE_RUN_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'PEER_MAINTENANCE_RUN_IDS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (PEER_MAINTENANCE_RUN_IDS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TARGET_DB_SERVER_VERSION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TARGET_DB_SERVER_VERSION VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TARGET_RESOURCE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TARGET_RESOURCE_ID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TARGET_RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TARGET_RESOURCE_TYPE VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TARGET_STORAGE_SERVER_VERSION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TARGET_STORAGE_SERVER_VERSION VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TIME_ENDED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TIME_ENDED TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TIME_SCHEDULED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TIME_SCHEDULED TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TIME_STARTED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TIME_STARTED TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_EXA_MAINTENANCE_PY'
     AND column_name = 'TOTAL_TIME_TAKEN_IN_MINS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_EXA_MAINTENANCE_PY ADD (TOTAL_TIME_TAKEN_IN_MINS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'RUN_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (RUN_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'JOB_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (JOB_NAME VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'MODULE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (MODULE VARCHAR2(128))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'START_TS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (START_TS TIMESTAMP(6) DEFAULT systimestamp NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'END_TS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (END_TS TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (STATUS VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'PARAMS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (PARAMS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'ERROR_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (ERROR_CODE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUNS'
     AND column_name = 'ERROR_MSG'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUNS ADD (ERROR_MSG VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'LOG_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (LOG_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'RUN_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (RUN_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'LOG_TS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (LOG_TS TIMESTAMP(6) DEFAULT systimestamp NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'LEVEL_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (LEVEL_NAME VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'STEP_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (STEP_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'MESSAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (MESSAGE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'DETAILS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (DETAILS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'ROWS_AFFECTED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (ROWS_AFFECTED NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JOB_RUN_LOG'
     AND column_name = 'ELAPSED_MS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JOB_RUN_LOG ADD (ELAPSED_MS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE'
     AND column_name = 'FILE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE ADD (FILE_NAME VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE'
     AND column_name = 'PAYLOAD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE ADD (PAYLOAD CLOB NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE'
     AND column_name = 'LOADED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE ADD (LOADED_AT TIMESTAMP(6) DEFAULT systimestamp NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE'
     AND column_name = 'SOURCE_NOTE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE ADD (SOURCE_NOTE VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE_STAGE'
     AND column_name = 'FILE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE_STAGE ADD (FILE_NAME VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_JSON_SOURCE_STAGE'
     AND column_name = 'PAYLOAD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_JSON_SOURCE_STAGE ADD (PAYLOAD CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'METRIC_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (METRIC_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (DISPLAY_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (LANGUAGE_CODE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'UTILIZATION_PERIOD'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (UTILIZATION_PERIOD NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'CREATED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (CREATED_ON TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'MODIFIED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (MODIFIED_ON TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG_L10N'
     AND column_name = 'METRIC_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG_L10N ADD (METRIC_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG_L10N'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG_L10N ADD (LANGUAGE_CODE VARCHAR2(30) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_METRIC_CATALOG_L10N'
     AND column_name = 'LOCALIZED_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_METRIC_CATALOG_L10N ADD (LOCALIZED_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_MY_CUSTOM_REPORTS'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_MY_CUSTOM_REPORTS ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_MY_CUSTOM_REPORTS'
     AND column_name = 'REPORT_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_MY_CUSTOM_REPORTS ADD (REPORT_NAME VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_MY_CUSTOM_REPORTS'
     AND column_name = 'WORKLOAD_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_MY_CUSTOM_REPORTS ADD (WORKLOAD_NAME VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_MY_CUSTOM_REPORTS'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_MY_CUSTOM_REPORTS ADD (COMPARTMENT_ID CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_MY_CUSTOM_REPORTS'
     AND column_name = 'OWNER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_MY_CUSTOM_REPORTS ADD (OWNER VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (DISPLAY_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (STATUS VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (LANGUAGE_CODE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (HIDDEN NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'HAS_SPECIAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (HAS_SPECIAL NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG_L10N'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG_L10N ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG_L10N'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG_L10N ADD (LANGUAGE_CODE VARCHAR2(30) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG_L10N'
     AND column_name = 'LOCALIZED_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG_L10N ADD (LOCALIZED_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATALOG_L10N'
     AND column_name = 'LOCALIZED_DESC'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATALOG_L10N ADD (LOCALIZED_DESC CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'CATEGORY_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (CATEGORY_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'CLASSIFICATION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (CLASSIFICATION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (DISPLAY_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (LANGUAGE_CODE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (HIDDEN NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'CREATED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (CREATED_ON TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'MODIFIED_ON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (MODIFIED_ON TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_L10N'
     AND column_name = 'CATEGORY_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_L10N ADD (CATEGORY_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_L10N'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_L10N ADD (LANGUAGE_CODE VARCHAR2(30) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_L10N'
     AND column_name = 'LOCALIZED_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_L10N ADD (LOCALIZED_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_MAP'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_MAP ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_MAP'
     AND column_name = 'CATEGORY_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_MAP ADD (CATEGORY_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_MAP'
     AND column_name = 'CATEGORY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_MAP ADD (CATEGORY_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_CATEGORY_MAP'
     AND column_name = 'CATEGORY_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_CATEGORY_MAP ADD (CATEGORY_LABEL VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'PRODUCT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (PRODUCT_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'PRODUCT_PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (PRODUCT_PART_NUMBER VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'PRODUCT_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (PRODUCT_DISPLAY_NAME VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'DEFAULT_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (DEFAULT_QUANTITY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'RECOMMENDED_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (RECOMMENDED_QUANTITY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'ALLOW_ZERO_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (ALLOW_ZERO_QUANTITY NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_ITEM'
     AND column_name = 'MESSAGE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_ITEM ADD (MESSAGE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'SHAPE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (SHAPE_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (STATUS VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'SHAPE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (SHAPE_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'SUBTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (SUBTYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'PROCESSOR_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (PROCESSOR_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'BUNDLE_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (BUNDLE_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'GPU_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (GPU_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'GPU_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (GPU_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'LOCAL_DISK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (LOCAL_DISK VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'ALLOW_RESERVED_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (ALLOW_RESERVED_CAPACITY NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'ALLOW_PREEMPTIBLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (ALLOW_PREEMPTIBLE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'ALLOW_DEDICATED_HOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (ALLOW_DEDICATED_HOST NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'ALLOW_BURSTABLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (ALLOW_BURSTABLE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_SHAPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_SHAPE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_PRICING_OPTIONS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_PRICING_OPTIONS NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_PROCESSOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_PROCESSOR NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_OCPU'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_OCPU NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_MEMORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_MEMORY NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_DISK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_DISK NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDE_OS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDE_OS NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'IS_DEFAULT_IN_PRESET'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (IS_DEFAULT_IN_PRESET NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (HIDDEN NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'WINDOWS_SUPPORTED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (WINDOWS_SUPPORTED NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'FUNCTION_DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (FUNCTION_DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'PRODUCT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (PRODUCT_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'MIN_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (MIN_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'MAX_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (MAX_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRESET_SHAPE_PRODUCT'
     AND column_name = 'DEFAULT_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRESET_SHAPE_PRODUCT ADD (DEFAULT_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (DISPLAY_NAME VARCHAR2(400) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'METRIC_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (METRIC_NAME VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'SERVICE_CATEGORY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (SERVICE_CATEGORY VARCHAR2(200) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'CURRENCY_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (CURRENCY_CODE VARCHAR2(10) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'PRICE_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (PRICE_MODEL VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'UNIT_PRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (UNIT_PRICE NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'FETCHED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (FETCHED_AT TIMESTAMP(6) DEFAULT systimestamp NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRICE_CATALOG'
     AND column_name = 'SRC_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRICE_CATALOG ADD (SRC_URL VARCHAR2(1000) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'PRODUCT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (PRODUCT_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (SERVICE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (DISPLAY_NAME VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'METRIC_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (METRIC_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'PRICE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (PRICE_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'BILLING_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (BILLING_MODEL VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'AVAILABILITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (AVAILABILITY VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'ALLOW_DECIMAL_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (ALLOW_DECIMAL_QTY NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'SUPPORT_REWARDS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (SUPPORT_REWARDS NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'SERVICE_CATEGORY_DISPLAY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (SERVICE_CATEGORY_DISPLAY VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'LCP_DESC'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (LCP_DESC VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'DOCUMENTATION_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (DOCUMENTATION_URL VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (HIDDEN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (NAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'LANGUAGE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (LANGUAGE VARCHAR2(20))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (DISPLAY_NAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (STATUS VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'HAS_SPECIAL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (HAS_SPECIAL VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'CATEGORIES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (CATEGORIES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'TAGS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (TAGS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'PRESET_ITEMS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (PRESET_ITEMS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'PRESET_SHAPES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (PRESET_SHAPES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'SRC_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (SRC_URL VARCHAR2(500))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESETS'
     AND column_name = 'FETCHED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESETS ADD (FETCHED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'PRESET_ITEM_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (PRESET_ITEM_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'PRESET_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (PRESET_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'ITEM_SEQ'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (ITEM_SEQ NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (QUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'RECOMMENDED_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (RECOMMENDED_QUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'MESSAGE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (MESSAGE_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'ALLOW_ZERO_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (ALLOW_ZERO_QUANTITY VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'PRODUCT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (PRODUCT_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (PART_NUMBER VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRESET_ITEMS'
     AND column_name = 'PRODUCT_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRESET_ITEMS ADD (PRODUCT_DISPLAY_NAME VARCHAR2(400))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRICE'
     AND column_name = 'PRODUCT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRICE ADD (PRODUCT_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRICE'
     AND column_name = 'CURRENCY_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRICE ADD (CURRENCY_CODE VARCHAR2(10) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRICE'
     AND column_name = 'PRICE_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRICE ADD (PRICE_MODEL VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRICE'
     AND column_name = 'REALM_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRICE ADD (REALM_CODE NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_PRODUCT_PRICE'
     AND column_name = 'UNIT_PRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_PRODUCT_PRICE ADD (UNIT_PRICE NUMBER(18,6) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (DISPLAY_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'IDENTIFIER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (IDENTIFIER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (REGION VARCHAR2(60))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (RESOURCE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'DEFINED_TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (DEFINED_TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'FREEFORM_TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (FREEFORM_TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'COMPARTMENT_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (COMPARTMENT_ID VARCHAR2(255))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'SYSTEM_TAGS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (SYSTEM_TAGS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'AVAILABILITY_DOMAIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (AVAILABILITY_DOMAIN VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'TIME_CREATED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (TIME_CREATED TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCES_PY'
     AND column_name = 'ADDITIONAL_DETAILS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCES_PY ADD (ADDITIONAL_DETAILS CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'CHILD_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (CHILD_DISPLAY_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'CHILD_RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (CHILD_RESOURCE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'PARENT_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (PARENT_DISPLAY_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'PARENT_RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (PARENT_RESOURCE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'NODE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (NODE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'RAW_CLUSTER_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (RAW_CLUSTER_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'NORMALIZED_CLUSTER_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (NORMALIZED_CLUSTER_ID VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_OKE_RELATIONSHIPS'
     AND column_name = 'SNAPSHOT_DATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_OKE_RELATIONSHIPS ADD (SNAPSHOT_DATE DATE DEFAULT SYSDATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'CHILD_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (CHILD_DISPLAY_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'CHILD_RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (CHILD_RESOURCE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'PARENT_DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (PARENT_DISPLAY_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'PARENT_RESOURCE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (PARENT_RESOURCE_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'RAW_CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (RAW_CREATED_BY VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'NORMALIZED_CREATED_BY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (NORMALIZED_CREATED_BY VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'SNAPSHOT_DATE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (SNAPSHOT_DATE DATE DEFAULT SYSDATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'CHILD_IDENTIFIER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (CHILD_IDENTIFIER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_RESOURCE_RELATIONSHIPS'
     AND column_name = 'PARENT_IDENTIFIER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_RESOURCE_RELATIONSHIPS ADD (PARENT_IDENTIFIER VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SHAPE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SHAPE_NAME VARCHAR2(100) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (STATUS VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'FEATURES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (FEATURES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'LCP_DESC'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (LCP_DESC VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SHAPE_TYPE_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SHAPE_TYPE_VALUE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SHAPE_TYPE_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SHAPE_TYPE_LABEL VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SUB_TYPE_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SUB_TYPE_VALUE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SUB_TYPE_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SUB_TYPE_LABEL VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'PROCESSOR_TYPE_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (PROCESSOR_TYPE_VALUE VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'PROCESSOR_TYPE_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (PROCESSOR_TYPE_LABEL VARCHAR2(30))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'BUNDLE_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (BUNDLE_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SHAPE_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SHAPE_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'FACTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (FACTOR NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'GPU_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (GPU_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'GPU_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (GPU_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'FUNCTION_DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (FUNCTION_DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'LOCAL_DISK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (LOCAL_DISK VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'ALLOW_RESERVED_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (ALLOW_RESERVED_CAPACITY VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'ALLOW_PREEMPTIBLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (ALLOW_PREEMPTIBLE VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'ALLOW_DEDICATED_HOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (ALLOW_DEDICATED_HOST VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'ALLOW_BURSTABLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (ALLOW_BURSTABLE VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (HIDDEN VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'WINDOWS_SUPPORTED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (WINDOWS_SUPPORTED VARCHAR2(5))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'USABLE_OCPU_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (USABLE_OCPU_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'EXTENDED_OCPU_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (EXTENDED_OCPU_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'EXTENDED_OCPU_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (EXTENDED_OCPU_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'EXTENDED_MEMORY_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (EXTENDED_MEMORY_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'EXTENDED_MEMORY_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (EXTENDED_MEMORY_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'PRODUCTS_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (PRODUCTS_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SUPPORTED_OS_IMAGES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SUPPORTED_OS_IMAGES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'FETCHED_AT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (FETCHED_AT TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPES_CATALOG'
     AND column_name = 'SRC_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPES_CATALOG ADD (SRC_URL VARCHAR2(1000) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (STATUS VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'FEATURES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (FEATURES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'WEIGHT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (WEIGHT NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'LCP_DESC'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (LCP_DESC VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'SHAPE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (SHAPE_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'SUBTYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (SUBTYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'PROCESSOR_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (PROCESSOR_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'BUNDLE_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (BUNDLE_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'SHAPE_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (SHAPE_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'FACTOR'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (FACTOR NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'GPU_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (GPU_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'GPU_MEMORY_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (GPU_MEMORY_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'FUNCTION_DESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (FUNCTION_DESCRIPTION CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'LOCAL_DISK'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (LOCAL_DISK VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'ALLOW_RESERVED_CAPACITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (ALLOW_RESERVED_CAPACITY NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'ALLOW_PREEMPTIBLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (ALLOW_PREEMPTIBLE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'ALLOW_DEDICATED_HOST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (ALLOW_DEDICATED_HOST NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'ALLOW_BURSTABLE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (ALLOW_BURSTABLE NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'HIDDEN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (HIDDEN NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'WINDOWS_SUPPORTED'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (WINDOWS_SUPPORTED NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'USABLE_OCPU_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (USABLE_OCPU_QTY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'EXT_OCPU_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (EXT_OCPU_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'EXT_OCPU_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (EXT_OCPU_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'EXT_MEMORY_MIN'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (EXT_MEMORY_MIN NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'EXT_MEMORY_MAX'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (EXT_MEMORY_MAX NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_OS_IMAGE'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_OS_IMAGE ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_OS_IMAGE'
     AND column_name = 'IMAGE_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_OS_IMAGE ADD (IMAGE_VALUE VARCHAR2(100) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_OS_IMAGE'
     AND column_name = 'IMAGE_LABEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_OS_IMAGE ADD (IMAGE_LABEL VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_OS_IMAGE'
     AND column_name = 'IMAGE_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_OS_IMAGE ADD (IMAGE_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'SHAPE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (SHAPE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (PART_NUMBER VARCHAR2(50) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'PRODUCT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (PRODUCT_TYPE VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'MIN_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (MIN_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'MAX_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (MAX_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'DEFAULT_QTY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (DEFAULT_QTY NUMBER(18,6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SHAPE_PRODUCT'
     AND column_name = 'PRESET_NAMES_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SHAPE_PRODUCT ADD (PRESET_NAMES_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'SUBSCRIPTION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (SUBSCRIPTION_ID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'ISO_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (ISO_CODE VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (NAME VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'STD_PRECISION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (STD_PRECISION NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'SERVICE_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (SERVICE_NAME VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'STATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (STATUS VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'AVAILABLE_AMOUNT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (AVAILABLE_AMOUNT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'BOOKING_OPTY_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (BOOKING_OPTY_NUMBER VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'COMMITMENT_SERVICES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (COMMITMENT_SERVICES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'CSI'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (CSI VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'DATA_CENTER_REGION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (DATA_CENTER_REGION VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'FUNDED_ALLOCATION_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (FUNDED_ALLOCATION_VALUE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (ID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'IS_INTENT_TO_PAY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (IS_INTENT_TO_PAY VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'NET_UNIT_PRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (NET_UNIT_PRICE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'OPERATION_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (OPERATION_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'ORDER_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (ORDER_NUMBER VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'ORIGINAL_PROMO_AMOUNT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (ORIGINAL_PROMO_AMOUNT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PARTNER_TRANSACTION_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PARTNER_TRANSACTION_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PRICING_MODEL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PRICING_MODEL VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PRODUCT_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PRODUCT_NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PRODUCT_PART_NUMBER'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PRODUCT_PART_NUMBER VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PRODUCT_PROVISIONING_GROUP'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PRODUCT_PROVISIONING_GROUP VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PRODUCT_UNIT_OF_MEASURE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PRODUCT_UNIT_OF_MEASURE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PROGRAM_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PROGRAM_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'PROMO_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (PROMO_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (QUANTITY VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'SUBSTATUS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (SUBSTATUS VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'TIME_END'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (TIME_END VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'TIME_START'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (TIME_START VARCHAR2(50))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'TOTAL_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (TOTAL_VALUE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'USED_AMOUNT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (USED_AMOUNT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTIONS_PY'
     AND column_name = 'SUBSCRIPTION_LINE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTIONS_PY ADD (SUBSCRIPTION_LINE_ID VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'SUBSCRIPTION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (SUBSCRIPTION_ID VARCHAR2(255) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'SUBSCRIPTION_LINE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (SUBSCRIPTION_LINE_ID VARCHAR2(255) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_TIME_START'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_TIME_START TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_TIME_END'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_TIME_END TIMESTAMP(6))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_QUANTITY VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_AVAILABLE_AMT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_AVAILABLE_AMT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_LINE_NET_AMT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_LINE_NET_AMT VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_COMMITMENTS'
     AND column_name = 'COMMITMENT_FA_VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_COMMITMENTS ADD (COMMITMENT_FA_VALUE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'SUBSCRIPTION_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (SUBSCRIPTION_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'ORDER_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (ORDER_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'ORDER_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (ORDER_NAME VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'QUANTITY'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (QUANTITY NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'TIME_START'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (TIME_START DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'TIME_END'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (TIME_END DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SUBSCRIPTION_DETAILS'
     AND column_name = 'SUBSCRIPTION_LINE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SUBSCRIPTION_DETAILS ADD (SUBSCRIPTION_LINE_ID VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (SERVICE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'ORIGINAL_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (ORIGINAL_ID NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (NAME VARCHAR2(200))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'DISPLAY_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (DISPLAY_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'COMPONENT_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (COMPONENT_TYPE VARCHAR2(100))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'CATEGORY_TYPE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (CATEGORY_TYPE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'HIDE_SECTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (HIDE_SECTION VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'HIDE_INSTANCES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (HIDE_INSTANCES VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'HIDE_HOURS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (HIDE_HOURS VARCHAR2(10))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'FIXED_UTILIZATION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (FIXED_UTILIZATION NUMBER(1,0))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'DEFAULT_DAYS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (DEFAULT_DAYS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'DEFAULT_HOURS'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (DEFAULT_HOURS NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'CAPACITY_RESERVATION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (CAPACITY_RESERVATION NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'PRICE_RATIO'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (PRICE_RATIO NUMBER(10,4))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'NOTES'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (NOTES CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'PRODUCT_PAGE_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (PRODUCT_PAGE_URL VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'PRODUCT_DOC_URL'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (PRODUCT_DOC_URL VARCHAR2(1000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG'
     AND column_name = 'RAW_JSON'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG ADD (RAW_JSON CLOB)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG_L10N'
     AND column_name = 'SERVICE_ID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG_L10N ADD (SERVICE_ID NUMBER NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG_L10N'
     AND column_name = 'LANGUAGE_CODE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG_L10N ADD (LANGUAGE_CODE VARCHAR2(30) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_SVC_CATALOG_L10N'
     AND column_name = 'LOCALIZED_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_SVC_CATALOG_L10N ADD (LOCALIZED_NAME VARCHAR2(300))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_WORKLOADS'
     AND column_name = 'WORKLOAD_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_WORKLOADS ADD (WORKLOAD_NAME VARCHAR2(100) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'OCI_WORKLOADS'
     AND column_name = 'VALUE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE OCI_WORKLOADS ADD (VALUE VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_MONTH_CHART_DATA'
     AND column_name = 'WORKLOAD_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA ADD (WORKLOAD_NAME VARCHAR2(400) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_MONTH_CHART_DATA'
     AND column_name = 'MONTH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA ADD (MONTH DATE NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_MONTH_CHART_DATA'
     AND column_name = 'COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA ADD (COST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_MONTH_CHART_DATA'
     AND column_name = 'LAST_REFRESH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA ADD (LAST_REFRESH DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_WEEK_CHART_DATA'
     AND column_name = 'WORKLOAD_NAME'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA ADD (WORKLOAD_NAME VARCHAR2(400) NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_WEEK_CHART_DATA'
     AND column_name = 'WEEK_START'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA ADD (WEEK_START DATE NOT NULL)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_WEEK_CHART_DATA'
     AND column_name = 'COST'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA ADD (COST NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'PAGE1_CONS_WRKLD_WEEK_CHART_DATA'
     AND column_name = 'LAST_REFRESH'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA ADD (LAST_REFRESH DATE)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'RATECARD_MV'
     AND column_name = 'CHARGEDESCRIPTION'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE RATECARD_MV ADD (CHARGEDESCRIPTION VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'RATECARD_MV'
     AND column_name = 'PRICINGUNIT'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE RATECARD_MV ADD (PRICINGUNIT VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'RATECARD_MV'
     AND column_name = 'SKUID'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE RATECARD_MV ADD (SKUID VARCHAR2(4000))~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'RATECARD_MV'
     AND column_name = 'ACTUALUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE RATECARD_MV ADD (ACTUALUNITPRICE NUMBER)~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_tab_cols
   WHERE table_name = 'RATECARD_MV'
     AND column_name = 'LISTUNITPRICE'
     AND hidden_column = 'NO';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~ALTER TABLE RATECARD_MV ADD (LISTUNITPRICE NUMBER)~';
  END IF;
END;
/

