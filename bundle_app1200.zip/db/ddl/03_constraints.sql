DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0029640';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'APP_CONFIG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_KEY';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "APP_CONFIG" ADD PRIMARY KEY ("CONFIG_KEY")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'PK_CCAMR';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_CORE_AGENT_MODE_ROUTE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'MODE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_MODE_ROUTE" ADD CONSTRAINT "PK_CCAMR" PRIMARY KEY ("MODE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_CORE_AGENT_RUNS_ARCH_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_CORE_AGENT_RUNS_ARCH'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RUN_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_RUNS_ARCH" ADD CONSTRAINT "CHATBOT_CORE_AGENT_RUNS_ARCH_PK" PRIMARY KEY ("RUN_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_CORE_AGENT_RUN_STEPS_ARCH_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_CORE_AGENT_RUN_STEPS_ARCH'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'STEP_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_RUN_STEPS_ARCH" ADD CONSTRAINT "CHATBOT_CORE_AGENT_RUN_STEPS_ARCH_PK" PRIMARY KEY ("STEP_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_OUT_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_DATASET_RULE_OUTPUTS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RULE_ID,ORD';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_OUTPUTS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_OUT_PK" PRIMARY KEY ("RULE_ID", "ORD")
  USING INDEX "CHATBOT_DATASET_RULE_OUT_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_GENERIC_CONV_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_GENERIC_CONVERSATION'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CHAT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_GENERIC_CONVERSATION" ADD CONSTRAINT "CHATBOT_GENERIC_CONV_PK" PRIMARY KEY ("CHAT_ID")
  USING INDEX "CHATBOT_GENERIC_CONV_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_GENERIC_DEBUG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_GENERIC_DEBUG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_GENERIC_DEBUG" ADD CONSTRAINT "CHATBOT_GENERIC_DEBUG_PK" PRIMARY KEY ("ID")
  USING INDEX "CHATBOT_GENERIC_DEBUG_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_GENERIC_LOG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_GENERIC_LOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_GENERIC_LOG" ADD CONSTRAINT "CHATBOT_GENERIC_LOG_PK" PRIMARY KEY ("ID")
  USING INDEX "CHATBOT_GENERIC_LOG_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_GLOSSARY_KEYWORDS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_GLOSSARY_KEYWORDS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RULE_ID,ORD';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_GLOSSARY_KEYWORDS" ADD CONSTRAINT "CHATBOT_GLOSSARY_KEYWORDS_PK" PRIMARY KEY ("RULE_ID", "ORD")
  USING INDEX "CHATBOT_GLOSSARY_KEYWORDS_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0031178';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_INSIGHTS_RUN'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'INSIGHTS_RUN_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_INSIGHTS_RUN" ADD PRIMARY KEY ("INSIGHTS_RUN_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_JOB_DEBUG_ARCH_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_JOB_DEBUG_ARCH'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_JOB_DEBUG_ARCH" ADD CONSTRAINT "CHATBOT_JOB_DEBUG_ARCH_PK" PRIMARY KEY ("ID")
  USING INDEX "CHATBOT_JOB_DEBUG_ARCH_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_NL2SQL_CONV_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_NL2SQL_CONVERSATION'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CHAT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_CONVERSATION" ADD CONSTRAINT "CHATBOT_NL2SQL_CONV_PK" PRIMARY KEY ("CHAT_ID")
  USING INDEX "CHATBOT_NL2SQL_CONV_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_NL2SQL_CONV_ARCH_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_NL2SQL_CONV_ARCH'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CHAT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_CONV_ARCH" ADD CONSTRAINT "CHATBOT_NL2SQL_CONV_ARCH_PK" PRIMARY KEY ("CHAT_ID")
  USING INDEX "CHATBOT_NL2SQL_CONV_ARCH_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_NL2SQL_LOG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_NL2SQL_LOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_LOG" ADD CONSTRAINT "CHATBOT_NL2SQL_LOG_PK" PRIMARY KEY ("ID")
  USING INDEX "CHATBOT_NL2SQL_LOG_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_NL2SQL_LOG_ARCH_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_NL2SQL_LOG_ARCH'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_LOG_ARCH" ADD CONSTRAINT "CHATBOT_NL2SQL_LOG_ARCH_PK" PRIMARY KEY ("ID")
  USING INDEX "CHATBOT_NL2SQL_LOG_ARCH_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_PARAM_META_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_PARAMETER_METADATA'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'COMPONENT_TYPE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_PARAMETER_METADATA" ADD CONSTRAINT "CHATBOT_PARAM_META_PK" PRIMARY KEY ("COMPONENT_TYPE")
  USING INDEX "CHATBOT_PARAM_META_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_FEEDBACK_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_RUN_FEEDBACK'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'FEEDBACK_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_FEEDBACK" ADD CONSTRAINT "CHATBOT_RUN_FEEDBACK_PK" PRIMARY KEY ("FEEDBACK_ID")
  USING INDEX "CHATBOT_RUN_FEEDBACK_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_RUN_INSIGHTS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'INSIGHT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_PK" PRIMARY KEY ("INSIGHT_ID")
  USING INDEX "CHATBOT_RUN_INSIGHTS_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'DBTOOLS$EXECUTION_HISTORY_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DBTOOLS$EXECUTION_HISTORY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DBTOOLS$EXECUTION_HISTORY" ADD CONSTRAINT "DBTOOLS$EXECUTION_HISTORY_PK" PRIMARY KEY ("ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030295';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_APPLIED'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'APPLIED_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_APPLIED" ADD PRIMARY KEY ("APPLIED_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030282';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_BUNDLES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'BUNDLE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_BUNDLES" ADD PRIMARY KEY ("BUNDLE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030304';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_MIGRATION_SCRIPTS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'MIGRATION_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_MIGRATION_SCRIPTS" ADD PRIMARY KEY ("MIGRATION_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030288';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_RUNS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RUN_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_RUNS" ADD PRIMARY KEY ("RUN_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030299';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_SCHEMA_MIGRATIONS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'MIGRATION_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_SCHEMA_MIGRATIONS" ADD PRIMARY KEY ("MIGRATION_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'DOC_UPLOAD_ID_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DOC_UPLOAD'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DOC_UPLOAD" ADD CONSTRAINT "DOC_UPLOAD_ID_PK" PRIMARY KEY ("ID")
  USING INDEX "DOC_UPLOAD_ID_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0029797';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'FOCUS_REPORTS_LOAD_LOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "FOCUS_REPORTS_LOAD_LOG" ADD PRIMARY KEY ("ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030579';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'FR_AUTHZ_GROUPS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'GROUP_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "FR_AUTHZ_GROUPS" ADD PRIMARY KEY ("GROUP_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030206';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'GENAI_MODEL_PRICE_MAP'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'MODEL_KEY';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "GENAI_MODEL_PRICE_MAP" ADD PRIMARY KEY ("MODEL_KEY")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_COMP_TAX_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_COMPUTE_SHAPE_TAXONOMY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'TAXONOMY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_COMPUTE_SHAPE_TAXONOMY" ADD CONSTRAINT "OCI_CALC_COMP_TAX_PK" PRIMARY KEY ("TAXONOMY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIGURATION'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_PK" PRIMARY KEY ("CONFIG_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIG_DEPENDENCY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DEPENDENCY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_PK" PRIMARY KEY ("DEPENDENCY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_DRIVER_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIG_DRIVER'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_DRIVER_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CONFIG_DRIVER_PK" PRIMARY KEY ("CONFIG_DRIVER_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_DRIVER_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_DRIVER'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DRIVER_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_DRIVER" ADD CONSTRAINT "OCI_CALC_DRIVER_PK" PRIMARY KEY ("DRIVER_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_FAMILY_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_FAMILY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'FAMILY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_FAMILY" ADD CONSTRAINT "OCI_CALC_FAMILY_PK" PRIMARY KEY ("FAMILY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_GENAI_TAX_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_GENAI_SKU_TAXONOMY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'GENAI_TAXONOMY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_GENAI_SKU_TAXONOMY" ADD CONSTRAINT "OCI_CALC_GENAI_TAX_PK" PRIMARY KEY ("GENAI_TAXONOMY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_RULE_DIAGNOSTIC'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DIAG_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_PK" PRIMARY KEY ("DIAG_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SERVICE_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_SERVICE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SERVICE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SERVICE" ADD CONSTRAINT "OCI_CALC_SERVICE_PK" PRIMARY KEY ("SERVICE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_SKU_RULE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SKU_RULE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_PK" PRIMARY KEY ("SKU_RULE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030756';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CURRENCY_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CURRENCY_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CURRENCY_CATALOG" ADD PRIMARY KEY ("CURRENCY_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030689';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_ESTIMATE_TEMPLATE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'TEMPLATE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_ESTIMATE_TEMPLATE" ADD PRIMARY KEY ("TEMPLATE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030742';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EST_CONFIG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EST_CONFIG_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EST_CONFIG" ADD PRIMARY KEY ("EST_CONFIG_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030738';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EST_HEADER'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EST_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EST_HEADER" ADD PRIMARY KEY ("EST_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030753';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EST_ITEM'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EST_ITEM_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EST_ITEM" ADD PRIMARY KEY ("EST_ITEM_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030747';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EST_SERVICE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EST_SERVICE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EST_SERVICE" ADD PRIMARY KEY ("EST_SERVICE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030775';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EXADATA_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EXADATA_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EXADATA_CATALOG" ADD PRIMARY KEY ("EXADATA_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_EXADATA_PRODUCT';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_EXADATA_PRODUCT'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EXADATA_ID,PART_NUMBER';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_EXADATA_PRODUCT" ADD CONSTRAINT "OCI_PK_EXADATA_PRODUCT" PRIMARY KEY ("EXADATA_ID", "PART_NUMBER")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030325';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_JOB_RUNS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RUN_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_JOB_RUNS" ADD PRIMARY KEY ("RUN_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030329';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_JOB_RUN_LOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'LOG_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_JOB_RUN_LOG" ADD PRIMARY KEY ("LOG_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030677';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_JSON_SOURCE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'FILE_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_JSON_SOURCE" ADD PRIMARY KEY ("FILE_NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030783';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_JSON_SOURCE_STAGE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'FILE_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_JSON_SOURCE_STAGE" ADD PRIMARY KEY ("FILE_NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030758';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_METRIC_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'METRIC_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_METRIC_CATALOG" ADD PRIMARY KEY ("METRIC_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_METRIC_CATALOG_L10N';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_METRIC_CATALOG_L10N'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'METRIC_ID,LANGUAGE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_METRIC_CATALOG_L10N" ADD CONSTRAINT "OCI_PK_METRIC_CATALOG_L10N" PRIMARY KEY ("METRIC_ID", "LANGUAGE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030683';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATALOG" ADD PRIMARY KEY ("PRESET_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_CATALOG_L10N';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATALOG_L10N'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID,LANGUAGE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATALOG_L10N" ADD CONSTRAINT "OCI_PK_PRESET_CATALOG_L10N" PRIMARY KEY ("PRESET_ID", "LANGUAGE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030681';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATEGORY'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CATEGORY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATEGORY" ADD PRIMARY KEY ("CATEGORY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_CATEGORY_L10N';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATEGORY_L10N'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CATEGORY_ID,LANGUAGE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATEGORY_L10N" ADD CONSTRAINT "OCI_PK_PRESET_CATEGORY_L10N" PRIMARY KEY ("CATEGORY_ID", "LANGUAGE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_CATEGORY_MAP';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATEGORY_MAP'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID,CATEGORY_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATEGORY_MAP" ADD CONSTRAINT "OCI_PK_PRESET_CATEGORY_MAP" PRIMARY KEY ("PRESET_ID", "CATEGORY_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_ITEM';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_ITEM'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID,PRODUCT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_ITEM" ADD CONSTRAINT "OCI_PK_PRESET_ITEM" PRIMARY KEY ("PRESET_ID", "PRODUCT_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_SHAPE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_SHAPE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID,SHAPE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_SHAPE" ADD CONSTRAINT "OCI_PK_PRESET_SHAPE" PRIMARY KEY ("PRESET_ID", "SHAPE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRESET_SHAPE_PRODUCT';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_SHAPE_PRODUCT'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ID,SHAPE_ID,PART_NUMBER';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_SHAPE_PRODUCT" ADD CONSTRAINT "OCI_PK_PRESET_SHAPE_PRODUCT" PRIMARY KEY ("PRESET_ID", "SHAPE_ID", "PART_NUMBER")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PRICE_CATALOG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRICE_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PART_NUMBER,CURRENCY_CODE,PRICE_MODEL';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRICE_CATALOG" ADD CONSTRAINT "OCI_PRICE_CATALOG_PK" PRIMARY KEY ("PART_NUMBER", "CURRENCY_CODE", "PRICE_MODEL")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030697';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRODUCT_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRODUCT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_CATALOG" ADD PRIMARY KEY ("PRODUCT_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030365';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRODUCT_PRESETS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESETS" ADD PRIMARY KEY ("ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PROD_PRESET_ITEMS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRODUCT_PRESET_ITEMS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRESET_ITEM_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESET_ITEMS" ADD CONSTRAINT "OCI_PROD_PRESET_ITEMS_PK" PRIMARY KEY ("PRESET_ITEM_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_PRODUCT_PRICE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRODUCT_PRICE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PRODUCT_ID,CURRENCY_CODE,PRICE_MODEL,REALM_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRICE" ADD CONSTRAINT "OCI_PK_PRODUCT_PRICE" PRIMARY KEY ("PRODUCT_ID", "CURRENCY_CODE", "PRICE_MODEL", "REALM_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030909';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SERVICE_TOPOLOGY_EDGES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'EDGE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SERVICE_TOPOLOGY_EDGES" ADD PRIMARY KEY ("EDGE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030900';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SERVICE_TOPOLOGY_RUNS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RUN_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SERVICE_TOPOLOGY_RUNS" ADD PRIMARY KEY ("RUN_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_SHAPES_CATALOG_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SHAPES_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SHAPE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SHAPES_CATALOG" ADD CONSTRAINT "OCI_SHAPES_CATALOG_PK" PRIMARY KEY ("SHAPE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030764';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SHAPE_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SHAPE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SHAPE_CATALOG" ADD PRIMARY KEY ("SHAPE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_SHAPE_OS_IMAGE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SHAPE_OS_IMAGE'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SHAPE_ID,IMAGE_VALUE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SHAPE_OS_IMAGE" ADD CONSTRAINT "OCI_PK_SHAPE_OS_IMAGE" PRIMARY KEY ("SHAPE_ID", "IMAGE_VALUE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_SHAPE_PRODUCT';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SHAPE_PRODUCT'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SHAPE_ID,PART_NUMBER';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SHAPE_PRODUCT" ADD CONSTRAINT "OCI_PK_SHAPE_PRODUCT" PRIMARY KEY ("SHAPE_ID", "PART_NUMBER")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030679';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SVC_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SERVICE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SVC_CATALOG" ADD PRIMARY KEY ("SERVICE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PK_SVC_CATALOG_L10N';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_SVC_CATALOG_L10N'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SERVICE_ID,LANGUAGE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_SVC_CATALOG_L10N" ADD CONSTRAINT "OCI_PK_SVC_CATALOG_L10N" PRIMARY KEY ("SERVICE_ID", "LANGUAGE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_WORKLOADS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_WORKLOADS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'WORKLOAD_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_WORKLOADS" ADD CONSTRAINT "OCI_WORKLOADS_PK" PRIMARY KEY ("WORKLOAD_NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0029630';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'PAGE1_CONS_WRKLD_MONTH_CHART_DATA'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'WORKLOAD_NAME,MONTH';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "PAGE1_CONS_WRKLD_MONTH_CHART_DATA" ADD PRIMARY KEY ("WORKLOAD_NAME", "MONTH")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0029631';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'PAGE1_CONS_WRKLD_WEEK_CHART_DATA'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'WORKLOAD_NAME,WEEK_START';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "PAGE1_CONS_WRKLD_WEEK_CHART_DATA" ADD PRIMARY KEY ("WORKLOAD_NAME", "WEEK_START")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RAG_CHATBOT_ID_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RAG_CHATBOT'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONV_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RAG_CHATBOT" ADD CONSTRAINT "RAG_CHATBOT_ID_PK" PRIMARY KEY ("CONV_ID")
  USING INDEX "RAG_CHATBOT_ID_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RAG_CITATIONS_ID_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RAG_CITATIONS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RAG_CITATIONS" ADD CONSTRAINT "RAG_CITATIONS_ID_PK" PRIMARY KEY ("ID")
  USING INDEX "RAG_CITATIONS_ID_PK";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDC_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_DOMAIN_CATALOG'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DOMAIN_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_CATALOG" ADD CONSTRAINT "RGDC_PK" PRIMARY KEY ("DOMAIN_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDR_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_DOMAIN_RULES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RULE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_RULES" ADD CONSTRAINT "RGDR_PK" PRIMARY KEY ("RULE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_EDGES_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_EDGES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,EDGE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_EDGES" ADD CONSTRAINT "RG_EDGES_PK" PRIMARY KEY ("SNAPSHOT_ID", "EDGE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_FILTERS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_FILTERS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,FILTER_TYPE,FILTER_VALUE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_FILTERS" ADD CONSTRAINT "RG_FILTERS_PK" PRIMARY KEY ("SNAPSHOT_ID", "FILTER_TYPE", "FILTER_VALUE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_NODES_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_NODES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,NODE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_NODES" ADD CONSTRAINT "RG_NODES_PK" PRIMARY KEY ("SNAPSHOT_ID", "NODE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_NODE_FACTS_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_NODE_FACTS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,NODE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_NODE_FACTS" ADD CONSTRAINT "RG_NODE_FACTS_PK" PRIMARY KEY ("SNAPSHOT_ID", "NODE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_SCOPE_NODES_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_SCOPE_NODES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,SCOPE_NAME,NODE_ID,NODE_ROLE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_SCOPE_NODES" ADD CONSTRAINT "RG_SCOPE_NODES_PK" PRIMARY KEY ("SNAPSHOT_ID", "SCOPE_NAME", "NODE_ID", "NODE_ROLE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030872';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_SNAPSHOTS'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_SNAPSHOTS" ADD PRIMARY KEY ("SNAPSHOT_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_TRAV_NODES_PK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'RESOURCE_GRAPH_TRAVERSAL_NODES'
       AND uc.constraint_type = 'P'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SNAPSHOT_ID,SCOPE_NAME,NODE_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_TRAVERSAL_NODES" ADD CONSTRAINT "RG_TRAV_NODES_PK" PRIMARY KEY ("SNAPSHOT_ID", "SCOPE_NAME", "NODE_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_KW_U1';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_DATASET_RULE_KEYWORDS'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RULE_ID,ORD';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_KEYWORDS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_KW_U1" UNIQUE ("RULE_ID", "ORD")
  USING INDEX "CHATBOT_DATASET_RULE_KW_U1";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_KW_U2';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_DATASET_RULE_KEYWORDS'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'RULE_ID,KEYWORD_NORM';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_KEYWORDS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_KW_U2" UNIQUE ("RULE_ID", "KEYWORD_NORM")
  USING INDEX "CHATBOT_DATASET_RULE_KW_U2";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'UK_CTS';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_NL2SQL_SUMMARY'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DATASET,ENVIRONMENT,TABLE_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_SUMMARY" ADD CONSTRAINT "UK_CTS" UNIQUE ("DATASET", "ENVIRONMENT", "TABLE_NAME")
  USING INDEX "UK_CTS";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_FEEDBACK_UQ';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_RUN_FEEDBACK'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'LOG_ID,APP_USER';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_FEEDBACK" ADD CONSTRAINT "CHATBOT_RUN_FEEDBACK_UQ" UNIQUE ("LOG_ID", "APP_USER")
  USING INDEX "CHATBOT_RUN_FEEDBACK_UQ";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_UQ_LOG';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'CHATBOT_RUN_INSIGHTS'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'LOG_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_UQ_LOG" UNIQUE ("LOG_ID")
  USING INDEX "CHATBOT_RUN_INSIGHTS_UQ_LOG";~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'DEPLOY_BUNDLES_UQ';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'DEPLOY_BUNDLES'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'APP_ID,VERSION_TAG';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_BUNDLES" ADD CONSTRAINT "DEPLOY_BUNDLES_UQ" UNIQUE ("APP_ID", "VERSION_TAG")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_COMP_TAX_UK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_COMPUTE_SHAPE_TAXONOMY'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SHAPE_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_COMPUTE_SHAPE_TAXONOMY" ADD CONSTRAINT "OCI_CALC_COMP_TAX_UK" UNIQUE ("SHAPE_NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_UK_CODE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIGURATION'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_UK_CODE" UNIQUE ("CONFIG_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_UK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIG_DEPENDENCY'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PARENT_CONFIG_ID,CHILD_CONFIG_ID,DEPENDENCY_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_UK" UNIQUE ("PARENT_CONFIG_ID", "CHILD_CONFIG_ID", "DEPENDENCY_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFGDRV_UK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_CONFIG_DRIVER'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_ID,DRIVER_ID';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CFGDRV_UK" UNIQUE ("CONFIG_ID", "DRIVER_ID")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_DRIVER_UK_KEY';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_DRIVER'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'DRIVER_KEY';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_DRIVER" ADD CONSTRAINT "OCI_CALC_DRIVER_UK_KEY" UNIQUE ("DRIVER_KEY")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_FAMILY_UK_CODE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_FAMILY'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'FAMILY_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_FAMILY" ADD CONSTRAINT "OCI_CALC_FAMILY_UK_CODE" UNIQUE ("FAMILY_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_GENAI_TAX_UK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_GENAI_SKU_TAXONOMY'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PART_NUMBER,CURRENCY_CODE,PRICE_MODEL';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_GENAI_SKU_TAXONOMY" ADD CONSTRAINT "OCI_CALC_GENAI_TAX_UK" UNIQUE ("PART_NUMBER", "CURRENCY_CODE", "PRICE_MODEL")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SERVICE_UK_CODE';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_SERVICE'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'SERVICE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SERVICE" ADD CONSTRAINT "OCI_CALC_SERVICE_UK_CODE" UNIQUE ("SERVICE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_UK';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_CALC_SKU_RULE'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CONFIG_ID,PART_NUMBER,SKU_ROLE_CODE';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_UK" UNIQUE ("CONFIG_ID", "PART_NUMBER", "SKU_ROLE_CODE")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030690';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_ESTIMATE_TEMPLATE'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'CODE_NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_ESTIMATE_TEMPLATE" ADD UNIQUE ("CODE_NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030684';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRESET_CATALOG'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'NAME';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_CATALOG" ADD UNIQUE ("NAME")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  -- PK/UK guard: name match OR equivalent table/type/ordered-column signature.
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'SYS_C0030698';
  IF l_cnt = 0 THEN
    SELECT COUNT(*)
      INTO l_cnt
      FROM user_constraints uc
     WHERE uc.table_name = 'OCI_PRODUCT_CATALOG'
       AND uc.constraint_type = 'U'
       AND (
             SELECT LISTAGG(ucc.column_name, ',') WITHIN GROUP (ORDER BY ucc.position)
               FROM user_cons_columns ucc
              WHERE ucc.constraint_name = uc.constraint_name
                AND ucc.table_name      = uc.table_name
           ) = 'PART_NUMBER';
  END IF;
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_CATALOG" ADD UNIQUE ("PART_NUMBER")
  USING INDEX;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CK_CCAMR_ENABLED';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_MODE_ROUTE" ADD CONSTRAINT "CK_CCAMR_ENABLED" CHECK (enabled_yn in ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CK_CCAMR_MODE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_MODE_ROUTE" ADD CONSTRAINT "CK_CCAMR_MODE" CHECK (regexp_like(mode_code, '^[a-z0-9_]+$'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHK_STEP_REQUIRED';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_STEP_SEQUENCE" ADD CONSTRAINT "CHK_STEP_REQUIRED" CHECK (REQUIRED IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHK_TOOL_REG_ENABLED';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_TOOL_REGISTRY" ADD CONSTRAINT "CHK_TOOL_REG_ENABLED" CHECK (ENABLED IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHK_TOOL_REG_FAILFAST';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_TOOL_REGISTRY" ADD CONSTRAINT "CHK_TOOL_REG_FAILFAST" CHECK (FAIL_FAST_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHK_TOOL_REG_PAYLOAD_MERGE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_CORE_AGENT_TOOL_REGISTRY" ADD CONSTRAINT "CHK_TOOL_REG_PAYLOAD_MERGE" CHECK (PAYLOAD_MERGE_MODE IN ('REPLACE','MERGE_OBJECT','APPEND_ARRAY'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULES_CK_ACTIVE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULES" ADD CONSTRAINT "CHATBOT_DATASET_RULES_CK_ACTIVE" CHECK (active_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULES_CK_CARRY';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULES" ADD CONSTRAINT "CHATBOT_DATASET_RULES_CK_CARRY" CHECK (carry_forward_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULES_CK_MATCH_MODE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULES" ADD CONSTRAINT "CHATBOT_DATASET_RULES_CK_MATCH_MODE" CHECK (match_mode IN ('ANY','ALL','EXACT'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULES_CK_RULE_TYPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULES" ADD CONSTRAINT "CHATBOT_DATASET_RULES_CK_RULE_TYPE" CHECK (rule_type IN ('TARGET_FILTER','TIME_COMPARISON','OUTPUT_HINT','CUSTOM'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_CMP_CK_GRAIN';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_COMPARISON" ADD CONSTRAINT "CHATBOT_DATASET_RULE_CMP_CK_GRAIN" CHECK (time_grain IN ('DAY','WEEK','MONTH','QUARTER','YEAR'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_CMP_CK_REQ_TS';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_COMPARISON" ADD CONSTRAINT "CHATBOT_DATASET_RULE_CMP_CK_REQ_TS" CHECK (requires_time_series_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_CMP_CK_TYPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_COMPARISON" ADD CONSTRAINT "CHATBOT_DATASET_RULE_CMP_CK_TYPE" CHECK (comparison_type IN ('MOM','YOY','WOW','CUSTOM'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_CASE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_CASE" CHECK (case_mode IN ('NONE','UPPER','LOWER'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_JOIN';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_JOIN" CHECK (logic_join IN ('AND','OR'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_JSON" CHECK (value_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_OPERATOR';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_OPERATOR" CHECK (operator IN ('EQ','NEQ','LIKE','IN','GT','GTE','LT','LTE','BETWEEN','IS_NULL','IS_NOT_NULL','REGEXP'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_SCOPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_SCOPE" CHECK (field_scope IN ('TARGET_COLUMN','CUSTOM_COLUMN'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_COND_CK_VTYPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_CONDITIONS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_COND_CK_VTYPE" CHECK (value_type IN ('TEXT','NUMBER','DATE','JSON'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_KW_CK_MATCH_TYPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_KEYWORDS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_KW_CK_MATCH_TYPE" CHECK (match_type IN ('TOKEN','PHRASE','REGEX'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_OUT_CK_NAME';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_OUTPUTS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_OUT_CK_NAME" CHECK (output_name IN ('CURRENT','PREVIOUS','DELTA','PCT_CHANGE','CUSTOM'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_DATASET_RULE_TGT_CK_ACTIVE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_DATASET_RULE_TARGETS" ADD CONSTRAINT "CHATBOT_DATASET_RULE_TGT_CK_ACTIVE" CHECK (active_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_PARAM_META_RISK_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_PARAMETER_METADATA" ADD CONSTRAINT "CHATBOT_PARAM_META_RISK_CK" CHECK (
          UPPER(risk_if_changed) IN ('LOW','MEDIUM','HIGH','CRITICAL')
        );~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_FEEDBACK_CK_VALUE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_FEEDBACK" ADD CONSTRAINT "CHATBOT_RUN_FEEDBACK_CK_VALUE" CHECK (feedback_value IN (-1,0,1));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_CLARIFY';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_CLARIFY" CHECK (clarify_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_FALLBACK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_FALLBACK" CHECK (fallback_used_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_FIRST_PASS';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_FIRST_PASS" CHECK (first_pass_success_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_NO_SQL';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_NO_SQL" CHECK (no_sql_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_REPAIR';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_REPAIR" CHECK (repair_used_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_INSIGHTS_CK_SQL_GENERATED';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_INSIGHTS" ADD CONSTRAINT "CHATBOT_RUN_INSIGHTS_CK_SQL_GENERATED" CHECK (sql_generated_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_VALUE_RULES_CK_ACTIVE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_VALUE_RULES" ADD CONSTRAINT "CHATBOT_VALUE_RULES_CK_ACTIVE" CHECK (active_yn IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_VALUE_RULES_CK_EXTRA_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_VALUE_RULES" ADD CONSTRAINT "CHATBOT_VALUE_RULES_CK_EXTRA_JSON" CHECK (extra_keywords_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_VALUE_RULES_CK_MATCH_MODE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_VALUE_RULES" ADD CONSTRAINT "CHATBOT_VALUE_RULES_CK_MATCH_MODE" CHECK (match_mode IN ('ANY','ALL'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_VALUE_RULES_CK_MAX_VALUES';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_VALUE_RULES" ADD CONSTRAINT "CHATBOT_VALUE_RULES_CK_MAX_VALUES" CHECK (max_values BETWEEN 1 AND 500);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_VALUE_RULES_CK_VALUES_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_VALUE_RULES" ADD CONSTRAINT "CHATBOT_VALUE_RULES_CK_VALUES_JSON" CHECK (values_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_COMP_TAX_INC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_COMPUTE_SHAPE_TAXONOMY" ADD CONSTRAINT "OCI_CALC_COMP_TAX_INC_CK" CHECK (RUNTIME_INCLUDE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_COMP_TAX_REV_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_COMPUTE_SHAPE_TAXONOMY" ADD CONSTRAINT "OCI_CALC_COMP_TAX_REV_CK" CHECK (REVIEW_STATUS IN ('CANDIDATE','APPROVED','REJECTED','EXCLUDED'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_CONF_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_CONF_CK" CHECK (CONFIDENCE_SCORE IS NULL OR CONFIDENCE_SCORE BETWEEN 0 AND 100);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_SRC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_SRC_CK" CHECK (
          SOURCE_TYPE IN ('CURATED','ORACLE_TEMPLATE','ORACLE_PRESET','ORACLE_SHAPE','MANUAL','OVERRIDE')
        );~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_STATUS_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_STATUS_CK" CHECK (STATUS IN ('DRAFT','CANDIDATE','APPROVED','REJECTED','OVERRIDE'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_CONF_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_CONF_CK" CHECK (CONFIDENCE_SCORE IS NULL OR CONFIDENCE_SCORE BETWEEN 0 AND 100);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_DEF_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_DEF_CK" CHECK (DEFAULT_ENABLED_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_REQ_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_REQ_CK" CHECK (REQUIRED_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_SRC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_SRC_CK" CHECK (SOURCE_TYPE IN ('CURATED','ORACLE_TEMPLATE','ORACLE_PRESET','ORACLE_SHAPE','MANUAL','OVERRIDE'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFGDRV_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CFGDRV_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFGDRV_REQ_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CFGDRV_REQ_CK" CHECK (REQUIRED_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_DRIVER_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_DRIVER" ADD CONSTRAINT "OCI_CALC_DRIVER_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_DRIVER_TYPE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_DRIVER" ADD CONSTRAINT "OCI_CALC_DRIVER_TYPE_CK" CHECK (DATA_TYPE IN ('NUMBER','BOOLEAN','TEXT','SELECT'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_FAMILY_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_FAMILY" ADD CONSTRAINT "OCI_CALC_FAMILY_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_GENAI_TAX_INC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_GENAI_SKU_TAXONOMY" ADD CONSTRAINT "OCI_CALC_GENAI_TAX_INC_CK" CHECK (RUNTIME_INCLUDE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_GENAI_TAX_REV_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_GENAI_SKU_TAXONOMY" ADD CONSTRAINT "OCI_CALC_GENAI_TAX_REV_CK" CHECK (REVIEW_STATUS IN ('CANDIDATE','APPROVED','REJECTED','EXCLUDED'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_JSON_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_JSON_CK" CHECK (DETAILS_JSON IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_SEV_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_SEV_CK" CHECK (SEVERITY IN ('INFO','WARN','ERROR'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SERVICE_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SERVICE" ADD CONSTRAINT "OCI_CALC_SERVICE_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SERVICE_SRC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SERVICE" ADD CONSTRAINT "OCI_CALC_SERVICE_SRC_CK" CHECK (
          SOURCE_TYPE IN ('CURATED','ORACLE_TEMPLATE','ORACLE_PRESET','ORACLE_SHAPE','MANUAL','OVERRIDE')
        );~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_ACTIVE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_ACTIVE_CK" CHECK (ACTIVE_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_CONF_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_CONF_CK" CHECK (CONFIDENCE_SCORE IS NULL OR CONFIDENCE_SCORE BETWEEN 0 AND 100);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_FORMULA_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_FORMULA_CK" CHECK (
          QUANTITY_FORMULA_CODE IN (
            'FIXED',
            'DRIVER_VALUE',
            'DRIVER_TIMES_HOURS',
            'DRIVER_TIMES_DRIVER',
            'SUM_DRIVERS',
            'MAX_DRIVER',
            'TOKEN_QUANTITY',
            'CUSTOM_JSON'
          )
        );~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_JSON_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_JSON_CK" CHECK (FORMULA_JSON IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_REQ_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_REQ_CK" CHECK (REQUIRED_YN IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_SRC_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_SRC_CK" CHECK (
          SOURCE_TYPE IN ('CURATED','ORACLE_TEMPLATE','ORACLE_PRESET','ORACLE_SHAPE','MANUAL','OVERRIDE')
        );~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_STATUS_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_STATUS_CK" CHECK (STATUS IN ('CANDIDATE','APPROVED','REJECTED','OVERRIDE'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PROD_PRESET_CAT_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESETS" ADD CONSTRAINT "OCI_PROD_PRESET_CAT_JSON" CHECK (categories_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PROD_PRESET_ITEMS_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESETS" ADD CONSTRAINT "OCI_PROD_PRESET_ITEMS_JSON" CHECK (preset_items_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PROD_PRESET_SHAPES_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESETS" ADD CONSTRAINT "OCI_PROD_PRESET_SHAPES_JSON" CHECK (preset_shapes_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_PROD_PRESET_TAGS_JSON';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRODUCT_PRESETS" ADD CONSTRAINT "OCI_PROD_PRESET_TAGS_JSON" CHECK (tags_json IS JSON);~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDC_ENABLED_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_CATALOG" ADD CONSTRAINT "RGDC_ENABLED_CK" CHECK (ENABLED_FLAG IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDC_STATUS_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_CATALOG" ADD CONSTRAINT "RGDC_STATUS_CK" CHECK (COVERAGE_STATUS IN ('READY','PARTIAL','PLANNED'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDR_ENABLED_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_RULES" ADD CONSTRAINT "RGDR_ENABLED_CK" CHECK (ENABLED_FLAG IN ('Y','N'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RGDR_TYPE_CK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_DOMAIN_RULES" ADD CONSTRAINT "RGDR_TYPE_CK" CHECK (RULE_TYPE IN ('NODE_CATEGORY','NODE_TYPE_LIKE','NODE_ID_LIKE','EDGE_PROVENANCE','EDGE_SUBTYPE_LIKE','CANONICAL_PATH'));~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_GENERIC_LOG_CONV_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_GENERIC_LOG" ADD CONSTRAINT "CHATBOT_GENERIC_LOG_CONV_FK" FOREIGN KEY ("CHAT_ID")
	  REFERENCES "CHATBOT_GENERIC_CONVERSATION" ("CHAT_ID") ON DELETE CASCADE;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'FK_CILS_RUN';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_INSIGHTS_LOOP_STEP" ADD CONSTRAINT "FK_CILS_RUN" FOREIGN KEY ("INSIGHTS_RUN_ID")
	  REFERENCES "CHATBOT_INSIGHTS_RUN" ("INSIGHTS_RUN_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_NL2SQL_LOG_CONV_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_NL2SQL_LOG" ADD CONSTRAINT "CHATBOT_NL2SQL_LOG_CONV_FK" FOREIGN KEY ("CHAT_ID")
	  REFERENCES "CHATBOT_NL2SQL_CONVERSATION" ("CHAT_ID") ON DELETE CASCADE;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_PARAMS_META_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_PARAMETERS" ADD CONSTRAINT "CHATBOT_PARAMS_META_FK" FOREIGN KEY ("COMPONENT_TYPE")
	  REFERENCES "CHATBOT_PARAMETER_METADATA" ("COMPONENT_TYPE") ENABLE NOVALIDATE;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'CHATBOT_RUN_FEEDBACK_LOG_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "CHATBOT_RUN_FEEDBACK" ADD CONSTRAINT "CHATBOT_RUN_FEEDBACK_LOG_FK" FOREIGN KEY ("LOG_ID")
	  REFERENCES "CHATBOT_NL2SQL_LOG" ("ID") ON DELETE CASCADE;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'DEPLOY_APPLIED_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_APPLIED" ADD CONSTRAINT "DEPLOY_APPLIED_FK" FOREIGN KEY ("BUNDLE_ID")
	  REFERENCES "DEPLOY_BUNDLES" ("BUNDLE_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'DEPLOY_RUNS_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "DEPLOY_RUNS" ADD CONSTRAINT "DEPLOY_RUNS_FK" FOREIGN KEY ("BUNDLE_ID")
	  REFERENCES "DEPLOY_BUNDLES" ("BUNDLE_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CONFIG_SERVICE_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIGURATION" ADD CONSTRAINT "OCI_CALC_CONFIG_SERVICE_FK" FOREIGN KEY ("SERVICE_ID")
	  REFERENCES "OCI_CALC_SERVICE" ("SERVICE_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_CHILD_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_CHILD_FK" FOREIGN KEY ("CHILD_CONFIG_ID")
	  REFERENCES "OCI_CALC_CONFIGURATION" ("CONFIG_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFG_DEP_PARENT_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DEPENDENCY" ADD CONSTRAINT "OCI_CALC_CFG_DEP_PARENT_FK" FOREIGN KEY ("PARENT_CONFIG_ID")
	  REFERENCES "OCI_CALC_CONFIGURATION" ("CONFIG_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFGDRV_CONFIG_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CFGDRV_CONFIG_FK" FOREIGN KEY ("CONFIG_ID")
	  REFERENCES "OCI_CALC_CONFIGURATION" ("CONFIG_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_CFGDRV_DRIVER_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_CONFIG_DRIVER" ADD CONSTRAINT "OCI_CALC_CFGDRV_DRIVER_FK" FOREIGN KEY ("DRIVER_ID")
	  REFERENCES "OCI_CALC_DRIVER" ("DRIVER_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_CFG_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_CFG_FK" FOREIGN KEY ("CONFIG_ID")
	  REFERENCES "OCI_CALC_CONFIGURATION" ("CONFIG_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_FAM_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_FAM_FK" FOREIGN KEY ("FAMILY_ID")
	  REFERENCES "OCI_CALC_FAMILY" ("FAMILY_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_RULE_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_RULE_FK" FOREIGN KEY ("SKU_RULE_ID")
	  REFERENCES "OCI_CALC_SKU_RULE" ("SKU_RULE_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_RULE_DIAG_SVC_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_RULE_DIAGNOSTIC" ADD CONSTRAINT "OCI_CALC_RULE_DIAG_SVC_FK" FOREIGN KEY ("SERVICE_ID")
	  REFERENCES "OCI_CALC_SERVICE" ("SERVICE_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SERVICE_FAM_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SERVICE" ADD CONSTRAINT "OCI_CALC_SERVICE_FAM_FK" FOREIGN KEY ("FAMILY_ID")
	  REFERENCES "OCI_CALC_FAMILY" ("FAMILY_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_CONFIG_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_CONFIG_FK" FOREIGN KEY ("CONFIG_ID")
	  REFERENCES "OCI_CALC_CONFIGURATION" ("CONFIG_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_DRV1_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_DRV1_FK" FOREIGN KEY ("PRIMARY_DRIVER_ID")
	  REFERENCES "OCI_CALC_DRIVER" ("DRIVER_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_DRV2_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_DRV2_FK" FOREIGN KEY ("SECONDARY_DRIVER_ID")
	  REFERENCES "OCI_CALC_DRIVER" ("DRIVER_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_CALC_SKU_RULE_DRV3_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_CALC_SKU_RULE" ADD CONSTRAINT "OCI_CALC_SKU_RULE_DRV3_FK" FOREIGN KEY ("TERTIARY_DRIVER_ID")
	  REFERENCES "OCI_CALC_DRIVER" ("DRIVER_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'OCI_FK_PSP_SHAPE';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "OCI_PRESET_SHAPE_PRODUCT" ADD CONSTRAINT "OCI_FK_PSP_SHAPE" FOREIGN KEY ("PRESET_ID", "SHAPE_ID")
	  REFERENCES "OCI_PRESET_SHAPE" ("PRESET_ID", "SHAPE_ID") ON DELETE CASCADE;~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_EDGES_SNAP_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_EDGES" ADD CONSTRAINT "RG_EDGES_SNAP_FK" FOREIGN KEY ("SNAPSHOT_ID")
	  REFERENCES "RESOURCE_GRAPH_SNAPSHOTS" ("SNAPSHOT_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_FILTERS_SNAP_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_FILTERS" ADD CONSTRAINT "RG_FILTERS_SNAP_FK" FOREIGN KEY ("SNAPSHOT_ID")
	  REFERENCES "RESOURCE_GRAPH_SNAPSHOTS" ("SNAPSHOT_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_NODES_SNAP_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_NODES" ADD CONSTRAINT "RG_NODES_SNAP_FK" FOREIGN KEY ("SNAPSHOT_ID")
	  REFERENCES "RESOURCE_GRAPH_SNAPSHOTS" ("SNAPSHOT_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_NODE_FACTS_SNAP_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_NODE_FACTS" ADD CONSTRAINT "RG_NODE_FACTS_SNAP_FK" FOREIGN KEY ("SNAPSHOT_ID")
	  REFERENCES "RESOURCE_GRAPH_SNAPSHOTS" ("SNAPSHOT_ID");~';
  END IF;
END;
/

DECLARE
  l_cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO l_cnt FROM user_constraints WHERE constraint_name = 'RG_SCOPE_NODES_SNAP_FK';
  IF l_cnt = 0 THEN
    EXECUTE IMMEDIATE q'~
  ALTER TABLE "RESOURCE_GRAPH_SCOPE_NODES" ADD CONSTRAINT "RG_SCOPE_NODES_SNAP_FK" FOREIGN KEY ("SNAPSHOT_ID")
	  REFERENCES "RESOURCE_GRAPH_SNAPSHOTS" ("SNAPSHOT_ID");~';
  END IF;
END;
/

