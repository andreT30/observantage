
  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_DAILY_HTML" (
    p_tenant             in varchar2,
    p_subscription_id    in varchar2,
    p_region             in varchar2,
    p_compartment        in varchar2,
    p_service_category   in varchar2,
    p_service_name       in varchar2,
    p_charge_description in varchar2,
    p_resource_type      in varchar2,
    p_resource_name      in varchar2,
    p_fromdate           in varchar2,
    p_todate             in varchar2,
    p_group_level1       in varchar2,
    p_group_level2       in varchar2,
    p_group_level3       in varchar2
) return clob
is
    v_html         clob := '';
    v_key          varchar2(1000);
    v_cost         number := 0;
    v_sql          clob;

    type rc is ref cursor;

    type pivot_map_type is table of number index by varchar2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    type t_header_row is table of varchar2(1000) index by pls_integer;

    v_lvl1_col     varchar2(100);
    v_lvl2_col     varchar2(100);
    v_lvl3_col     varchar2(100);

    v_lvl1_map     t_header_row;
    v_lvl2_map     t_header_row;
    v_lvl3_map     t_header_row;
    v_columns      t_header_row;
    v_idx          integer := 0;

    v_group_cursor rc;
    v_cursor       rc;

    -- Track previous day's cost per column (for highlighting)
    v_prev_costs   pivot_map_type;
    l_prev_cost    number;
    l_delta        number;
    l_delta_pct    number;
    l_style        varchar2(200);
    l_cost_text    varchar2(100);

    cursor cur_dates is
        select distinct to_char(date_bucket, 'DD-Mon') as day_label, date_bucket
        from cost_usage_timeseries_daily
        where date_bucket between to_date(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              and to_date(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        order by date_bucket;

    function add_filter(col_name varchar2, param_val varchar2) return varchar2 is
    begin
        if param_val is null or trim(param_val) is null then
            return '';
        else
            return ' and ' || col_name || ' in ('
                || ' select trim(column_value)'
                || ' from table(apex_string.split(''' || replace(param_val, '''', '''''') || ''', '',''))'
                || ' )';
        end if;
    end;

    -- NEW: apply same list to either OCI_COMPARTMENTID or COSTCENTER (scoped OR)
    function add_filter_or2(p_col1 varchar2, p_col2 varchar2, p_param_val varchar2) return varchar2 is
        l_esc varchar2(32767);
    begin
        if p_param_val is null or trim(p_param_val) is null then
            return '';
        end if;

        l_esc := replace(p_param_val, '''', '''''');

        return ' and ('
            || p_col1 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ' or '
            || p_col2 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ')';
    end;

begin
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- HTML Table Start
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1"><thead><tr><th class="pivot-day-col" rowspan="3">Day</th>';

    -- Build dynamic SQL for columns
    v_sql := 'select distinct nvl(' || v_lvl1_col || ', ''None''), nvl(' || v_lvl2_col || ', ''Unknown''), nvl(' || v_lvl3_col || ', ''Unknown'') '
          || 'from cost_usage_timeseries_daily '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' order by 1, 2, 3';

    open v_group_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_group_cursor into v_lvl1_map(v_idx + 1), v_lvl2_map(v_idx + 1), v_lvl3_map(v_idx + 1);
        exit when v_group_cursor%notfound;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    end loop;
    close v_group_cursor;

    -- Header Rows
    declare
        type temp_map is table of integer index by varchar2(500);
        v_colspan_map temp_map;
        col_key varchar2(500);
    begin
        for i in 1 .. v_idx loop
            col_key := v_lvl1_map(i);
            if v_colspan_map.exists(col_key) then
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            else
                v_colspan_map(col_key) := 1;
            end if;
        end loop;

        col_key := v_colspan_map.first;
        while col_key is not null loop
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.next(col_key);
        end loop;
    end;

    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr></thead><tbody>';

    -- Build pivot data
    v_sql := 'select to_char(date_bucket, ''DD-Mon'') || ''|'' ||'
          || '       nvl(' || v_lvl1_col || ', ''None'') || ''|'' ||'
          || '       nvl(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||'
          || '       nvl(' || v_lvl3_col || ', ''Unknown'') as map_key,'
          || '       sum(cost) '
          || 'from cost_usage_timeseries_daily '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' group by to_char(date_bucket, ''DD-Mon''),'
          || '          nvl(' || v_lvl1_col || ', ''None''),'
          || '          nvl(' || v_lvl2_col || ', ''Unknown''),'
          || '          nvl(' || v_lvl3_col || ', ''Unknown'')';

    open v_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_cursor into v_key, v_cost;
        exit when v_cursor%notfound;
        v_data_map(v_key) := v_cost;
    end loop;
    close v_cursor;

    -- Output data rows
    for date_rec in cur_dates loop
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.day_label || '</td>';

        for i in 1 .. v_idx loop
            v_key := date_rec.day_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);

            -- Current cost
            v_cost := case
                        when v_data_map.exists(v_key) then v_data_map(v_key)
                        else 0
                      end;

            -- Previous day's cost for this column (if any)
            l_prev_cost := null;
            if v_prev_costs.exists(v_columns(i)) then
                l_prev_cost := v_prev_costs(v_columns(i));
            end if;

            -- Store current as "previous" for next day
            v_prev_costs(v_columns(i)) := v_cost;

            l_style := null;

            -- Compute % change vs previous day and decide color
            if l_prev_cost is not null and l_prev_cost > 0 then
                l_delta     := v_cost - l_prev_cost;
                l_delta_pct := l_delta / l_prev_cost;

                if abs(l_delta_pct) >= 0.10 then
                    if l_delta_pct > 0 then
                        l_style := ' class="pivot-cell-up"';
                    else
                        l_style := ' class="pivot-cell-down"';
                    end if;
                end if;
            end if;

            -- Format cost
            l_cost_text := case
                             when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                             else to_char(v_cost, 'FM999G999G999G990D00')
                           end;

            -- Emit cell with optional style
            v_html := v_html || '<td' || nvl(l_style, '') || '>' || l_cost_text || '</td>';

            -- Accumulate column totals
            if v_totals.exists(v_columns(i)) then
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            else
                v_totals(v_columns(i)) := v_cost;
            end if;
        end loop;

        v_html := v_html || '</tr>';
    end loop;

    -- Totals row
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    for i in 1 .. v_idx loop
        v_cost := nvl(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>' || case
                                            when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                                            else to_char(v_cost, 'FM999G999G999G990D00')
                                         end || '</b></td>';
    end loop;
    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    return v_html;
end;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_MONTHLY_HTML" (
    p_tenant             in varchar2,
    p_subscription_id    in varchar2,
    p_region             in varchar2,
    p_compartment        in varchar2,
    p_service_category   in varchar2,
    p_service_name       in varchar2,
    p_charge_description in varchar2,
    p_resource_type      in varchar2,
    p_resource_name      in varchar2,
    p_fromdate           in varchar2,
    p_todate             in varchar2,
    p_group_level1       in varchar2,
    p_group_level2       in varchar2,
    p_group_level3       in varchar2
) return clob
is
    v_html         clob := '';
    v_key          varchar2(1000);
    v_cost         number := 0;
    v_sql          clob;

    type rc is ref cursor;

    type pivot_map_type is table of number index by varchar2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    type t_header_row is table of varchar2(1000) index by pls_integer;

    v_lvl1_col     varchar2(100);
    v_lvl2_col     varchar2(100);
    v_lvl3_col     varchar2(100);

    v_lvl1_map     t_header_row;
    v_lvl2_map     t_header_row;
    v_lvl3_map     t_header_row;
    v_columns      t_header_row;
    v_idx          integer := 0;

    v_group_cursor rc;
    v_cursor       rc;

    cursor cur_dates is
        select distinct to_char(trunc(date_bucket, 'MM'), 'Mon YYYY') as month_label,
                        trunc(date_bucket, 'MM') as month_bucket
        from cost_usage_timeseries_monthly
        where date_bucket between to_date(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              and to_date(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        order by 2;

    function add_filter(col_name varchar2, param_val varchar2) return varchar2 is
    begin
        if param_val is null or trim(param_val) is null then
            return '';
        else
            return ' and ' || col_name || ' in ('
                || ' select trim(column_value)'
                || ' from table(apex_string.split(''' || replace(param_val, '''', '''''') || ''', '',''))'
                || ' )';
        end if;
    end;

    -- NEW: apply same list to either OCI_COMPARTMENTID or COSTCENTER (scoped OR)
    function add_filter_or2(p_col1 varchar2, p_col2 varchar2, p_param_val varchar2) return varchar2 is
        l_esc varchar2(32767);
    begin
        if p_param_val is null or trim(p_param_val) is null then
            return '';
        end if;

        l_esc := replace(p_param_val, '''', '''''');

        return ' and ('
            || p_col1 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ' or '
            || p_col2 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ')';
    end;

begin
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1">'
           || '<thead><tr><th class="pivot-day-col" rowspan="3">Month</th>';

    -- Build column headers
    v_sql := 'select distinct nvl(' || v_lvl1_col || ', ''None''), '
          || '               nvl(' || v_lvl2_col || ', ''Unknown''), '
          || '               nvl(' || v_lvl3_col || ', ''Unknown'') '
          || 'from cost_usage_timeseries_monthly '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') '
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' order by 1, 2, 3';

    open v_group_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_group_cursor into v_lvl1_map(v_idx + 1),
                                v_lvl2_map(v_idx + 1),
                                v_lvl3_map(v_idx + 1);
        exit when v_group_cursor%notfound;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    end loop;
    close v_group_cursor;

    -- Header row level 1
    declare
        type temp_map is table of integer index by varchar2(500);
        v_colspan_map temp_map;
        col_key varchar2(500);
    begin
        for i in 1 .. v_idx loop
            col_key := v_lvl1_map(i);
            if v_colspan_map.exists(col_key) then
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            else
                v_colspan_map(col_key) := 1;
            end if;
        end loop;

        col_key := v_colspan_map.first;
        while col_key is not null loop
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.next(col_key);
        end loop;
    end;

    -- Header level 2
    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    end loop;

    -- Header level 3
    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr></thead><tbody>';

    -- Pivot data
    v_sql := 'select to_char(trunc(date_bucket, ''MM''), ''Mon YYYY'') || ''|'' ||'
          || '       nvl(' || v_lvl1_col || ', ''None'') || ''|'' ||'
          || '       nvl(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||'
          || '       nvl(' || v_lvl3_col || ', ''Unknown'') as map_key,'
          || '       sum(cost) '
          || 'from cost_usage_timeseries_monthly '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') '
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' group by trunc(date_bucket, ''MM''),'
          || '          nvl(' || v_lvl1_col || ', ''None''),'
          || '          nvl(' || v_lvl2_col || ', ''Unknown''),'
          || '          nvl(' || v_lvl3_col || ', ''Unknown'')';

    open v_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_cursor into v_key, v_cost;
        exit when v_cursor%notfound;
        v_data_map(v_key) := v_cost;
    end loop;
    close v_cursor;

    -- Data rows
    for date_rec in cur_dates loop
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.month_label || '</td>';

        for i in 1 .. v_idx loop
            v_key := date_rec.month_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);

            v_cost := case
                        when v_data_map.exists(v_key) then v_data_map(v_key)
                        else 0
                      end;

            v_html := v_html || '<td>'
                  || case
                        when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                        else to_char(v_cost, 'FM999G999G999G990D00')
                     end
                  || '</td>';

            if v_totals.exists(v_columns(i)) then
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            else
                v_totals(v_columns(i)) := v_cost;
            end if;
        end loop;

        v_html := v_html || '</tr>';
    end loop;

    -- Totals row
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    for i in 1 .. v_idx loop
        v_cost := nvl(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>'
              || case
                    when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                    else to_char(v_cost, 'FM999G999G999G990D00')
                 end
              || '</b></td>';
    end loop;

    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    return v_html;
end;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "COST_PIVOT_DYNAMIC_WEEKLY_HTML" (
    p_tenant             in varchar2,
    p_subscription_id    in varchar2,
    p_region             in varchar2,
    p_compartment        in varchar2,
    p_service_category   in varchar2,
    p_service_name       in varchar2,
    p_charge_description in varchar2,
    p_resource_type      in varchar2,
    p_resource_name      in varchar2,
    p_fromdate           in varchar2,
    p_todate             in varchar2,
    p_group_level1       in varchar2,
    p_group_level2       in varchar2,
    p_group_level3       in varchar2
) return clob
is
    v_html         clob := '';
    v_key          varchar2(1000);
    v_cost         number := 0;
    v_sql          clob;

    type rc is ref cursor;

    type pivot_map_type is table of number index by varchar2(1000);
    v_data_map     pivot_map_type;
    v_totals       pivot_map_type;

    type t_header_row is table of varchar2(1000) index by pls_integer;

    v_lvl1_col     varchar2(100);
    v_lvl2_col     varchar2(100);
    v_lvl3_col     varchar2(100);

    v_lvl1_map     t_header_row;
    v_lvl2_map     t_header_row;
    v_lvl3_map     t_header_row;
    v_columns      t_header_row;
    v_idx          integer := 0;

    v_group_cursor rc;
    v_cursor       rc;

    cursor cur_dates is
        select distinct to_char(date_bucket, 'DD-Mon') || ' (W' || to_char(date_bucket, 'IW') || ')' as week_label,
                        date_bucket
        from cost_usage_timeseries_weekly
        where date_bucket between to_date(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              and to_date(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        order by date_bucket;

    function add_filter(col_name varchar2, param_val varchar2) return varchar2 is
    begin
        if param_val is null or trim(param_val) is null then
            return '';
        else
            return ' and ' || col_name || ' in ('
                || ' select trim(column_value)'
                || ' from table(apex_string.split(''' || replace(param_val, '''', '''''') || ''', '',''))'
                || ' )';
        end if;
    end;

    -- NEW: apply same list to either OCI_COMPARTMENTID or COSTCENTER (scoped OR)
    function add_filter_or2(p_col1 varchar2, p_col2 varchar2, p_param_val varchar2) return varchar2 is
        l_esc varchar2(32767);
    begin
        if p_param_val is null or trim(p_param_val) is null then
            return '';
        end if;

        l_esc := replace(p_param_val, '''', '''''');

        return ' and ('
            || p_col1 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ' or '
            || p_col2 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ')';
    end;

begin
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1">'
           || '<thead><tr><th class="pivot-day-col" rowspan="3">Week</th>';

    -- Distinct column headers
    v_sql := 'select distinct nvl(' || v_lvl1_col || ', ''None''), '
          || '               nvl(' || v_lvl2_col || ', ''Unknown''), '
          || '               nvl(' || v_lvl3_col || ', ''Unknown'') '
          || 'from cost_usage_timeseries_weekly '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') '
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' order by 1, 2, 3';

    open v_group_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_group_cursor into v_lvl1_map(v_idx + 1),
                                v_lvl2_map(v_idx + 1),
                                v_lvl3_map(v_idx + 1);
        exit when v_group_cursor%notfound;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    end loop;
    close v_group_cursor;

    -- Header: Level 1
    declare
        type temp_map is table of integer index by varchar2(500);
        v_colspan_map temp_map;
        col_key varchar2(500);
    begin
        for i in 1 .. v_idx loop
            col_key := v_lvl1_map(i);
            if v_colspan_map.exists(col_key) then
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            else
                v_colspan_map(col_key) := 1;
            end if;
        end loop;

        col_key := v_colspan_map.first;
        while col_key is not null loop
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.next(col_key);
        end loop;
    end;

    -- Header: Level 2 and 3
    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr></thead><tbody>';

    -- Load pivot data
    v_sql := 'select to_char(date_bucket, ''DD-Mon'') || '' (W'' || to_char(date_bucket, ''IW'') || '')'' || ''|'' ||'
          || '       nvl(' || v_lvl1_col || ', ''None'') || ''|'' ||'
          || '       nvl(' || v_lvl2_col || ', ''Unknown'') || ''|'' ||'
          || '       nvl(' || v_lvl3_col || ', ''Unknown'') as map_key,'
          || '       sum(cost) '
          || 'from cost_usage_timeseries_weekly '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'') '
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'') '
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' group by to_char(date_bucket, ''DD-Mon''),'
          || '          to_char(date_bucket, ''IW''),'
          || '          nvl(' || v_lvl1_col || ', ''None''),'
          || '          nvl(' || v_lvl2_col || ', ''Unknown''),'
          || '          nvl(' || v_lvl3_col || ', ''Unknown'')';

    open v_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_cursor into v_key, v_cost;
        exit when v_cursor%notfound;
        v_data_map(v_key) := v_cost;
    end loop;
    close v_cursor;

    -- Output data rows
    for date_rec in cur_dates loop
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.week_label || '</td>';

        for i in 1 .. v_idx loop
            v_key := date_rec.week_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);

            v_cost := case
                        when v_data_map.exists(v_key) then v_data_map(v_key)
                        else 0
                      end;

            v_html := v_html || '<td>'
                  || case
                        when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                        else to_char(v_cost, 'FM999G999G999G990D00')
                     end
                  || '</td>';

            if v_totals.exists(v_columns(i)) then
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_cost;
            else
                v_totals(v_columns(i)) := v_cost;
            end if;
        end loop;

        v_html := v_html || '</tr>';
    end loop;

    -- Totals row
    v_html := v_html || '<tr><td class="pivot-day-col"><b>Total</b></td>';
    for i in 1 .. v_idx loop
        v_cost := nvl(v_totals(v_columns(i)), 0);
        v_html := v_html || '<td><b>'
              || case
                    when v_cost < 1 then '0' || to_char(v_cost, 'FM.00')
                    else to_char(v_cost, 'FM999G999G999G990D00')
                 end
              || '</b></td>';
    end loop;

    v_html := v_html || '</tr>';

    v_html := v_html || '</tbody></table></div>';
    return v_html;
end;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "IN_GROUP_CODE" (p_group_code VARCHAR2)
RETURN BOOLEAN
IS
  l_apex_group fr_authz_groups.apex_group%TYPE;
  l_sso_group  fr_authz_groups.sso_group%TYPE;
BEGIN
  SELECT apex_group, sso_group
    INTO l_apex_group, l_sso_group
    FROM fr_authz_groups
   WHERE group_code = p_group_code;
  RETURN session_in_group(l_apex_group, l_sso_group);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN FALSE;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "JSON_ESCAPE" (p_text IN VARCHAR2) RETURN VARCHAR2 IS
  l_result VARCHAR2(32767);
BEGIN
  l_result := REPLACE(p_text, '\', '\\');        -- escape backslashes
  l_result := REPLACE(l_result, '"', '\"');      -- escape double quotes
  l_result := REPLACE(l_result, CHR(10), '\n');  -- line feed
  l_result := REPLACE(l_result, CHR(13), '');    -- carriage return
  RETURN l_result;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "LLM_CALL_TEXT" (
    p_message        in  clob,
    p_model_id       in  varchar2,
    p_compartment_id in  varchar2
) return clob
as
  l_region              varchar2(50);
  l_model_cfg_model_id  varchar2(1000);
  l_api_format          varchar2(50);
  l_temperature         number;
  l_top_p               number;
  l_top_k               number;
  l_endpoint            varchar2(1000);
  l_payload             clob;
  l_resp                dbms_cloud_types.resp;
  l_body_json           clob;
  l_text                clob;
  -- helpers
  function clob_to_blob_utf8(p_clob in clob) return blob is
    l_blob        blob;
    l_dest_offset integer := 1;
    l_src_offset  integer := 1;
    l_lang_ctx    integer := 0;
    l_warning     integer := 0;
  begin
    dbms_lob.createtemporary(l_blob, true);
    dbms_lob.convertToBlob(
      dest_lob     => l_blob,
      src_clob     => p_clob,
      amount       => dbms_lob.lobmaxsize,
      dest_offset  => l_dest_offset,
      src_offset   => l_src_offset,
      blob_csid    => nls_charset_id('AL32UTF8'),
      lang_context => l_lang_ctx,
      warning      => l_warning
    );
    return l_blob;
  end;
  -- extract text robustly from OCI chat response
  function extract_text(p_json in clob) return clob is
    jo   json_object_t;
    cr   json_object_t;
    txt  clob;
  begin
    jo := json_object_t.parse(p_json);
    -- error payload?
    if jo.has('error') then
      raise_application_error(-20990,
        'OCI GenAI error: '||substr(p_json,1,2000));
    end if;
    if not jo.has('chatResponse') then
      return null;
    end if;
    cr := jo.get_object('chatResponse');
    -- Cohere-style single string
    if cr.has('text') then
      txt := cr.get_string('text');
      if txt is not null and trim(txt) is not null then
        return txt;
      end if;
    end if;
    -- Generic-style choices[0].message.content[*].text (concatenate TEXT parts)
    if cr.has('choices') then
      declare
        ca   json_array_t := cr.get_array('choices');
        ch   json_object_t;
        msg  json_object_t;
        cont json_array_t;
        i    pls_integer;
        part json_object_t;
        acc  clob := empty_clob();
      begin
        if ca.get_size > 0 then
          ch := treat(ca.get(0) as json_object_t);
          if ch.has('message') then
            msg := treat(ch.get('message') as json_object_t);
            if msg.has('content') then
              cont := treat(msg.get('content') as json_array_t);
              i := 0;
              while i < cont.get_size loop
                part := treat(cont.get(i) as json_object_t);
                if part.has('type') and upper(part.get_string('type')) = 'TEXT' then
                  acc := acc || part.get_string('text');
                end if;
                i := i + 1;
              end loop;
              if acc is not null and trim(acc) is not null then
                return acc;
              end if;
            end if;
          end if;
        end if;
      exception when others then
        null;
      end;
    end if;
    -- fallback: sometimes providers put text under output_text
    if cr.has('output_text') then
      txt := cr.get_string('output_text');
    end if;
    return txt;
  exception
    when others then
      -- if parsing failed, surface raw body for troubleshooting
      raise_application_error(-20991,
        'Failed to parse chat response: '||substr(p_json,1,2000));
  end;
begin
  -- 1) Load model config
  select region, model_id, api_format,
         nvl(temperature,1), nvl(top_p,1), nvl(top_k,1)
    into l_region, l_model_cfg_model_id, l_api_format,
         l_temperature, l_top_p, l_top_k
    from ai_model_config
   where model_id = p_model_id;
  l_endpoint :=
    'https://inference.generativeai.'||lower(l_region)||
    '.oci.oraclecloud.com/20231130/actions/chat';
  -- 2) Build payload (one-turn chat)
  if upper(l_api_format) = 'GENERIC' then
    l_payload :=
      json_object(
        'compartmentId' value p_compartment_id,
        'servingMode' value json_object(
          'modelId' value l_model_cfg_model_id,
          'servingType' value 'ON_DEMAND'
        ),
        'chatRequest' value json_object(
          'apiFormat' value 'GENERIC',
          'maxTokens' value 3999,
          'temperature' value l_temperature,
          'topP' value l_top_p,
          'topK' value l_top_k,
          'messages' value json_array(
            json_object(
              'role' value 'USER',
              'content' value json_array(
                json_object('type' value 'TEXT', 'text' value p_message)
              )
            )
          )
        )
      );
  else
    l_payload :=
      json_object(
        'compartmentId' value p_compartment_id,
        'servingMode' value json_object(
          'modelId' value l_model_cfg_model_id,
          'servingType' value 'ON_DEMAND'
        ),
        'chatRequest' value json_object(
          'apiFormat' value 'COHERE',
          'maxTokens' value 3999,
          'temperature' value l_temperature,
          'topP' value l_top_p,
          'topK' value l_top_k,
          'message' value p_message
        )
      );
  end if;
  -- 3) Call OCI GenAI endpoint (UTF-8 body)
  l_resp := dbms_cloud.send_request(
    credential_name => 'OCI$RESOURCE_PRINCIPAL',
    uri             => l_endpoint,
    method          => 'POST',
    headers         => json_object('Content-Type' value 'application/json'),
    body            => clob_to_blob_utf8(l_payload)
  );
  l_body_json := dbms_cloud.get_response_text(l_resp);
  -- 4) Robust extraction
  l_text := extract_text(l_body_json);
  if l_text is null or trim(l_text) is null then
    -- surface the body for troubleshooting
    raise_application_error(-20992,
      'Empty assistant text. Body: '||substr(l_body_json,1,2000));
  end if;
  return l_text;
end;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "SESSION_IN_GROUP" (
  p_apex_group VARCHAR2,
  p_sso_group  VARCHAR2
) RETURN BOOLEAN
IS
  l_scheme VARCHAR2(100);
  l_dummy  NUMBER;
BEGIN
  SELECT authentication_scheme
    INTO l_scheme
    FROM apex_applications
   WHERE application_id = TO_NUMBER(v('APP_ID'));
  IF l_scheme = 'Oracle APEX Accounts' THEN
    RETURN apex_util.current_user_in_group(p_apex_group);
  ELSIF l_scheme = 'OCI SSO' THEN
    BEGIN
      SELECT 1
        INTO l_dummy
        FROM apex_workspace_session_groups
       WHERE apex_session_id = TO_NUMBER(v('APP_SESSION'))
         AND group_name      = p_sso_group;
      RETURN TRUE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
    END;
  END IF;
  RETURN FALSE;
END;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "URL_ENCODE" (
    P_STR IN VARCHAR2
) RETURN VARCHAR2 IS
BEGIN
    RETURN SYS.UTL_URL.ESCAPE(
        URL                   => P_STR,
        ESCAPE_RESERVED_CHARS => TRUE,
        URL_CHARSET           => 'AL32UTF8'
    );
END URL_ENCODE;
/

  CREATE OR REPLACE EDITIONABLE FUNCTION "USAGE_PIVOT_DYNAMIC_DAILY_HTML" (
    p_tenant             in varchar2,
    p_subscription_id    in varchar2,
    p_region             in varchar2,
    p_compartment        in varchar2,
    p_service_category   in varchar2,
    p_service_name       in varchar2,
    p_charge_description in varchar2,
    p_resource_type      in varchar2,
    p_resource_name      in varchar2,
    p_fromdate           in varchar2,
    p_todate             in varchar2,
    p_group_level1       in varchar2,
    p_group_level2       in varchar2,
    p_group_level3       in varchar2
) return clob
is
    v_html          clob := '';
    v_key           varchar2(1000);
    v_usage         number := 0;
    v_sql           clob;

    type rc is ref cursor;

    type pivot_map_type is table of number index by varchar2(1000);
    v_data_map      pivot_map_type;
    v_totals        pivot_map_type;

    type t_header_row is table of varchar2(1000) index by pls_integer;

    v_lvl1_col      varchar2(100);
    v_lvl2_col      varchar2(100);
    v_lvl3_col      varchar2(100);

    v_lvl1_map      t_header_row;
    v_lvl2_map      t_header_row;
    v_lvl3_map      t_header_row;
    v_columns       t_header_row;
    v_idx           integer := 0;

    v_group_cursor  rc;
    v_cursor        rc;

    cursor cur_dates is
        select distinct to_char(date_bucket, 'DD-Mon') as day_label, date_bucket
        from cost_usage_timeseries_daily
        where date_bucket between to_date(p_fromdate, 'DD-MON-YYYY HH24:MI:SS')
                              and to_date(p_todate,   'DD-MON-YYYY HH24:MI:SS')
        order by date_bucket;

    function add_filter(col_name varchar2, param_val varchar2) return varchar2 is
    begin
        if param_val is null or trim(param_val) is null then
            return '';
        else
            return ' and ' || col_name || ' in ('
                || ' select trim(column_value)'
                || ' from table(apex_string.split(''' || replace(param_val, '''', '''''') || ''', '',''))'
                || ' )';
        end if;
    end;

    -- NEW: one parameter applies to either column (OCI_COMPARTMENTID OR COSTCENTER)
    function add_filter_or2(p_col1 varchar2, p_col2 varchar2, p_param_val varchar2) return varchar2 is
        l_esc varchar2(32767);
    begin
        if p_param_val is null or trim(p_param_val) is null then
            return '';
        end if;

        l_esc := replace(p_param_val, '''', '''''');

        return ' and ('
            || p_col1 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ' or '
            || p_col2 || ' in ('
            || '   select trim(column_value)'
            || '   from table(apex_string.split(''' || l_esc || ''', '',''))'
            || ' )'
            || ')';
    end;

begin
    v_lvl1_col := p_group_level1;
    v_lvl2_col := p_group_level2;
    v_lvl3_col := p_group_level3;

    -- HTML Table Start
    v_html := '<div class="pivot-scroll"><table id="pivot-table" class="pivot-table" border="1"><thead><tr>'
           || '<th class="pivot-day-col" rowspan="3">Day</th>';

    -- Build dynamic SQL for columns
    v_sql := 'select distinct nvl(' || v_lvl1_col || ', ''None'')'
          || '            , nvl(' || v_lvl2_col || ', ''Unknown'')'
          || '            , nvl(' || v_lvl3_col || ', ''Unknown'') '
          || 'from cost_usage_timeseries_daily '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'')'
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'')'
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' order by 1, 2, 3';

    open v_group_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_group_cursor into v_lvl1_map(v_idx + 1), v_lvl2_map(v_idx + 1), v_lvl3_map(v_idx + 1);
        exit when v_group_cursor%notfound;
        v_idx := v_idx + 1;
        v_columns(v_idx) := v_lvl1_map(v_idx) || '|' || v_lvl2_map(v_idx) || '|' || v_lvl3_map(v_idx);
    end loop;
    close v_group_cursor;

    -- Header Rows
    declare
        type temp_map is table of integer index by varchar2(500);
        v_colspan_map temp_map;
        col_key varchar2(500);
    begin
        for i in 1 .. v_idx loop
            col_key := v_lvl1_map(i);
            if v_colspan_map.exists(col_key) then
                v_colspan_map(col_key) := v_colspan_map(col_key) + 1;
            else
                v_colspan_map(col_key) := 1;
            end if;
        end loop;

        col_key := v_colspan_map.first;
        while col_key is not null loop
            v_html := v_html || '<th colspan="' || v_colspan_map(col_key) || '">' || col_key || '</th>';
            col_key := v_colspan_map.next(col_key);
        end loop;
    end;

    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl2_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr><tr>';
    for i in 1 .. v_idx loop
        v_html := v_html || '<th>' || v_lvl3_map(i) || '</th>';
    end loop;

    v_html := v_html || '</tr></thead><tbody>';

    -- Build pivot data
    v_sql := 'select to_char(date_bucket, ''DD-Mon'') || ''|'''
          || '    || nvl(' || v_lvl1_col || ', ''None'') || ''|'''
          || '    || nvl(' || v_lvl2_col || ', ''Unknown'') || ''|'''
          || '    || nvl(' || v_lvl3_col || ', ''Unknown'') as map_key,'
          || '       round(sum(usage), 0) '
          || 'from cost_usage_timeseries_daily '
          || 'where date_bucket between to_date(:1, ''DD-MON-YYYY HH24:MI:SS'')'
          || '                      and to_date(:2, ''DD-MON-YYYY HH24:MI:SS'')'
          || add_filter('SUBACCOUNTNAME',   p_tenant)
          || add_filter('BILLINGACCOUNTID', p_subscription_id)
          || add_filter('REGION',           p_region)
          || add_filter_or2('OCI_COMPARTMENTID', 'COSTCENTER', p_compartment) -- CHANGED
          || add_filter('SERVICECATEGORY',  p_service_category)
          || add_filter('SERVICENAME',      p_service_name)
          || add_filter('CHARGEDESCRIPTION',p_charge_description)
          || add_filter('RESOURCETYPE',     p_resource_type)
          || add_filter('RESOURCEID',       p_resource_name)
          || ' group by to_char(date_bucket, ''DD-Mon''),'
          || '          nvl(' || v_lvl1_col || ', ''None''),'
          || '          nvl(' || v_lvl2_col || ', ''Unknown''),'
          || '          nvl(' || v_lvl3_col || ', ''Unknown'')';

    open v_cursor for v_sql using p_fromdate, p_todate;
    loop
        fetch v_cursor into v_key, v_usage;
        exit when v_cursor%notfound;
        v_data_map(v_key) := v_usage;
    end loop;
    close v_cursor;

    -- Output data rows
    for date_rec in cur_dates loop
        v_html := v_html || '<tr><td class="pivot-day-col">' || date_rec.day_label || '</td>';

        for i in 1 .. v_idx loop
            v_key := date_rec.day_label || '|' || v_lvl1_map(i) || '|' || v_lvl2_map(i) || '|' || v_lvl3_map(i);

            v_usage := case
                         when v_data_map.exists(v_key) then v_data_map(v_key)
                         else 0
                       end;

            v_html := v_html || '<td>' || to_char(v_usage, 'FM999G999G999G999G999G990') || '</td>';

            if v_totals.exists(v_columns(i)) then
                v_totals(v_columns(i)) := v_totals(v_columns(i)) + v_usage;
            else
                v_totals(v_columns(i)) := v_usage;
            end if;
        end loop;

        v_html := v_html || '</tr>';
    end loop;

    v_html := v_html || '</tbody></table></div>';
    return v_html;
end;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ARCHIVE_AVAILABILITY_METRICS_PY" (
  p_retain_months in pls_integer default 13
) as
  -- Keep at most p_retain_months in the main table.
  -- Cutoff is first day of current month minus p_retain_months.
  l_cutoff_ts timestamp;
begin
  if p_retain_months < 1 then
    raise_application_error(-20001, 'p_retain_months must be >= 1');
  end if;

  l_cutoff_ts :=
    add_months(
      trunc(systimestamp, 'MM'),  -- first day of current month at 00:00
      -p_retain_months
    );

  -- 1) Move data to archive (older than cutoff)
  insert /*+ APPEND */
  into OCI_AVAILABILITY_METRICS_PY_ARCHIVE a
  select *
  from   OCI_AVAILABILITY_METRICS_PY m
  where  m."TIMESTAMP" < l_cutoff_ts;

  commit;

  -- 2) Delete same range from main table
  delete /*+ PARALLEL(8) */
  from   OCI_AVAILABILITY_METRICS_PY m
  where  m."TIMESTAMP" < l_cutoff_ts;

  commit;

  -- 3) Optionally gather stats (skip if you have central stats job)
  begin
    dbms_stats.gather_table_stats(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'OCI_AVAILABILITY_METRICS_PY',
      estimate_percent => dbms_stats.auto_sample_size,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );

    dbms_stats.gather_table_stats(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'OCI_AVAILABILITY_METRICS_PY_ARCHIVE',
      estimate_percent => dbms_stats.auto_sample_size,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );
  exception
    when others then
      null; -- ignore stats errors
  end;
end ARCHIVE_AVAILABILITY_METRICS_PY;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ARCHIVE_FOCUS_REPORTS_PY" (
  p_retain_months IN PLS_INTEGER DEFAULT 13
) AS
  -- Keep at most p_retain_months in the main table.
  -- Cutoff is first day of current month minus p_retain_months.
  l_cutoff_ts TIMESTAMP;
BEGIN
  IF p_retain_months < 1 THEN
    RAISE_APPLICATION_ERROR(-20001, 'p_retain_months must be >= 1');
  END IF;

  l_cutoff_ts :=
    ADD_MONTHS(
      TRUNC(SYSTIMESTAMP, 'MM'),  -- first day of current month at 00:00
      -p_retain_months
    );

  -- 1) Move data to archive (older than cutoff)
  INSERT /*+ APPEND */
  INTO FOCUS_REPORTS_PY_ARCHIVE a
  SELECT *
  FROM   FOCUS_REPORTS_PY m
  WHERE  m.CHARGEPERIODSTART < l_cutoff_ts;

  COMMIT;

  -- 2) Delete same range from main table
  DELETE /*+ PARALLEL(8) */
  FROM   FOCUS_REPORTS_PY m
  WHERE  m.CHARGEPERIODSTART < l_cutoff_ts;

  COMMIT;

  -- 3) Optionally gather stats (skip if you have central stats job)
  BEGIN
    DBMS_STATS.GATHER_TABLE_STATS(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'FOCUS_REPORTS_PY',
      estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );

    DBMS_STATS.GATHER_TABLE_STATS(
      ownname          => 'OCI_FOCUS_REPORTS',
      tabname          => 'FOCUS_REPORTS_PY_ARCHIVE',
      estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       => 'FOR ALL COLUMNS SIZE AUTO'
    );
  EXCEPTION
    WHEN OTHERS THEN
      NULL; -- ignore stats errors
  END;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "CHATBOT_PROC_GENERIC" (
    p_user_message    IN  CLOB,
    p_model_id        IN  VARCHAR2,
    p_chat_id         IN  NUMBER,
    p_app_user        IN  VARCHAR2,
    p_app_session     IN  VARCHAR2,
    p_compartment_id  IN  VARCHAR2,
    p_row_id          OUT chatbot_generic_log.id%TYPE,
    p_final_sql       OUT CLOB,
    p_final_response  OUT CLOB,
    p_final_aimessage OUT CLOB
) AS
    -------------------------------------------------------------------------
    -- Config + infra
    -------------------------------------------------------------------------
    l_region             VARCHAR2(50);
    l_model_cfg_model_id VARCHAR2(1000);
    l_api_format         VARCHAR2(50);
    l_temperature        NUMBER;
    l_top_p              NUMBER;
    l_top_k              NUMBER;
    l_frequency_penalty  NUMBER;
    l_presence_penalty   NUMBER;
    l_reasoning_endpoint VARCHAR2(1000);
    l_payload            CLOB;
    l_response_struct    dbms_cloud_types.resp;
    l_response_text      CLOB;  -- raw HTTP body (JSON)
    -- Prompt / memory
    l_prompt             CLOB;
    l_cohere_message     CLOB;  -- single-string with history for COHERE
    l_generic_messages   CLOB;  -- JSON array string for GENERIC "messages"
    -- Parsed assistant text
    l_assistant_text     CLOB;
    -- Code extraction
    l_code_language_raw  VARCHAR2(200);
    l_code_language_norm VARCHAR2(50);
    l_code_block         CLOB;
    v_log_row_id         chatbot_generic_log.id%TYPE;
    -------------------------------------------------------------------------
    -- Memory limits
    -------------------------------------------------------------------------
    c_max_history_turns   CONSTANT PLS_INTEGER := 20;     -- up to 20 prior exchanges
    c_max_history_chars   CONSTANT PLS_INTEGER := 12000;  -- cap total characters contributed by history
    -------------------------------------------------------------------------
    -- Debug helpers (no table; apex_debug only)
    -------------------------------------------------------------------------
    l_req_id    VARCHAR2(32) := RAWTOHEX(SYS_GUID()); -- correlation id per run
    l_t0        TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
    l_http_t0   TIMESTAMP WITH TIME ZONE;
    l_http_ms   NUMBER;
    -------------------------------------------------------------------------
    -- Grok 4 fix
    -------------------------------------------------------------------------
    l_is_grok4_chr  VARCHAR2(1);
    l_is_grok4      BOOLEAN;
    PROCEDURE logv(p_msg VARCHAR2) IS
    BEGIN
      apex_debug.message('[%s] %s', l_req_id, p_msg);
    END;
    PROCEDURE logc(p_label VARCHAR2, p_c CLOB, p_len INTEGER := 4000) IS
    BEGIN
    apex_debug.message('[%s] %s (first %s): %s',
        l_req_id,
        p_label,
        p_len,
        DBMS_LOB.SUBSTR(p_c, LEAST(p_len, 4000), 1)
    );
    END;
    FUNCTION ms_between(p_start TIMESTAMP WITH TIME ZONE,
                        p_end   TIMESTAMP WITH TIME ZONE) RETURN NUMBER IS
    BEGIN
      RETURN  (EXTRACT(DAY    FROM (p_end - p_start)) * 86400000)
            + (EXTRACT(HOUR   FROM (p_end - p_start)) * 3600000)
            + (EXTRACT(MINUTE FROM (p_end - p_start)) * 60000)
            + ROUND(EXTRACT(SECOND FROM (p_end - p_start)) * 1000);
    END;
    -------------------------------------------------------------------------
    -- Utilities
    -------------------------------------------------------------------------
    FUNCTION clob_to_blob_utf8(p_clob IN CLOB) RETURN BLOB IS
        l_blob        BLOB;
        l_dest_offset INTEGER := 1;
        l_src_offset  INTEGER := 1;
        l_lang_ctx    INTEGER := 0;
        l_warning     INTEGER := 0;
    BEGIN
        DBMS_LOB.CREATETEMPORARY(l_blob, TRUE);
        DBMS_LOB.CONVERTTOBLOB(
            dest_lob     => l_blob,
            src_clob     => p_clob,
            amount       => DBMS_LOB.LOBMAXSIZE,
            dest_offset  => l_dest_offset,
            src_offset   => l_src_offset,
            blob_csid    => NLS_CHARSET_ID('AL32UTF8'),
            lang_context => l_lang_ctx,
            warning      => l_warning
        );
        RETURN l_blob;
    END;
    FUNCTION json_escape(p_txt CLOB) RETURN CLOB IS
        l_out CLOB;
    BEGIN
        IF p_txt IS NULL THEN RETURN NULL; END IF;
        l_out := p_txt;
        l_out := REPLACE(l_out, '\', '\\');
        l_out := REPLACE(l_out, '"', '\"');
        l_out := REPLACE(l_out, CHR(13)||CHR(10), '\n');
        l_out := REPLACE(l_out, CHR(10), '\n');
        l_out := REPLACE(l_out, CHR(13), '\n');
        l_out := REPLACE(l_out, CHR(9),  '\t');
        RETURN l_out;
    END;
    FUNCTION dbg(p CLOB, p_len INTEGER := 4000) RETURN VARCHAR2 IS
    BEGIN
        RETURN DBMS_LOB.SUBSTR(p, p_len, 1);
    END;
    -- Build payload for COHERE with a single message string
    FUNCTION build_payload_cohere(
        p_model_id         IN VARCHAR2,
        p_compartment_id   IN VARCHAR2,
        p_message_text     IN CLOB,
        p_temperature      IN NUMBER,
        p_top_p            IN NUMBER,
        p_top_k            IN NUMBER,
        p_freq_penalty     IN NUMBER,
        p_presence_penalty IN NUMBER
    ) RETURN CLOB IS
        l_msg CLOB := json_escape(p_message_text);
        l_payload CLOB;
    BEGIN
        l_payload :=
            TO_CLOB('{')||
              '"compartmentId":"'||p_compartment_id||'",'||
              '"servingMode":{"modelId":"'||p_model_id||'","servingType":"ON_DEMAND"},'||
              '"chatRequest":{'||
                '"apiFormat":"COHERE",'||
                '"maxTokens":3999,'||
                '"frequencyPenalty":'||TO_CHAR(p_freq_penalty,'FM9990.00')||','||
                '"presencePenalty":'||TO_CHAR(p_presence_penalty,'FM9990.00')||','||
                '"temperature":'||TO_CHAR(p_temperature,'FM9990.00')||','||
                '"topP":'||TO_CHAR(p_top_p,'FM9990.00')||','||
                '"topK":'||TO_CHAR(p_top_k,'FM9990')||','||
                '"message":"'||l_msg||'"'||
              '}'||
            '}';
        RETURN l_payload;
    END;
    -- Build payload for GENERIC with a messages[] JSON array
    FUNCTION build_payload_generic(
        p_model_id          IN VARCHAR2,
        p_compartment_id    IN VARCHAR2,
        p_messages_json     IN CLOB,   -- already a JSON array string
        p_temperature       IN NUMBER,
        p_top_p             IN NUMBER,
        p_top_k             IN NUMBER,
        p_freq_penalty      IN NUMBER,
        p_presence_penalty  IN NUMBER,
        p_include_freq      IN BOOLEAN,  -- NEW: include frequencyPenalty?
        p_include_presence  IN BOOLEAN   -- NEW: include presencePenalty?
    ) RETURN CLOB IS
        l_payload CLOB;
        l_chat    CLOB;
    BEGIN
        l_chat :=
            TO_CLOB('{')||
            '"messages":'|| p_messages_json ||','||
            '"apiFormat":"GENERIC",'||
            '"maxTokens":3999,'||
            '"temperature":'||TO_CHAR(p_temperature)||','||
            '"topP":'||TO_CHAR(p_top_p,'FM9990.00')||','||
            '"topK":'||TO_CHAR(p_top_k,'FM9990');
        IF p_include_freq THEN
            l_chat := l_chat || ',' ||
            '"frequencyPenalty":'||TO_CHAR(p_freq_penalty,'FM9990.00');
        END IF;
        IF p_include_presence THEN
            l_chat := l_chat || ',' ||
            '"presencePenalty":'||TO_CHAR(p_presence_penalty,'FM9990.00');
        END IF;
        l_chat := l_chat || '}';
        l_payload :=
            TO_CLOB('{')||
            '"compartmentId":"'||p_compartment_id||'",'||
            '"servingMode":{"modelId":"'||p_model_id||'","servingType":"ON_DEMAND"},'||
            '"chatRequest":'|| l_chat ||
            '}';
        RETURN l_payload;
    END;
    -------------------------------------------------------------------------
    -- Extract assistant text from OCI GenAI response for both formats
    -------------------------------------------------------------------------
    FUNCTION extract_assistant_text(p_json CLOB) RETURN CLOB IS
        lo JSON_OBJECT_T := json_object_t.parse(p_json);
        cr JSON_OBJECT_T;
        txt CLOB;
    BEGIN
        IF NOT lo.has('chatResponse') THEN
            RETURN NULL;
        END IF;
        cr := lo.get_object('chatResponse');
        -- COHERE: prefer "text"
        IF cr.has('text') THEN
            BEGIN
                txt := cr.get_string('text');
                IF txt IS NOT NULL AND TRIM(txt) IS NOT NULL THEN
                    RETURN txt;
                END IF;
            EXCEPTION WHEN OTHERS THEN NULL; END;
        END IF;
        -- GENERIC: choices[0].message.content[*].text
        IF cr.has('choices') THEN
            DECLARE
                ca JSON_ARRAY_T := cr.get_array('choices');
                ch JSON_OBJECT_T;
                mo JSON_OBJECT_T;
                co JSON_ARRAY_T;
                i PLS_INTEGER;
                part JSON_OBJECT_T;
                accum CLOB := EMPTY_CLOB();
            BEGIN
                IF ca.get_size > 0 THEN
                    ch := TREAT(ca.get(0) AS JSON_OBJECT_T);
                    mo := TREAT(ch.get('message') AS JSON_OBJECT_T);
                    co := TREAT(mo.get('content') AS JSON_ARRAY_T);
                    i := 0;
                    WHILE i < co.get_size LOOP
                        part := TREAT(co.get(i) AS JSON_OBJECT_T);
                        IF part.has('type') AND UPPER(part.get_string('type')) = 'TEXT' THEN
                            accum := accum || part.get_string('text');
                        END IF;
                        i := i + 1;
                    END LOOP;
                    RETURN accum;
                END IF;
            EXCEPTION WHEN OTHERS THEN RETURN NULL; END;
        END IF;
        RETURN NULL;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN NULL;
    END;
    -------------------------------------------------------------------------
    -- Find first fenced code block ```lang\n...\n```, return lang + code
    -------------------------------------------------------------------------
    PROCEDURE extract_code_block(
        p_text         IN  CLOB,
        p_lang_raw     OUT VARCHAR2,
        p_lang_norm    OUT VARCHAR2,
        p_code         OUT CLOB
    ) IS
        s PLS_INTEGER;
        e PLS_INTEGER;
        nl PLS_INTEGER;
        lang_line VARCHAR2(32767);
        code_start PLS_INTEGER;
        code_len   PLS_INTEGER;
        lang_guess VARCHAR2(200);
    BEGIN
        p_lang_raw  := NULL;
        p_lang_norm := NULL;
        p_code      := NULL;
        s := DBMS_LOB.INSTR(p_text, '```', 1, 1);
        IF s = 0 THEN RETURN; END IF;
        nl := DBMS_LOB.INSTR(p_text, CHR(10), s+3, 1);
        IF nl = 0 THEN RETURN; END IF;
        -- This substring is tiny (language tag), VARCHAR2 is fine here
        lang_line := TRIM(REPLACE(DBMS_LOB.SUBSTR(p_text, nl - (s+3), s+3), CHR(13), ''));
        IF lang_line IS NOT NULL THEN p_lang_raw := LOWER(lang_line); END IF;
        code_start := nl + 1;
        e := DBMS_LOB.INSTR(p_text, '```', code_start, 1);
        IF e = 0 THEN e := DBMS_LOB.GETLENGTH(p_text) + 1; END IF;
        code_len := e - code_start;
        IF code_len <= 0 THEN RETURN; END IF;
        -- ****** CLOB→CLOB copy (no 32K truncation) ******
        DBMS_LOB.CREATETEMPORARY(p_code, TRUE);
        DBMS_LOB.COPY(
            dest_lob    => p_code,
            src_lob     => p_text,
            amount      => code_len,
            dest_offset => 1,
            src_offset  => code_start
        );
        lang_guess := NVL(p_lang_raw, '');
        CASE lang_guess
            WHEN ''      THEN p_lang_norm := 'plaintext';
            WHEN 'js'    THEN p_lang_norm := 'javascript';
            WHEN 'ts'    THEN p_lang_norm := 'typescript';
            WHEN 'ps1'   THEN p_lang_norm := 'powershell';
            WHEN 'sh'    THEN p_lang_norm := 'bash';
            WHEN 'shell' THEN p_lang_norm := 'bash';
            WHEN 'py'    THEN p_lang_norm := 'python';
            WHEN 'plsql' THEN p_lang_norm := 'plsql';
            WHEN 'pgsql' THEN p_lang_norm := 'sql';
            ELSE
                IF lang_guess IN (
                    'javascript','typescript','python','sql','bash','json',
                    'html','css','java','c','cpp','csharp','kotlin','ruby',
                    'go','php','r','swift','scala','rust','powershell','xml',
                    'yaml','markdown','plsql','docker','ini','makefile'
                ) THEN
                    p_lang_norm := lang_guess;
                ELSE
                    p_lang_norm := 'plaintext';
                END IF;
        END CASE;
    END;
    -------------------------------------------------------------------------
    -- Helpers to build memory
    -------------------------------------------------------------------------
    FUNCTION clamp_text(p_txt CLOB, p_max_chars PLS_INTEGER) RETURN CLOB IS
    BEGIN
        IF p_txt IS NULL THEN RETURN NULL; END IF;
        IF DBMS_LOB.GETLENGTH(p_txt) <= p_max_chars THEN
            RETURN p_txt;
        ELSE
            RETURN DBMS_LOB.SUBSTR(p_txt, p_max_chars, 1);
        END IF;
    END;
    PROCEDURE build_history_for_generic(
        p_chat_id        IN NUMBER,
        p_app_user       IN VARCHAR2,
        p_current_msg    IN CLOB,
        p_messages_json  OUT CLOB
    ) IS
        l_acc           CLOB := TO_CLOB('[');
        l_first         BOOLEAN := TRUE;
        l_chars_used    PLS_INTEGER := 0;
        CURSOR c_hist IS
          SELECT user_prompt, assistant_text
            FROM (
                  SELECT user_prompt, assistant_text, created_at
                    FROM chatbot_generic_log
                   WHERE chat_id  = p_chat_id
                     AND app_user = p_app_user
                     AND assistant_text IS NOT NULL
                   ORDER BY created_at DESC
                 )
           WHERE ROWNUM <= c_max_history_turns
           ORDER BY created_at ASC;
    BEGIN
        -- prior turns
        FOR r IN c_hist LOOP
            -- USER message
            IF NOT l_first THEN l_acc := l_acc || ','; END IF;
            l_first := FALSE;
            DECLARE u CLOB := clamp_text(NVL(r.user_prompt, ''), 2000);
            BEGIN
                u := json_escape(u);
                l_acc := l_acc ||
                  '{"role":"USER","content":[{"type":"TEXT","text":"'|| u ||'"}]}';
                l_chars_used := l_chars_used + NVL(DBMS_LOB.GETLENGTH(u),0);
            END;
            -- ASSISTANT message
            l_acc := l_acc || ',';
            DECLARE a CLOB := clamp_text(NVL(r.assistant_text, ''), 4000);
            BEGIN
                a := json_escape(a);
                l_acc := l_acc ||
                  '{"role":"ASSISTANT","content":[{"type":"TEXT","text":"'|| a ||'"}]}';
                l_chars_used := l_chars_used + NVL(DBMS_LOB.GETLENGTH(a),0);
            END;
            IF l_chars_used >= c_max_history_chars THEN
                EXIT;
            END IF;
        END LOOP;
        -- current user message last
        DECLARE cu CLOB := json_escape(clamp_text(p_current_msg, 4000));
        BEGIN
            IF NOT l_first THEN l_acc := l_acc || ','; END IF;
            l_acc := l_acc ||
              '{"role":"USER","content":[{"type":"TEXT","text":"'|| cu ||'"}]}';
        END;
        l_acc := l_acc || ']';
        p_messages_json := l_acc;
    END;
    PROCEDURE build_history_for_cohere(
        p_chat_id        IN NUMBER,
        p_app_user       IN VARCHAR2,
        p_current_msg    IN CLOB,
        p_message_text   OUT CLOB
    ) IS
        l_acc        CLOB := EMPTY_CLOB();
        l_turns      PLS_INTEGER := 0;
        l_chars_used PLS_INTEGER := 0;
        CURSOR c_hist IS
          SELECT user_prompt, assistant_text
            FROM (
                  SELECT user_prompt, assistant_text, created_at
                    FROM chatbot_generic_log
                   WHERE chat_id  = p_chat_id
                     AND app_user = p_app_user
                     AND assistant_text IS NOT NULL
                   ORDER BY created_at DESC
                 )
           WHERE ROWNUM <= c_max_history_turns
           ORDER BY created_at ASC;
    BEGIN
        FOR r IN c_hist LOOP
            EXIT WHEN l_chars_used >= c_max_history_chars;
            DECLARE
                u CLOB := clamp_text(NVL(r.user_prompt, ''), 2000);
                a CLOB := clamp_text(NVL(r.assistant_text, ''), 4000);
            BEGIN
                l_acc := l_acc ||
                    'User: '      || u || CHR(10) ||
                    'Assistant: ' || a || CHR(10) || CHR(10);
                l_chars_used := l_chars_used + NVL(DBMS_LOB.GETLENGTH(u),0) + NVL(DBMS_LOB.GETLENGTH(a),0);
                l_turns := l_turns + 1;
            END;
        END LOOP;
        l_acc := l_acc || 'User: ' || p_current_msg || CHR(10) || 'Assistant:';
        p_message_text := l_acc;
    END;
BEGIN
    -- Ensure debug is on during development; ignore if not in APEX
    BEGIN
      apex_debug.enable(apex_debug.c_log_level_info);
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
    -- Disable DML
    BEGIN
        EXECUTE IMMEDIATE 'ALTER SESSION DISABLE PARALLEL DML';
    EXCEPTION WHEN OTHERS THEN NULL; -- ignore if not allowed
    END;
    DBMS_APPLICATION_INFO.set_module('CHATBOT', 'CHATBOT_PROC_GENERIC');
    DBMS_APPLICATION_INFO.set_action('init');
    apex_debug.message('🧠 Starting CHATBOT_PROC_GENERIC (with memory)');
    logv('start; app_user='||p_app_user||
         ', chat_id='||p_chat_id||
         ', session='||p_app_session||
         ', model_id='||p_model_id);
    -------------------------------------------------------------------------
    -- Load model config
    -------------------------------------------------------------------------
    BEGIN
        SELECT
        region, model_id, api_format,
        NVL(temperature,1), NVL(top_p,1), NVL(top_k,1),
        NVL(frequency_penalty,0), NVL(presence_penalty,0),
        CASE WHEN LOWER(model_name) LIKE '%grok-4%' THEN 'Y' ELSE 'N' END AS is_grok4
        INTO
        l_region, l_model_cfg_model_id, l_api_format,
        l_temperature, l_top_p, l_top_k,
        l_frequency_penalty, l_presence_penalty,
        l_is_grok4_chr
        FROM ai_model_config
        WHERE model_id = p_model_id;
        l_is_grok4 := (l_is_grok4_chr = 'Y');
        IF l_is_grok4 THEN logv('Model GROK-4 detected: will omit frequencyPenalty'); END IF;
        l_reasoning_endpoint := 'https://inference.generativeai.'||LOWER(l_region)||
                                '.oci.oraclecloud.com/20231130/actions/chat';
        apex_debug.message('🔗 Endpoint: %s', l_reasoning_endpoint);
        apex_debug.message('🧠 Model: %s; Format: %s', l_model_cfg_model_id, l_api_format);
        logv('endpoint='||l_reasoning_endpoint||', api_format='||l_api_format);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            raise_application_error(-20002, 'No AI model config found for given model ID.');
    END;
    -------------------------------------------------------------------------
    -- Build memory-aware input (no extra instructions/schema/examples)
    -------------------------------------------------------------------------
    l_prompt := TO_CLOB(p_user_message);
    IF UPPER(l_api_format) = 'GENERIC' THEN
        build_history_for_generic(
            p_chat_id       => p_chat_id,
            p_app_user      => p_app_user,
            p_current_msg   => l_prompt,
            p_messages_json => l_generic_messages
        );
        l_payload := build_payload_generic(
            p_model_id          => l_model_cfg_model_id,
            p_compartment_id    => p_compartment_id,
            p_messages_json     => l_generic_messages,
            p_temperature       => l_temperature,
            p_top_p             => l_top_p,
            p_top_k             => l_top_k,
            p_freq_penalty      => l_frequency_penalty,
            p_presence_penalty  => l_presence_penalty,
            p_include_freq      => NOT l_is_grok4,  -- omit for GROK-4
            p_include_presence  => NOT l_is_grok4   -- omit for GROK-4
        );
    ELSE
        -- COHERE
        build_history_for_cohere(
            p_chat_id      => p_chat_id,
            p_app_user     => p_app_user,
            p_current_msg  => l_prompt,
            p_message_text => l_cohere_message
        );
        l_payload := build_payload_cohere(
            p_model_id         => l_model_cfg_model_id,
            p_compartment_id   => p_compartment_id,
            p_message_text     => l_cohere_message,
            p_temperature      => l_temperature,
            p_top_p            => l_top_p,
            p_top_k            => l_top_k,
            p_freq_penalty     => l_frequency_penalty,
            p_presence_penalty => l_presence_penalty
        );
    END IF;
    logv('payload chars='||NVL(DBMS_LOB.getlength(l_payload),0));
    logc('📦 Payload', l_payload, 4000);
    -------------------------------------------------------------------------
    -- Call OCI GenAI
    -------------------------------------------------------------------------
    DECLARE
      l_body BLOB := clob_to_blob_utf8(l_payload);
    BEGIN
      l_http_t0 := SYSTIMESTAMP;
      l_response_struct := dbms_cloud.send_request(
          credential_name => 'OCI$RESOURCE_PRINCIPAL',
          uri             => l_reasoning_endpoint,
          method          => 'POST',
          headers         => JSON_OBJECT('Content-Type' VALUE 'application/json'),
          body            => l_body
      );
      DBMS_LOB.FREETEMPORARY(l_body);
      l_http_ms := ms_between(l_http_t0, SYSTIMESTAMP);
      logv('HTTP POST completed in '||l_http_ms||' ms');
    END;
    l_response_text := dbms_cloud.get_response_text(l_response_struct);
    p_final_response := l_response_text;
    logv('response chars='||NVL(DBMS_LOB.getlength(l_response_text),0));
    logc('🧾 Raw response', l_response_text, 4000);
    -------------------------------------------------------------------------
    -- Extract assistant text
    -------------------------------------------------------------------------
    l_assistant_text := extract_assistant_text(l_response_text);
    p_final_aimessage := l_assistant_text;
    IF l_assistant_text IS NULL OR TRIM(l_assistant_text) IS NULL THEN
        raise_application_error(-20011, 'AI response parsing failed: assistant text not found.');
    END IF;
    logv('assistant_text chars='||NVL(DBMS_LOB.getlength(l_assistant_text),0));
    -------------------------------------------------------------------------
    -- Detect a code block (first fenced block) for Prism display
    -------------------------------------------------------------------------
    extract_code_block(
        p_text      => l_assistant_text,
        p_lang_raw  => l_code_language_raw,
        p_lang_norm => l_code_language_norm,
        p_code      => l_code_block
    );
    IF l_code_block IS NOT NULL THEN
      logv('code block chars='||DBMS_LOB.getlength(l_code_block));
    END IF;
    -------------------------------------------------------------------------
    -- Log row (generic chat)
    -------------------------------------------------------------------------
    -- Ensure parent conversation row exists (or touch LAST_ACTIVITY if it does)
    MERGE INTO CHATBOT_GENERIC_CONVERSATION c
    USING (
        SELECT p_chat_id AS chat_id,
                p_app_user AS app_user,
                '' AS friendly_name
        FROM dual
    ) s
    ON (c.chat_id = s.chat_id)
    WHEN NOT MATCHED THEN
        INSERT (chat_id, app_user, friendly_name, created_at, last_activity, archived_yn)
        VALUES (s.chat_id, s.app_user, s.friendly_name, SYSTIMESTAMP, SYSTIMESTAMP, 'N')
    WHEN MATCHED THEN
        UPDATE SET last_activity = SYSTIMESTAMP;
    INSERT INTO CHATBOT_GENERIC_LOG (
        chat_id,
        app_user,
        session_id,
        user_prompt,
        assistant_text,
        code_language,
        code_block,
        generated_sql,
        execution_data,
        raw_response
    ) VALUES (
        p_chat_id,
        p_app_user,
        p_app_session,
        l_prompt,
        l_assistant_text,
        l_code_language_norm,
        l_code_block,
        NULL,
        NULL,
        l_response_text
    )
    RETURNING id INTO v_log_row_id;
    IF DBMS_LOB.ISTEMPORARY(l_code_block) = 1 THEN
        DBMS_LOB.FREETEMPORARY(l_code_block);
    END IF;
    p_row_id          := v_log_row_id;
    p_final_sql       := NULL;
    --p_final_aimessage := NULL;
    apex_debug.message('✅ Chat logged. ID=%s, Lang=%s, Code? %s',
        v_log_row_id,
        NVL(l_code_language_norm,'(none)'),
        CASE WHEN l_code_block IS NOT NULL THEN 'Y' ELSE 'N' END
    );
    logv('row inserted id='||v_log_row_id);
    apex_debug.message('🏁 Procedure completed.');
    logv('done; total='||ms_between(l_t0, SYSTIMESTAMP)||' ms');
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      apex_debug.message('❌ [%s] ERROR: %s', l_req_id, SQLERRM);
      apex_debug.message('🔙 [%s] BT: %s',   l_req_id, DBMS_UTILITY.format_error_backtrace);
      IF l_reasoning_endpoint IS NOT NULL THEN
        apex_debug.message('🔗 [%s] endpoint=%s', l_req_id, l_reasoning_endpoint);
      END IF;
      IF l_payload IS NOT NULL THEN
        apex_debug.message('📦 [%s] payload (first 4K): %s', l_req_id, dbg(l_payload, 4000));
      END IF;
      IF l_response_text IS NOT NULL THEN
        apex_debug.message('🧾 [%s] response (first 4K): %s', l_req_id, dbg(l_response_text, 4000));
      END IF;
      apex_debug.message('⏱ [%s] elapsed before error: %s ms',
                         l_req_id, ms_between(l_t0, SYSTIMESTAMP));
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
    RAISE;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DEMO_UTIL_APPLY_BILLING_TO_DAILY" AS
BEGIN
  /* Bill core fields */
  UPDATE demo_util_analytic_daily d
  SET (bill_id, bill_total_amount, bill_due_date, bill_status) = (
    SELECT bm.bill_id, bm.bill_total_amount, bm.bill_due_date, bm.bill_status
    FROM demo_util_bill_model bm
    WHERE bm.customer_id = d.customer_id
      AND bm.month_start = TRUNC(d.day_date,'MM')
  )
  WHERE EXISTS (
    SELECT 1 FROM demo_util_bill_model bm
    WHERE bm.customer_id = d.customer_id
      AND bm.month_start = TRUNC(d.day_date,'MM')
  );
  /* Paid-to-date on or before that day */
  UPDATE demo_util_analytic_daily d
  SET bill_paid_to_date = NVL((
    SELECT CASE
             WHEN bm.pay_date IS NOT NULL AND bm.pay_date <= d.day_date
             THEN bm.pay_amount ELSE 0
           END
    FROM demo_util_bill_model bm
    WHERE bm.customer_id = d.customer_id
      AND bm.month_start = TRUNC(d.day_date,'MM')
  ),0);
  /* Running open balance as of day */
  UPDATE demo_util_analytic_daily d
  SET customer_open_balance_to_date =
    NVL((
      SELECT SUM(bm2.bill_total_amount)
      FROM demo_util_bill_model bm2
      WHERE bm2.customer_id = d.customer_id
        AND bm2.bill_due_date <= d.day_date
    ),0)
    -
    NVL((
      SELECT SUM(bm3.pay_amount)
      FROM demo_util_bill_model bm3
      WHERE bm3.customer_id = d.customer_id
        AND bm3.pay_date IS NOT NULL
        AND bm3.pay_date <= d.day_date
    ),0);
  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "FOCUS_AUTH_CONFIG" (
  p_conf in out nocopy apex_authentication.t_configuration
) is
  l_disc varchar2(4000);
begin
  begin
    select config_value
      into l_disc
      from app_config
     where config_key = 'OIDC_DISCOVERY_URL';
  exception
    when no_data_found then
      l_disc := null;
  end;
  if l_disc is not null then
    p_conf.substitutions := apex_t_varchar2(
      'DISCOVERY_URL', l_disc
    );
  end if;
  -- Optional: runtime proof in debug log
  apex_debug.message('AUTH_CONFIG DISCOVERY_URL=%s', nvl(l_disc,'<NULL>'));
end;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PAGE1_CONS_WRKLD_MONTH_CHART_DATA_PROC" AS
  l_title   VARCHAR2(400);
  l_value   CLOB;
BEGIN
  -- Truncate the table once before processing
  EXECUTE IMMEDIATE 'TRUNCATE TABLE PAGE1_CONS_WRKLD_MONTH_CHART_DATA';

  -- Loop through top N rows by row_number
  FOR rec IN (
    SELECT DBMS_LOB.SUBSTR(WORKLOAD_NAME, 4000) AS WORKLOAD_NAME,
           DBMS_LOB.SUBSTR(VALUE, 4000) AS VALUE,
           ROW_NUMBER() OVER (ORDER BY WORKLOAD_NAME) AS rn
    FROM OCI_WORKLOADS
    WHERE VALUE IS NOT NULL
  ) LOOP
    -- Skip empty compartment lists
    IF rec.VALUE IS NOT NULL THEN
      -- Insert aggregated data
      INSERT INTO PAGE1_CONS_WRKLD_MONTH_CHART_DATA (
        WORKLOAD_NAME,
        MONTH,
        COST,
        LAST_REFRESH
      )
      SELECT
        rec.WORKLOAD_NAME,
        TRUNC(DATE_BUCKET, 'MM') AS MONTH,
        SUM(COST) AS COST,
        SYSDATE
      FROM COST_USAGE_TIMESERIES_DAILY fr
      WHERE DATE_BUCKET >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -12)
            AND EXISTS (
              SELECT 1
              FROM TABLE(APEX_STRING.SPLIT(rec.VALUE, ',')) w
              WHERE TRIM(w.column_value) = fr.OCI_COMPARTMENTID
                 OR TRIM(w.column_value) = fr.COSTCENTER
            )
      GROUP BY TRUNC(DATE_BUCKET, 'MM');
    END IF;
  END LOOP;
  -- Ensure all changes are committed
  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "PAGE1_CONS_WRKLD_WEEK_CHART_DATA_PROC" AS
  l_title   VARCHAR2(400);
  l_value   CLOB;
BEGIN
  -- Truncate the entire table before inserting fresh data
  EXECUTE IMMEDIATE 'TRUNCATE TABLE PAGE1_CONS_WRKLD_WEEK_CHART_DATA';

  -- Loop through workloads (VALUE holds comma-separated compartment ids and/or cost centers)
  FOR rec IN (
    SELECT DBMS_LOB.SUBSTR(WORKLOAD_NAME, 4000) AS WORKLOAD_NAME,
           DBMS_LOB.SUBSTR(VALUE, 4000)         AS VALUE,
           ROW_NUMBER() OVER (ORDER BY WORKLOAD_NAME) AS rn
    FROM OCI_WORKLOADS
    WHERE VALUE IS NOT NULL
  ) LOOP
    IF rec.VALUE IS NOT NULL THEN
      INSERT INTO PAGE1_CONS_WRKLD_WEEK_CHART_DATA (
        WORKLOAD_NAME,
        WEEK_START,
        COST,
        LAST_REFRESH
      )
      SELECT
        rec.WORKLOAD_NAME,
        TRUNC(fr.DATE_BUCKET, 'IW') AS WEEK_START,
        SUM(fr.COST)                AS COST,
        SYSDATE
      FROM COST_USAGE_TIMESERIES_DAILY fr
      WHERE fr.DATE_BUCKET >= (TRUNC(SYSDATE, 'IW') - INTERVAL '56' DAY)
        AND fr.DATE_BUCKET <  TRUNC(SYSDATE, 'IW')  -- exclude current week
        AND EXISTS (
          SELECT 1
          FROM TABLE(APEX_STRING.SPLIT(rec.VALUE, ',')) w
          WHERE TRIM(w.column_value) = fr.OCI_COMPARTMENTID
             OR TRIM(w.column_value) = fr.COSTCENTER
        )
      GROUP BY TRUNC(fr.DATE_BUCKET, 'IW');
    END IF;
  END LOOP;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POPULATE_OKE_RELATIONSHIPS_PROC" IS
BEGIN
    -- Optional: Clear old data
    EXECUTE IMMEDIATE 'TRUNCATE TABLE OCI_RESOURCE_OKE_RELATIONSHIPS';

    INSERT INTO OCI_RESOURCE_OKE_RELATIONSHIPS (
        CHILD_DISPLAY_NAME,
        CHILD_RESOURCE_TYPE,
        PARENT_DISPLAY_NAME,
        PARENT_RESOURCE_TYPE,
        RAW_CLUSTER_ID,
        NORMALIZED_CLUSTER_ID,
        NODE_TYPE,
        SNAPSHOT_DATE
    )
    SELECT
        child.DISPLAY_NAME,
        child.RESOURCE_TYPE,
        parent.DISPLAY_NAME,
        parent.RESOURCE_TYPE,
        JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
        REGEXP_REPLACE(
            JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
            '^default/',
            ''
        ),
        JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".NodeType'),
        SYSDATE
    FROM
        OCI_RESOURCES_PY child
    LEFT JOIN
        OCI_RESOURCES_PY parent
        ON REGEXP_REPLACE(
               JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster'),
               '^default/',
               ''
           ) IN (parent.DISPLAY_NAME, parent.IDENTIFIER)
    WHERE
        JSON_EXISTS(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster')
        AND JSON_VALUE(child.SYSTEM_TAGS, '$."orcl-containerengine".Cluster') IS NOT NULL;

    COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "POPULATE_RESOURCE_RELATIONSHIPS_PROC" IS
BEGIN
    -- Optional: Clear old data first
    EXECUTE IMMEDIATE 'TRUNCATE TABLE OCI_RESOURCE_RELATIONSHIPS';

    INSERT INTO OCI_RESOURCE_RELATIONSHIPS (
        CHILD_DISPLAY_NAME,
        CHILD_IDENTIFIER,
        CHILD_RESOURCE_TYPE,
        PARENT_DISPLAY_NAME,
        PARENT_IDENTIFIER,
        PARENT_RESOURCE_TYPE,
        RAW_CREATED_BY,
        NORMALIZED_CREATED_BY,
        SNAPSHOT_DATE
    )
    SELECT
        child.DISPLAY_NAME,
        child.IDENTIFIER,
        child.RESOURCE_TYPE,
        parent.DISPLAY_NAME,
        parent.IDENTIFIER,
        parent.RESOURCE_TYPE,
        JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
        REGEXP_REPLACE(
            JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
            '^default/',
            ''
        ),
        SYSDATE
    FROM
        OCI_RESOURCES_PY child
    LEFT JOIN
        OCI_RESOURCES_PY parent
        ON REGEXP_REPLACE(
               JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"'),
               '^default/',
               ''
           ) IN (parent.DISPLAY_NAME, parent.IDENTIFIER)
    WHERE
        JSON_VALUE(child.DEFINED_TAGS, '$."Oracle-Tags"."CreatedBy"') IS NOT NULL;

    COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "RA_NIGHTLY_REFRESH_PROC" (
  p_run_id OUT NUMBER
) AS
  l_scope_list VARCHAR2(4000) := 'ROOT';
  l_params_json CLOB;
  l_t0_run      TIMESTAMP;
  l_t0_step     TIMESTAMP;
  l_elapsed_ms  NUMBER;

  FUNCTION elapsed_ms(p_from IN TIMESTAMP) RETURN NUMBER IS
  BEGIN
    RETURN (EXTRACT(DAY    FROM (SYSTIMESTAMP - p_from)) * 24 * 60 * 60 * 1000)
         + (EXTRACT(HOUR   FROM (SYSTIMESTAMP - p_from)) * 60 * 60 * 1000)
         + (EXTRACT(MINUTE FROM (SYSTIMESTAMP - p_from)) * 60 * 1000)
         + (EXTRACT(SECOND FROM (SYSTIMESTAMP - p_from)) * 1000);
  END elapsed_ms;

  PROCEDURE log_msg(
    p_level         IN VARCHAR2,
    p_step          IN VARCHAR2,
    p_message       IN VARCHAR2,
    p_details_json  IN CLOB DEFAULT NULL,
    p_rows_affected IN NUMBER DEFAULT NULL,
    p_elapsed_ms    IN NUMBER DEFAULT NULL
  ) IS
  BEGIN
    DBMS_OUTPUT.put_line(
      TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS TZH:TZM') ||
      ' [' || UPPER(p_level) || '] ' || p_step || ' - ' || p_message
    );

    IF p_run_id IS NOT NULL THEN
      OCI_LOG_PKG.log_msg(
        p_run_id        => p_run_id,
        p_level         => p_level,
        p_step          => p_step,
        p_message       => p_message,
        p_details_json  => p_details_json,
        p_rows_affected => p_rows_affected,
        p_elapsed_ms    => p_elapsed_ms
      );
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END log_msg;

  PROCEDURE run_compute(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'COMPUTE_START', 'Starting Compute collector for scope ' || p_scope);
    OCI_COMPUTE_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_COMPUTE_' || p_scope);
    log_msg('INFO', 'COMPUTE_DONE', 'Finished Compute collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_compute;

  PROCEDURE run_network(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'NETWORK_START', 'Starting Network collector for scope ' || p_scope);
    OCI_NETWORK_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_NETWORK_' || p_scope);
    log_msg('INFO', 'NETWORK_DONE', 'Finished Network collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_network;

  PROCEDURE run_database(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'DATABASE_START', 'Starting Database collector for scope ' || p_scope);
    OCI_DATABASE_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_DATABASE_' || p_scope);
    log_msg('INFO', 'DATABASE_DONE', 'Finished Database collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_database;

  PROCEDURE run_oke(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'OKE_START', 'Starting OKE collector for scope ' || p_scope);
    OCI_OKE_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_OKE_' || p_scope);
    log_msg('INFO', 'OKE_DONE', 'Finished OKE collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_oke;

  PROCEDURE run_lb(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'LB_START', 'Starting Load Balancer collector for scope ' || p_scope);
    OCI_LOAD_BALANCER_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_LB_' || p_scope);
    log_msg('INFO', 'LB_DONE', 'Finished Load Balancer collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_lb;

  PROCEDURE run_object_storage(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'OBJECT_STORAGE_START', 'Starting Object Storage collector for scope ' || p_scope);
    OCI_OBJECT_STORAGE_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_OBJECT_STORAGE_' || p_scope);
    log_msg('INFO', 'OBJECT_STORAGE_DONE', 'Finished Object Storage collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_object_storage;

  PROCEDURE run_cache(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'OCI_CACHE_START', 'Starting OCI Cache collector for scope ' || p_scope);
    OCI_CACHE_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_OCI_CACHE_' || p_scope);
    log_msg('INFO', 'OCI_CACHE_DONE', 'Finished OCI Cache collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_cache;

  PROCEDURE run_waf(p_scope IN VARCHAR2) IS
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'WAF_START', 'Starting WAF collector for scope ' || p_scope);
    OCI_WAF_TOPOLOGY_COLLECTOR_PKG.run(p_scope => p_scope, p_job_name => 'RA_NIGHTLY_WAF_' || p_scope);
    log_msg('INFO', 'WAF_DONE', 'Finished WAF collector for scope ' || p_scope, p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_waf;

  PROCEDURE run_scope(p_scope IN VARCHAR2) IS
    l_scope VARCHAR2(30) := UPPER(TRIM(p_scope));
  BEGIN
    l_t0_step := SYSTIMESTAMP;
    log_msg('INFO', 'SCOPE_START', 'Starting Resource Analytics collectors for scope ' || l_scope, '{"scope":"' || REPLACE(l_scope, '"', '\"') || '"}');

    run_compute(l_scope);
    run_network(l_scope);
    run_database(l_scope);
    run_oke(l_scope);
    run_lb(l_scope);
    run_object_storage(l_scope);
    run_cache(l_scope);
    run_waf(l_scope);

    log_msg('INFO', 'SCOPE_DONE', 'Finished Resource Analytics collectors for scope ' || l_scope, '{"scope":"' || REPLACE(l_scope, '"', '\"') || '"}', p_elapsed_ms => elapsed_ms(l_t0_step));
  END run_scope;
BEGIN
  p_run_id := NULL;
  l_t0_run := SYSTIMESTAMP;

  SELECT JSON_OBJECT(
           'root_scope' VALUE 'ROOT',
           'child_scope_query' VALUE 'APP_CONFIG CONFIG_KEY LIKE OCI_ROOT_CHILD%_COMPARTMENT_OCID AND CONFIG_VALUE IS NOT NULL',
           'started_at' VALUE TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SSTZH:TZM')
           RETURNING CLOB
         )
    INTO l_params_json
    FROM dual;

  OCI_LOG_PKG.start_run(
    p_job_name    => 'RESOURCE_ANALYTICS_NIGHTLY_REFRESH',
    p_module      => 'RA_NIGHTLY_REFRESH_PROC',
    p_params_json => l_params_json,
    p_run_id      => p_run_id
  );

  DECLARE
    l_lockhandle VARCHAR2(128);
    l_res        PLS_INTEGER;
  BEGIN
    DBMS_LOCK.allocate_unique('RA_NIGHTLY_REFRESH_PROC.RUN', l_lockhandle);

    l_res := DBMS_LOCK.request(
               lockhandle        => l_lockhandle,
               lockmode          => DBMS_LOCK.x_mode,
               timeout           => 0,
               release_on_commit => TRUE
             );

    IF l_res <> 0 THEN
      RAISE_APPLICATION_ERROR(-20001, 'Another Resource Analytics nightly refresh run is in progress.');
    END IF;
  END;

  log_msg('INFO', 'START', 'Starting Resource Analytics nightly refresh');

  run_scope('ROOT');

  FOR c IN (
    SELECT REGEXP_REPLACE(config_key, '^OCI_ROOT_(.*)_COMPARTMENT_OCID$', '\1') AS scope_name,
           config_key,
           config_value
      FROM app_config
     WHERE config_key LIKE 'OCI_ROOT_CHILD%_COMPARTMENT_OCID'
       AND config_value IS NOT NULL
       AND TRIM(config_value) IS NOT NULL
     ORDER BY config_key
  ) LOOP
    l_scope_list := SUBSTR(l_scope_list || ',' || c.scope_name, 1, 4000);
    log_msg(
      'INFO',
      'CHILD_SCOPE_FOUND',
      'Configured child scope ' || c.scope_name || ' from ' || c.config_key,
      '{"config_key":"' || REPLACE(c.config_key, '"', '\"') || '","scope":"' || REPLACE(c.scope_name, '"', '\"') || '"}'
    );
    run_scope(c.scope_name);
  END LOOP;

  l_t0_step := SYSTIMESTAMP;
  log_msg('INFO', 'GRAPH_REFRESH_START', 'Refreshing resource graph snapshot for scopes ' || l_scope_list);
  RESOURCE_GRAPH_ETL_PKG.refresh_snapshot('Nightly Resource Analytics ingest refresh for scopes ' || l_scope_list);
  log_msg('INFO', 'GRAPH_REFRESH_DONE', 'Finished resource graph snapshot refresh', p_elapsed_ms => elapsed_ms(l_t0_step));

  l_t0_step := SYSTIMESTAMP;
  log_msg('INFO', 'CACHE_REFRESH_START', 'Refreshing resource graph traversal cache');
  RESOURCE_GRAPH_TRAVERSAL_CACHE_PKG.refresh_snapshot(
    p_snapshot_id => RESOURCE_GRAPH_ETL_PKG.get_latest_snapshot_id
  );
  log_msg('INFO', 'CACHE_REFRESH_DONE', 'Finished resource graph traversal cache refresh', p_elapsed_ms => elapsed_ms(l_t0_step));

  l_elapsed_ms := elapsed_ms(l_t0_run);
  log_msg(
    p_level      => 'INFO',
    p_step       => 'DONE',
    p_message    => 'Finished Resource Analytics nightly refresh for scopes ' || l_scope_list,
    p_details_json => '{"scopes":"' || REPLACE(l_scope_list, '"', '\"') || '"}',
    p_elapsed_ms => l_elapsed_ms
  );

  OCI_LOG_PKG.end_run_success(p_run_id);
EXCEPTION
  WHEN OTHERS THEN
    log_msg(
      p_level       => 'ERROR',
      p_step        => 'FAILED',
      p_message     => SQLERRM,
      p_details_json => TO_CLOB(DBMS_UTILITY.format_error_backtrace),
      p_elapsed_ms  => CASE WHEN l_t0_run IS NOT NULL THEN elapsed_ms(l_t0_run) END
    );

    IF p_run_id IS NOT NULL THEN
      OCI_LOG_PKG.end_run_error(p_run_id, SQLCODE, SQLERRM);
    END IF;

    RAISE;
END RA_NIGHTLY_REFRESH_PROC;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_COST_USAGE_TS_PROC" AS
  -- 12 months back from today; adjust to 'MM' if you want month-aligned
  l_from_ts TIMESTAMP := ADD_MONTHS(TRUNC(SYSTIMESTAMP, 'DD'), -12);
BEGIN
  EXECUTE IMMEDIATE 'ALTER SESSION ENABLE PARALLEL DML';

  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_DAILY';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_WEEKLY';
  EXECUTE IMMEDIATE 'TRUNCATE TABLE COST_USAGE_TIMESERIES_MONTHLY';

  ---------------------------------------------------------------------------
  -- DAILY: only partitions with CHARGEPERIODSTART >= l_from_ts are scanned
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(fr 8) PARALLEL(orp 8) PARALLEL(ocp 8) */
  INTO COST_USAGE_TIMESERIES_DAILY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(fr.CHARGEPERIODSTART, 'DDD') AS DATE_BUCKET,
    fr.BILLINGACCOUNTID, fr.SUBACCOUNTNAME, fr.INVOICEISSUER, fr.REGION, fr.BILLINGCURRENCY,
    NVL(fr.SERVICECATEGORY, 'None') AS SERVICECATEGORY,
    fr.SERVICENAME, fr.CHARGEDESCRIPTION, fr.RESOURCETYPE, fr.RESOURCEID,
    orp.DISPLAY_NAME AS RESOURCENAME,
    fr.SKUID, fr.PRICINGUNIT, fr.OCI_COMPARTMENTID, fr.OCI_COMPARTMENTNAME,
    ocp.PATH AS OCI_COMPARTMENT_PATH,
    fr.USAGEUNIT,
    -- billed cost with fallback to effective cost
    SUM(
      NVL(
        NULLIF(fr.BILLEDCOST, 0),
        fr.EFFECTIVECOST
      )
    ) AS COST,
    SUM(
      CASE
        WHEN LOWER(fr.USAGEUNIT) LIKE '%month%' THEN fr.USAGEQUANTITY * (730 / 24)
        ELSE fr.USAGEQUANTITY / 24
      END
    ) AS USAGE,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Tags.CreatedBy"'),
      '[^/]+$'
    ) AS CREATED_BY,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Implementor"'),
      '[^/]+$'
    ) AS IMPLEMENTOR,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Environment"'),
      '[^/]+$'
    ) AS ENVIRONMENT,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.CostCenter"'),
      '[^/]+$'
    ) AS COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM FOCUS_REPORTS_PY fr
  LEFT JOIN OCI_RESOURCES_PY    orp ON fr.RESOURCEID        = orp.IDENTIFIER
  LEFT JOIN OCI_COMPARTMENTS_PY ocp ON fr.OCI_COMPARTMENTID = ocp.COMPARTMENT_ID
  WHERE
        fr.CHARGEPERIODSTART >= l_from_ts                -- 12 months back, drives pruning
    AND fr.CHARGEPERIODEND   <= ADD_MONTHS(fr.CHARGEPERIODSTART, 7)
    AND NVL(NULLIF(fr.BILLEDCOST, 0), fr.EFFECTIVECOST) > 0
    AND fr.USAGEQUANTITY > 0
  GROUP BY
    TRUNC(fr.CHARGEPERIODSTART, 'DDD'),
    fr.BILLINGACCOUNTID, fr.SUBACCOUNTNAME, fr.INVOICEISSUER, fr.REGION, fr.BILLINGCURRENCY,
    fr.SERVICECATEGORY, fr.SERVICENAME, fr.CHARGEDESCRIPTION, fr.RESOURCETYPE, fr.RESOURCEID,
    orp.DISPLAY_NAME, fr.SKUID, fr.PRICINGUNIT, fr.OCI_COMPARTMENTID, fr.OCI_COMPARTMENTNAME,
    ocp.PATH, fr.USAGEUNIT,
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Tags.CreatedBy"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Environment"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.CostCenter"'),
      '[^/]+$'
    ),
    REGEXP_SUBSTR(
      JSON_VALUE(fr.TAGS, '$."Oracle-Standard.Implementor"'),
      '[^/]+$'
    );

  ---------------------------------------------------------------------------
  -- WEEKLY: aggregate from DAILY (already last 12 months only)
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(8) */
  INTO COST_USAGE_TIMESERIES_WEEKLY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(DATE_BUCKET, 'IW') AS DATE_BUCKET,
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    SUM(COST)  AS COST,
    SUM(USAGE) AS USAGE,
    CREATED_BY,
    IMPLEMENTOR,
    ENVIRONMENT,
    COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM COST_USAGE_TIMESERIES_DAILY
  GROUP BY
    TRUNC(DATE_BUCKET, 'IW'),
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER;

  ---------------------------------------------------------------------------
  -- MONTHLY: aggregate from DAILY (already last 12 months only)
  ---------------------------------------------------------------------------
  INSERT /*+ APPEND PARALLEL(8) */
  INTO COST_USAGE_TIMESERIES_MONTHLY (
    DATE_BUCKET, BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    COST, USAGE, CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER, LAST_REFRESH
  )
  SELECT
    TRUNC(DATE_BUCKET, 'MM') AS DATE_BUCKET,
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    SUM(COST)  AS COST,
    SUM(USAGE) AS USAGE,
    CREATED_BY,
    IMPLEMENTOR,
    ENVIRONMENT,
    COSTCENTER,
    SYSDATE AS LAST_REFRESH
  FROM COST_USAGE_TIMESERIES_DAILY
  GROUP BY
    TRUNC(DATE_BUCKET, 'MM'),
    BILLINGACCOUNTID, SUBACCOUNTNAME, INVOICEISSUER, REGION, BILLINGCURRENCY,
    SERVICECATEGORY, SERVICENAME, CHARGEDESCRIPTION, RESOURCETYPE, RESOURCEID, RESOURCENAME,
    SKUID, PRICINGUNIT, OCI_COMPARTMENTID, OCI_COMPARTMENTNAME, OCI_COMPARTMENT_PATH, USAGEUNIT,
    CREATED_BY, IMPLEMENTOR, ENVIRONMENT, COSTCENTER;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_CREDIT_CONSUMPTION_STATE_PROC" IS

  TYPE slice_rec IS RECORD (
    rid                ROWID,
    subscription_id    credit_consumption_state.subscription_id%TYPE,
    time_start         credit_consumption_state.time_start%TYPE,
    original_quantity  credit_consumption_state.original_quantity%TYPE,
    remaining_quantity credit_consumption_state.remaining_quantity%TYPE,
    depleted           credit_consumption_state.depleted%TYPE
  );
  TYPE slice_tab IS TABLE OF slice_rec INDEX BY PLS_INTEGER;

  TYPE charge_rec IS RECORD (
    chargeperiodstart focus_reports_py.chargeperiodstart%TYPE,
    billedcost        focus_reports_py.billedcost%TYPE
  );
  TYPE charge_tab IS TABLE OF charge_rec INDEX BY PLS_INTEGER;

  slices        slice_tab;
  charges       charge_tab;

  i             INTEGER;
  j             INTEGER;
  slice_count   INTEGER;
  charge_count  INTEGER;
  last_index    INTEGER;
  running_total NUMBER;
  v_used        NUMBER;
  v_last_date   DATE;

BEGIN
  -----------------------------------------------------------------------------
  -- Phase 1: Truncate and populate CREDIT_CONSUMPTION_STATE from ACTIVE subs +
  --          commitments (no slices; keep commitment periods)
  -----------------------------------------------------------------------------
  EXECUTE IMMEDIATE 'TRUNCATE TABLE credit_consumption_state';

  INSERT INTO credit_consumption_state (
    subscription_line_id,
    subscription_id,
    billingaccountid,
    order_number,
    time_start,
    time_end,
    original_quantity,
    remaining_quantity,
    depleted,
    iso_code,
    last_consumed_at,
    last_updated
  )
  SELECT
    p.subscription_line_id,
    p.subscription_id,
    p.subscription_id AS billingaccountid,
    p.order_number,
    c.commitment_time_start AS time_start,
    c.commitment_time_end   AS time_end,

    TO_NUMBER(
      REPLACE(REGEXP_REPLACE(c.commitment_quantity, '[^0-9\.\-]', ''), ',', ''),
      '999999999999999999999999999999D999999999999999999',
      'NLS_NUMERIC_CHARACTERS=.,'
    ) AS original_quantity,

    CASE
      WHEN TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           ) <= 200
      THEN NULL
      ELSE TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           )
    END AS remaining_quantity,

    CASE
      WHEN TO_NUMBER(
             REPLACE(REGEXP_REPLACE(c.commitment_available_amt, '[^0-9\.\-]', ''), ',', ''),
             '999999999999999999999999999999D999999999999999999',
             'NLS_NUMERIC_CHARACTERS=.,'
           ) <= 200
      THEN 1
      ELSE 0
    END AS depleted,

    p.iso_code,
    NULL AS last_consumed_at,
    SYSDATE AS last_updated
  FROM oci_subscriptions_py p
  JOIN oci_subscription_commitments c
    ON c.subscription_line_id = p.subscription_line_id
  WHERE p.substatus = 'ACTIVE'
    AND c.commitment_time_start IS NOT NULL
    AND c.commitment_time_end   IS NOT NULL;

  -----------------------------------------------------------------------------
  -- Phase 2: Update LAST_CONSUMED_AT by back-calculating from current active order
  -----------------------------------------------------------------------------
  FOR sub IN (SELECT DISTINCT subscription_id FROM credit_consumption_state) LOOP

    v_used := NULL;
    slices.DELETE;
    charges.DELETE;

    -- Step 1: Get consumed amount from latest non-depleted order
    BEGIN
      SELECT original_quantity - NVL(remaining_quantity, 0)
        INTO v_used
        FROM (
          SELECT original_quantity, remaining_quantity
            FROM credit_consumption_state
           WHERE subscription_id = sub.subscription_id
             AND depleted = 0
           ORDER BY time_start DESC
        )
       WHERE ROWNUM = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        CONTINUE;
    END;

    -- Step 2: Get ALL depleted = 1 rows ordered by time_start DESC
    SELECT rowid, subscription_id, time_start, original_quantity, NVL(remaining_quantity, 0), depleted
      BULK COLLECT INTO slices
      FROM credit_consumption_state
     WHERE subscription_id = sub.subscription_id
       AND depleted = 1
     ORDER BY time_start DESC;

    slice_count := slices.COUNT;

    IF slice_count = 0 THEN
      CONTINUE;
    END IF;

    -- Step 3: Get charges, newest to oldest
    SELECT chargeperiodstart, billedcost
      BULK COLLECT INTO charges
      FROM focus_reports_py
     WHERE billingaccountid = sub.subscription_id
       AND billedcost > 0
     ORDER BY chargeperiodstart DESC;

    charge_count := charges.COUNT;
    last_index := 1;

    -- Step 4: FIRST depleted slice gets updated using v_used from current order
    running_total := 0;

    FOR j IN last_index .. charge_count LOOP
      running_total := running_total + charges(j).billedcost;

      IF running_total >= v_used THEN
        UPDATE credit_consumption_state
           SET last_consumed_at = charges(j).chargeperiodstart
         WHERE ROWID = slices(1).rid;

        v_last_date := charges(j).chargeperiodstart;
        last_index := j + 1;
        EXIT;
      END IF;
    END LOOP;

    -- Step 5: Remaining depleted slices get full original_quantity matched
    FOR i IN 2 .. slice_count LOOP
      running_total := 0;

      FOR j IN last_index .. charge_count LOOP
        IF charges(j).chargeperiodstart < v_last_date THEN
          running_total := running_total + charges(j).billedcost;

          IF running_total >= slices(i - 1).original_quantity THEN
            UPDATE credit_consumption_state
               SET last_consumed_at = charges(j).chargeperiodstart
             WHERE ROWID = slices(i).rid;

            v_last_date := charges(j).chargeperiodstart;
            last_index := j + 1;
            EXIT;
          END IF;
        END IF;
      END LOOP;
    END LOOP;

  END LOOP;

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "REFRESH_CREDIT_USAGE_AGG_PROC" AS
BEGIN
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CREDIT_USAGE_AGG';

  INSERT INTO CREDIT_USAGE_AGG (BILLINGACCOUNTID, CHARGEPERIODEND, BILLEDCOST, HOURLY_COST)
  SELECT
    BILLINGACCOUNTID,
    TRUNC(CHARGEPERIODEND, 'HH') AS CHARGEPERIODEND,
    SUM(BILLEDCOST) AS BILLEDCOST,
    SUM(BILLEDCOST) / 1 AS HOURLY_COST
  FROM FOCUS_REPORTS_PY
  WHERE CHARGEPERIODEND >= SYSDATE - 30  -- or -90 for 3 months of history
  GROUP BY BILLINGACCOUNTID, TRUNC(CHARGEPERIODEND, 'HH');

  COMMIT;
END;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SUMMARIZE_DDL_AND_UPSERT" 
(
  p_ddl_text        in  clob,         -- raw CREATE TABLE ... ;
  p_dataset         in  varchar2,     -- e.g. 'LATEST'
  p_environment     in  varchar2,     -- e.g. 'TEST'
  p_model_id        in  varchar2 default null,  -- override; else APP_CONFIG.MODEL_ID
  p_target_table    in  varchar2 default 'TEST_CHATBOT_NL2SQL_SUMMARY',
  p_id_sequence     in  varchar2 default null,  -- set if target table needs ID via sequence
  p_auto_commit     in  boolean  default false, -- caller controls commit
  -- outs
  p_summary_json    out clob,
  p_summary_row_op  out varchar2
)
as
  -- runtime context
  l_model_id        varchar2(1000);
  l_compartment_id  varchar2(4000);
  l_chat_id         number := trunc(dbms_random.value(10000,99999));
  l_app_user        varchar2(128)  := coalesce(v('APP_USER'), sys_context('USERENV','SESSION_USER'));
  l_app_session     varchar2(4000) := coalesce(v('APP_SESSION'), 'N/A');
  -- llm i/o
  l_prompt           clob;
  l_row_id           number;
  l_final_sql        clob;
  l_final_response   clob;
  l_final_aimessage  clob;
  -- json & merge
  l_json_obj         json_object_t;
  l_table_name       varchar2(256);
  l_summary_text     clob;
  l_op               varchar2(10);
  -- for UNKNOWN.<TABLE> fix
  l_table_override   varchar2(256);
begin
  -- basic checks
  if p_ddl_text is null then
    raise_application_error(-20050, 'DDL text is required.');
  end if;
  if p_dataset is null or p_environment is null then
    raise_application_error(-20051, 'DATASET and ENVIRONMENT are required.');
  end if;
  ---------------------------------------------------------------------------
  -- Resolve model/compartment from APP_CONFIG (caller can override model)
  ---------------------------------------------------------------------------
  declare
    v_model_id_app       varchar2(1000);
    v_compartment_id_app varchar2(4000);
  begin
    begin
      select config_value into v_model_id_app
      from app_config where upper(config_key) = 'MODEL_ID';
    exception when no_data_found then v_model_id_app := null; end;
    begin
      select config_value into v_compartment_id_app
      from app_config where upper(config_key) = 'COMPARTMENT_ID';
    exception when no_data_found then v_compartment_id_app := null; end;
    l_model_id       := coalesce(p_model_id, v_model_id_app);
    l_compartment_id := v_compartment_id_app;
  end;
  if l_model_id is null then
    raise_application_error(-20060, 'MODEL_ID is not set (p_model_id is NULL and APP_CONFIG.MODEL_ID missing).');
  end if;
  if l_compartment_id is null then
    raise_application_error(-20061, 'COMPARTMENT_ID is not set in APP_CONFIG.');
  end if;
  ---------------------------------------------------------------------------
  -- Build LLM instruction (JSON-only)
  ---------------------------------------------------------------------------
  l_prompt := q'[
You are a precise SQL DDL summarization engine that converts any CREATE TABLE statement into a structured JSON description for NL2SQL routing.
Return ONLY valid JSON (no markdown, no code fences, no trailing commas, no commentary).
Expected JSON:
{
  "summary": "One short sentence (≤150 chars) describing the table in business terms.",
  "table_name": "<OWNER>.<TABLE_NAME>",
  "keys": ["<col>", "..."],
  "metrics": ["<col>", "..."],
  "attributes": ["<col>", "..."],
  "notes": ""
}
Rules
- Use ONLY columns present in the DDL. Uppercase all names.
- table_name: if schema missing, use "UNKNOWN.<TABLE_NAME>".
- keys: if a PRIMARY KEY exists, use it in declared order; else best-guess identifiers (names ending with _ID, _NO, _CODE, DATE/DT).
- metrics: numeric/measurable columns (NUMBER/DECIMAL/FLOAT/INTEGER, or names with COUNT/AMOUNT/TOTAL/AVG/RATE/SCORE/BALANCE/QUANTITY).
- attributes: everything else (names, categories, regions, statuses, flags).
- Arrays contain unique strings; include empty arrays if none.
- Output must be strictly valid JSON.
DDL:
]' || p_ddl_text;
  ---------------------------------------------------------------------------
  -- Call headless LLM (no logging) and keep the same validation
  ---------------------------------------------------------------------------
  l_final_aimessage := llm_call_text(
    p_message        => l_prompt,
    p_model_id       => l_model_id,
    p_compartment_id => l_compartment_id
  );
  if l_final_aimessage is null or trim(l_final_aimessage) is null then
    raise_application_error(-20052, 'LLM returned empty content.');
  end if;
  -- Validate JSON (19c+ compatible)
  declare
    v_dummy number;
  begin
    select 1 into v_dummy from dual where l_final_aimessage is json strict;
  exception
    when others then
      raise_application_error(-20053, 'LLM did not return valid JSON.');
  end;
  l_json_obj := json_object_t.parse(l_final_aimessage);
  if not l_json_obj.has('summary') or
     not l_json_obj.has('table_name') or
     not l_json_obj.has('keys') or
     not l_json_obj.has('metrics') or
     not l_json_obj.has('attributes') then
    raise_application_error(-20054, 'JSON missing required fields.');
  end if;
  ---------------------------------------------------------------------------
  -- Fix table_name if LLM emitted UNKNOWN.<TABLE> — derive OWNER.TABLE from DDL
  ---------------------------------------------------------------------------
  declare
    v_raw   varchar2(4000);
    v_owner varchar2(128) := upper(nvl(sys_context('USERENV','CURRENT_SCHEMA'),'UNKNOWN'));
    v_name  varchar2(4000);
  begin
    v_raw := regexp_substr(p_ddl_text,
            'create\s+table\s+((?:\"?[[:alnum:]_]+\"?\.)?\"?[[:alnum:]_]+\"?)',
            1, 1, 'in', 1);
    v_raw := replace(upper(nvl(v_raw,'')),'"','');
    if v_raw is not null then
      if instr(v_raw,'.') > 0 then
        l_table_override := v_raw;                     -- schema provided
      else
        l_table_override := v_owner||'.'||v_raw;       -- prefix current schema
      end if;
    else
      v_name := replace(upper(regexp_substr(p_ddl_text,'([[:alnum:]_"]+)\s*\(',1,1,'in',1)),'"','');
      if v_name is not null then
        l_table_override := v_owner||'.'||v_name;
      end if;
    end if;
  end;
  l_table_name   := upper(l_json_obj.get_string('table_name'));
  if l_table_override is not null and l_table_name like 'UNKNOWN.%' then
    l_table_name := l_table_override;
  end if;
  l_summary_text := l_final_aimessage;  -- store raw JSON
  ---------------------------------------------------------------------------
  -- MERGE into target table (identity or sequence)
  ---------------------------------------------------------------------------
  declare
    l_sql   clob;
    l_count integer;
  begin
    if p_id_sequence is null then
      l_sql :=
        'merge into '||p_target_table||' t '||
        'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
        '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
        'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
        'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
        'when not matched then insert (dataset, environment, table_name, last_refreshed, summary_text) '||
        'values (s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
      execute immediate l_sql using p_dataset, p_environment, l_table_name, l_summary_text;
    else
      l_sql :=
        'merge into '||p_target_table||' t '||
        'using (select :dataset as dataset, :env as environment, :tname as table_name, '||
        '              systimestamp as last_refreshed, :sumtxt as summary_text from dual) s '||
        'on (t.dataset = s.dataset and t.environment = s.environment and t.table_name = s.table_name) '||
        'when matched then update set t.last_refreshed = s.last_refreshed, t.summary_text = s.summary_text '||
        'when not matched then insert (id, dataset, environment, table_name, last_refreshed, summary_text) '||
        'values ('||p_id_sequence||'.nextval, s.dataset, s.environment, s.table_name, s.last_refreshed, s.summary_text)';
      execute immediate l_sql using p_dataset, p_environment, l_table_name, l_summary_text;
    end if;
    -- detect op (insert vs update)
    l_sql :=
      'select count(*) from '||p_target_table||
      ' where dataset = :1 and environment = :2 and table_name = :3'||
      '   and last_refreshed >= systimestamp - interval ''1'' minute';
    execute immediate l_sql into l_count using p_dataset, p_environment, l_table_name;
    l_op := case when l_count = 1 then 'UPDATE' else 'INSERT' end;
  end;
  -- outs
  p_summary_json   := l_summary_text;
  p_summary_row_op := l_op;
  if p_auto_commit then commit; end if;
end;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "SYNC_AI_MODEL_CONFIG_FROM_OCI" IS
  credential_name CONSTANT VARCHAR2(100) := 'OCI$RESOURCE_PRINCIPAL';
  TYPE region_list_t IS TABLE OF VARCHAR2(50);
  regions region_list_t := region_list_t('eu-frankfurt-1');
  compartment_ocid VARCHAR2(1000);
  resp           DBMS_CLOUD_TYPES.resp;
  response_clob  CLOB;
  region      VARCHAR2(50);
  request_uri VARCHAR2(1000);
  l_http_code   PLS_INTEGER;
  l_total_items PLS_INTEGER;
  l_inserted    PLS_INTEGER;
  l_first_item  VARCHAR2(4000);
BEGIN
  -- Get COMPARTMENT_ID from APP_CONFIG
  SELECT CONFIG_VALUE
    INTO compartment_ocid
    FROM APP_CONFIG
   WHERE CONFIG_KEY = 'COMPARTMENT_ID';
  -- Make sure you're truncating the right table and schema
  EXECUTE IMMEDIATE 'TRUNCATE TABLE AI_MODEL_CONFIG';
  -- Loop through regions
  FOR i IN 1 .. regions.COUNT LOOP
    region := regions(i);
    request_uri := 'https://generativeai.' || region ||
                   '.oci.oraclecloud.com/20231130/models?compartmentId=' ||
                   compartment_ocid;
    resp := DBMS_CLOUD.SEND_REQUEST(
              credential_name => credential_name,
              uri             => request_uri,
              method          => DBMS_CLOUD.METHOD_GET,
              headers         => '{"content-type":"application/json"}'
            );
    l_http_code := DBMS_CLOUD.GET_RESPONSE_STATUS_CODE(resp);
    response_clob := DBMS_CLOUD.GET_RESPONSE_TEXT(resp);
    DBMS_OUTPUT.PUT_LINE('Region ' || region || ' HTTP ' || l_http_code);
    IF l_http_code <> 200 THEN
      DBMS_OUTPUT.PUT_LINE('Body snippet: ' || SUBSTR(response_clob, 1, 1000));
      CONTINUE; -- skip this region on error
    END IF;
    -- Count how many items are at the path we expect
    SELECT COUNT(*)
      INTO l_total_items
      FROM JSON_TABLE(
             response_clob, '$.items[*]'
             COLUMNS ( dummy VARCHAR2(1) PATH '$.id' )
           );
    DBMS_OUTPUT.PUT_LINE('Parsed items at $.items[*]: ' || l_total_items);
    -- Insert only models with capability = 'CHAT' (case-insensitive)
    INSERT INTO AI_MODEL_CONFIG (
      MODEL_ID,
      MODEL_NAME,
      API_FORMAT,
      IS_DEFAULT,
      REGION,
      TEMPERATURE,
      TOP_P,
      TOP_K,
      FREQUENCY_PENALTY,
      PRESENCE_PENALTY
    )
    SELECT DISTINCT
      jt.model_id,
      jt.model_name,
      CASE
        WHEN REGEXP_LIKE(LOWER(COALESCE(jt.vendor, jt.model_id, jt.model_name)),
                         '(^|[^a-z])cohere([^a-z]|$)')
          OR REGEXP_LIKE(LOWER(NVL(jt.model_id,'')),  '(^|[._/\-])cohere([._/\-]|$)')
          OR REGEXP_LIKE(LOWER(NVL(jt.model_name,'')),'(^|[ _/\-])cohere([ _/\-]|$)')
        THEN 'COHERE'
        ELSE 'GENERIC'
      END AS api_format,
      'N' AS is_default,
      region,
      NULL, NULL, NULL, NULL, NULL
    FROM JSON_TABLE(
           response_clob, '$.items[*]'
           COLUMNS (
             model_id    VARCHAR2(1000) PATH '$.id',
             model_name  VARCHAR2(1000) PATH '$.displayName',
             vendor      VARCHAR2(100)  PATH '$.vendor' NULL ON ERROR,
             NESTED PATH '$.capabilities[*]'
               COLUMNS (cap VARCHAR2(64) PATH '$')
           )
         ) jt
    WHERE REGEXP_LIKE(jt.cap, '^CHAT$', 'i');
    l_inserted := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Inserted CHAT rows: ' || l_inserted);
    IF l_inserted = 0 THEN
      -- Dump a few capabilities to confirm what we got back
      DBMS_OUTPUT.PUT_LINE('No CHAT rows. Sample capabilities:');
      FOR r IN (
        SELECT DISTINCT cap
        FROM JSON_TABLE(
               response_clob, '$.items[*]'
               COLUMNS (
                 NESTED PATH '$.capabilities[*]'
                   COLUMNS (cap VARCHAR2(64) PATH '$')
               )
             )
        WHERE ROWNUM <= 10
      ) LOOP
        DBMS_OUTPUT.PUT_LINE('  - ' || r.cap);
      END LOOP;
      -- Also show the first item's id/name (do a SELECT ... INTO first)
      BEGIN
        SELECT NVL(model_name,'<null>') || ' / ' || NVL(model_id,'<null>')
          INTO l_first_item
          FROM JSON_TABLE(
                 response_clob, '$.items[0]'
                 COLUMNS (
                   model_id    VARCHAR2(1000) PATH '$.id',
                   model_name  VARCHAR2(1000) PATH '$.displayName'
                 )
               );
        DBMS_OUTPUT.PUT_LINE('First item name/id: ' || l_first_item);
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END IF;
  END LOOP;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('❌ Error: ' || SQLERRM);
    BEGIN
      DBMS_OUTPUT.PUT_LINE('Body snippet: ' || SUBSTR(response_clob, 1, 1000));
    EXCEPTION WHEN OTHERS THEN NULL; END;
    ROLLBACK;
END sync_ai_model_config_from_oci;
/

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_OCI_SUBSCRIPTION_DETAILS" AS
BEGIN
  MERGE INTO oci_subscription_details dst
  USING (
    SELECT DISTINCT
      c.subscription_line_id,
      TO_NUMBER(c.subscription_id) AS subscription_id,
      c.time_start,
      c.time_end,
      TO_NUMBER(c.order_number)    AS order_id,
      c.original_quantity          AS quantity
    FROM credit_consumption_state c
    WHERE c.subscription_line_id IS NOT NULL
      AND c.subscription_id IS NOT NULL
      AND c.order_number   IS NOT NULL
      AND REGEXP_LIKE(c.subscription_id, '^\d+$')
      AND REGEXP_LIKE(c.order_number,   '^\d+$')
  ) src
  ON (
    dst.subscription_line_id = src.subscription_line_id
    AND dst.time_start       = src.time_start
    AND dst.time_end         = src.time_end
  )

  WHEN MATCHED THEN
    UPDATE SET
      dst.subscription_id = src.subscription_id,
      dst.order_id        = src.order_id,
      dst.quantity        = src.quantity
      -- IMPORTANT: do NOT touch dst.order_name
  WHERE NVL(dst.subscription_id, -1) <> NVL(src.subscription_id, -1)
     OR NVL(dst.order_id, -1)        <> NVL(src.order_id, -1)
     OR NVL(dst.quantity, -1)        <> NVL(src.quantity, -1)

  WHEN NOT MATCHED THEN
    INSERT (
      subscription_line_id,
      subscription_id,
      time_start,
      time_end,
      order_id,
      quantity,
      order_name
    )
    VALUES (
      src.subscription_line_id,
      src.subscription_id,
      src.time_start,
      src.time_end,
      src.order_id,
      src.quantity,
      NULL  -- admin can set friendly name later
    );

  COMMIT;
END;
/
