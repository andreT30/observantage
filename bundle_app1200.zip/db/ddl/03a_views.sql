
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "COST_USAGE_DAILY_WKLD_V" ("DATE_BUCKET", "BILLINGACCOUNTID", "SUBACCOUNTNAME", "INVOICEISSUER", "REGION", "BILLINGCURRENCY", "SERVICECATEGORY", "SERVICENAME", "CHARGEDESCRIPTION", "RESOURCETYPE", "RESOURCEID", "RESOURCENAME", "SKUID", "PRICINGUNIT", "OCI_COMPARTMENTID", "OCI_COMPARTMENTNAME", "OCI_COMPARTMENT_PATH", "USAGEUNIT", "COST", "USAGE", "LAST_REFRESH", "CREATED_BY", "IMPLEMENTOR", "COSTCENTER", "ENVIRONMENT", "WORKLOAD_NAME")  AS 
  SELECT
  cutd."DATE_BUCKET",cutd."BILLINGACCOUNTID",cutd."SUBACCOUNTNAME",cutd."INVOICEISSUER",cutd."REGION",cutd."BILLINGCURRENCY",cutd."SERVICECATEGORY",cutd."SERVICENAME",cutd."CHARGEDESCRIPTION",cutd."RESOURCETYPE",cutd."RESOURCEID",cutd."RESOURCENAME",cutd."SKUID",cutd."PRICINGUNIT",cutd."OCI_COMPARTMENTID",cutd."OCI_COMPARTMENTNAME",cutd."OCI_COMPARTMENT_PATH",cutd."USAGEUNIT",cutd."COST",cutd."USAGE",cutd."LAST_REFRESH",cutd."CREATED_BY",cutd."IMPLEMENTOR",cutd."COSTCENTER",cutd."ENVIRONMENT",
  ow.WORKLOAD_NAME AS workload_name
FROM cost_usage_timeseries_daily cutd
JOIN OCI_WORKLOADS ow ON INSTR(',' || ow.VALUE || ',', ',' || cutd.OCI_COMPARTMENTID || ',') > 0 OR INSTR(',' || ow.VALUE || ',', ',' || cutd.COSTCENTER || ',') > 0;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "COST_USAGE_MONTHLY_WKLD_V" ("DATE_BUCKET", "BILLINGACCOUNTID", "SUBACCOUNTNAME", "INVOICEISSUER", "REGION", "BILLINGCURRENCY", "SERVICECATEGORY", "SERVICENAME", "CHARGEDESCRIPTION", "RESOURCETYPE", "RESOURCEID", "RESOURCENAME", "SKUID", "PRICINGUNIT", "OCI_COMPARTMENTID", "OCI_COMPARTMENTNAME", "OCI_COMPARTMENT_PATH", "USAGEUNIT", "COST", "USAGE", "LAST_REFRESH", "CREATED_BY", "IMPLEMENTOR", "COSTCENTER", "ENVIRONMENT", "WORKLOAD_NAME")  AS 
  SELECT
  cutd."DATE_BUCKET",cutd."BILLINGACCOUNTID",cutd."SUBACCOUNTNAME",cutd."INVOICEISSUER",cutd."REGION",cutd."BILLINGCURRENCY",cutd."SERVICECATEGORY",cutd."SERVICENAME",cutd."CHARGEDESCRIPTION",cutd."RESOURCETYPE",cutd."RESOURCEID",cutd."RESOURCENAME",cutd."SKUID",cutd."PRICINGUNIT",cutd."OCI_COMPARTMENTID",cutd."OCI_COMPARTMENTNAME",cutd."OCI_COMPARTMENT_PATH",cutd."USAGEUNIT",cutd."COST",cutd."USAGE",cutd."LAST_REFRESH",cutd."CREATED_BY",cutd."IMPLEMENTOR",cutd."COSTCENTER",cutd."ENVIRONMENT",
  ow.WORKLOAD_NAME AS workload_name
FROM cost_usage_timeseries_monthly cutd
JOIN OCI_WORKLOADS ow ON INSTR(',' || ow.VALUE || ',', ',' || cutd.OCI_COMPARTMENTID || ',') > 0 OR INSTR(',' || ow.VALUE || ',', ',' || cutd.COSTCENTER || ',') > 0;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_EFFECTIVE_PRICE" ("PART_NUMBER", "DISPLAY_NAME", "METRIC_NAME", "SERVICE_CATEGORY", "CURRENCY_CODE", "PRICE_MODEL", "CATALOG_UNIT_PRICE", "RATECARD_ACTUAL_UNIT_PRICE", "RATECARD_LIST_UNIT_PRICE", "EFFECTIVE_UNIT_PRICE", "PRICE_SOURCE", "FETCHED_AT", "SRC_URL")  AS 
  select lp.part_number,
       lp.display_name,
       lp.metric_name,
       lp.service_category,
       lp.currency_code,
       lp.price_model,
       lp.unit_price as catalog_unit_price,
       case
         when lp.currency_code = 'EUR' then rm.actualunitprice
         else null
       end as ratecard_actual_unit_price,
       rm.listunitprice as ratecard_list_unit_price,
       case
         when lp.currency_code = 'EUR' and rm.actualunitprice is not null then rm.actualunitprice
         else lp.unit_price
       end as effective_unit_price,
       case
         when lp.currency_code = 'EUR' and rm.actualunitprice is not null then 'RATECARD_MV.ACTUALUNITPRICE'
         else 'OCI_PRICE_CATALOG.UNIT_PRICE'
       end as price_source,
       lp.fetched_at,
       lp.src_url
  from oci_v_latest_catalog_price lp
  left join ratecard_mv rm
    on trim(rm.skuid) = trim(lp.part_number);

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_LINE_PRICE" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "EST_CONFIG_ID", "CONFIG_LABEL", "EST_SERVICE_ID", "SERVICE_ID", "SERVICE_LABEL", "EST_ITEM_ID", "PART_NUMBER", "QUANTITY", "IN_PRESET", "MIN_QUANTITY", "PRICE_MODEL", "CATALOG_UNIT_PRICE", "RATECARD_ACTUAL_UNIT_PRICE", "RATECARD_LIST_UNIT_PRICE", "EFFECTIVE_UNIT_PRICE", "PRICE_SOURCE", "STORED_UNIT_PRICE", "STORED_MONTHLY_COST", "COMPUTED_MONTHLY_COST", "COMPUTED_YEARLY_COST")  AS 
  select h.est_id,
       h.est_name,
       h.owner_username,
       h.currency_code,
       c.est_config_id,
       c.config_label,
       s.est_service_id,
       s.service_id,
       s.label as service_label,
       i.est_item_id,
       i.part_number,
       i.quantity,
       i.in_preset,
       i.min_quantity,
       ep.price_model,
       ep.catalog_unit_price,
       ep.ratecard_actual_unit_price,
       ep.ratecard_list_unit_price,
       ep.effective_unit_price,
       ep.price_source,
       i.unit_price as stored_unit_price,
       i.monthly_cost as stored_monthly_cost,
       (nvl(i.quantity, 0) * nvl(ep.effective_unit_price, nvl(i.unit_price, 0))) as computed_monthly_cost,
       (nvl(i.quantity, 0) * nvl(ep.effective_unit_price, nvl(i.unit_price, 0)) * 12) as computed_yearly_cost
  from oci_est_header h
  join oci_est_config c
    on c.est_id = h.est_id
  join oci_est_service s
    on s.est_config_id = c.est_config_id
  join oci_est_item i
    on i.est_service_id = s.est_service_id
  left join oci_v_effective_price ep
    on ep.part_number = i.part_number
   and ep.currency_code = h.currency_code
   and ep.price_model = 'PAY_AS_YOU_GO';

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_SERVICE_TOTAL" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "EST_SERVICE_ID", "SERVICE_ID", "SERVICE_LABEL", "TOTAL_MONTHLY_COST", "TOTAL_YEARLY_COST")  AS 
  select est_id,
       est_name,
       owner_username,
       currency_code,
       est_service_id,
       service_id,
       service_label,
       sum(computed_monthly_cost) as total_monthly_cost,
       sum(computed_yearly_cost) as total_yearly_cost
  from oci_v_estimate_line_price
 group by est_id,
          est_name,
          owner_username,
          currency_code,
          est_service_id,
          service_id,
          service_label;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_TOTAL" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "TOTAL_MONTHLY_COST", "TOTAL_YEARLY_COST")  AS 
  select est_id,
       est_name,
       owner_username,
       currency_code,
       sum(computed_monthly_cost) as total_monthly_cost,
       sum(computed_yearly_cost) as total_yearly_cost
  from oci_v_estimate_line_price
 group by est_id,
          est_name,
          owner_username,
          currency_code;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_LATEST_CATALOG_PRICE" ("PART_NUMBER", "DISPLAY_NAME", "METRIC_NAME", "SERVICE_CATEGORY", "CURRENCY_CODE", "PRICE_MODEL", "UNIT_PRICE", "FETCHED_AT", "SRC_URL")  AS 
  select p.part_number,
       p.display_name,
       p.metric_name,
       p.service_category,
       p.currency_code,
       p.price_model,
       p.unit_price,
       p.fetched_at,
       p.src_url
  from oci_price_catalog p
  join (
    select part_number,
           currency_code,
           price_model,
           max(fetched_at) as max_fetched_at
      from oci_price_catalog
     group by part_number, currency_code, price_model
  ) x
    on x.part_number = p.part_number
   and x.currency_code = p.currency_code
   and x.price_model = p.price_model
   and x.max_fetched_at = p.fetched_at;
