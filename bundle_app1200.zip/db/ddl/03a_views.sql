
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CHATBOT_DATASET_RULES_ADMIN_V" ("RULE_ID", "DATASET", "ENVIRONMENT", "ACTIVE_YN", "PRIORITY", "RULE_TYPE", "MATCH_MODE", "CARRY_FORWARD_YN", "DESCRIPTION", "CREATED_AT", "CREATED_BY", "UPDATED_AT", "UPDATED_BY", "KEYWORDS_CSV", "KEYWORD_COUNT", "TARGETS_CSV", "CONDITION_COUNT")  AS 
  SELECT r.id                                  AS rule_id,
       r.dataset,
       r.environment,
       r.active_yn,
       r.priority,
       r.rule_type,
       r.match_mode,
       r.carry_forward_yn,
       r.description,
       r.created_at,
       r.created_by,
       r.updated_at,
       r.updated_by,
       (
         SELECT LISTAGG(k.keyword, ', ') WITHIN GROUP (ORDER BY k.ord)
           FROM chatbot_dataset_rule_keywords k
          WHERE k.rule_id = r.id
       )                                     AS keywords_csv,
       (
         SELECT COUNT(*)
           FROM chatbot_dataset_rule_keywords k
          WHERE k.rule_id = r.id
       )                                     AS keyword_count,
       (
         SELECT LISTAGG(
                  t.target_table || NVL2(t.target_column, '.' || t.target_column, ''),
                  '; '
                ) WITHIN GROUP (ORDER BY t.weight DESC, t.id)
           FROM chatbot_dataset_rule_targets t
          WHERE t.rule_id = r.id
            AND t.active_yn = 'Y'
       )                                     AS targets_csv,
       (
         SELECT COUNT(*)
           FROM chatbot_dataset_rule_conditions c
          WHERE c.rule_id = r.id
       )                                     AS condition_count
  FROM chatbot_dataset_rules r;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CHATBOT_DATASET_RULES_JSON_V" ("ID", "DATASET", "ENVIRONMENT", "ACTIVE_YN", "PRIORITY", "RULE_TYPE", "MATCH_MODE", "CARRY_FORWARD_YN", "RULE_JSON")  AS 
  SELECT r.id,
       r.dataset,
       r.environment,
       r.active_yn,
       r.priority,
       r.rule_type,
       r.match_mode,
       r.carry_forward_yn,
       JSON_OBJECT(
         'rule_id' VALUE r.id,
         'dataset' VALUE r.dataset,
         'environment' VALUE r.environment,
         'active' VALUE CASE WHEN r.active_yn = 'Y' THEN 'true' ELSE 'false' END FORMAT JSON,
         'priority' VALUE r.priority,
         'rule_type' VALUE r.rule_type,
         'match_mode' VALUE LOWER(r.match_mode),
         'carry_forward' VALUE CASE WHEN r.carry_forward_yn = 'Y' THEN 'true' ELSE 'false' END FORMAT JSON,
         'description' VALUE r.description,
         'keywords' VALUE (
           SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                      'ord' VALUE k.ord,
                      'keyword' VALUE k.keyword,
                      'match_type' VALUE k.match_type
                    ) ORDER BY k.ord
                  )
             FROM chatbot_dataset_rule_keywords k
            WHERE k.rule_id = r.id
         ),
         'targets' VALUE (
           SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                      'id' VALUE t.id,
                      'table' VALUE t.target_table,
                      'column' VALUE t.target_column,
                      'role' VALUE t.target_role,
                      'weight' VALUE t.weight,
                      'active' VALUE CASE WHEN t.active_yn = 'Y' THEN 'true' ELSE 'false' END FORMAT JSON
                    ) ORDER BY t.weight DESC, t.id
                  )
             FROM chatbot_dataset_rule_targets t
            WHERE t.rule_id = r.id
         ),
         'conditions' VALUE (
           SELECT JSON_ARRAYAGG(
                    JSON_OBJECT(
                      'id' VALUE c.id,
                      'target_id' VALUE c.target_id,
                      'seq' VALUE c.cond_seq,
                      'join' VALUE c.logic_join,
                      'field_scope' VALUE c.field_scope,
                      'column' VALUE c.column_name,
                      'operator' VALUE c.operator,
                      'case' VALUE c.case_mode,
                      'value_type' VALUE c.value_type,
                      'value_text' VALUE c.value_text,
                      'value_num' VALUE c.value_num,
                      'value_date' VALUE TO_CHAR(c.value_date, 'YYYY-MM-DD'),
                      'value_json' VALUE c.value_json FORMAT JSON
                    ) ORDER BY c.cond_seq
                  )
             FROM chatbot_dataset_rule_conditions c
            WHERE c.rule_id = r.id
         ),
         'comparison' VALUE (
           SELECT JSON_OBJECT(
                    'applies_to' VALUE cmp.applies_to,
                    'comparison_type' VALUE cmp.comparison_type,
                    'basis' VALUE cmp.basis,
                    'time_grain' VALUE cmp.time_grain,
                    'requires_time_series' VALUE CASE WHEN cmp.requires_time_series_yn = 'Y' THEN 'true' ELSE 'false' END FORMAT JSON,
                    'notes' VALUE cmp.notes
                  )
             FROM chatbot_dataset_rule_comparison cmp
            WHERE cmp.rule_id = r.id
         ),
         'outputs' VALUE (
           SELECT JSON_ARRAYAGG(o.output_name ORDER BY o.ord)
             FROM chatbot_dataset_rule_outputs o
            WHERE o.rule_id = r.id
         )
       RETURNING CLOB) AS rule_json
  FROM chatbot_dataset_rules r;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CHATBOT_DATASET_RULE_KEYWORDS_V" ("RULE_ID", "DATASET", "ENVIRONMENT", "ACTIVE_YN", "PRIORITY", "RULE_TYPE", "MATCH_MODE", "CARRY_FORWARD_YN", "ORD", "KEYWORD", "KEYWORD_NORM", "MATCH_TYPE", "DESCRIPTION")  AS 
  SELECT r.id AS rule_id,
       r.dataset,
       r.environment,
       r.active_yn,
       r.priority,
       r.rule_type,
       r.match_mode,
       r.carry_forward_yn,
       k.ord,
       k.keyword,
       k.keyword_norm,
       k.match_type,
       r.description
  FROM chatbot_dataset_rules r
  JOIN chatbot_dataset_rule_keywords k
    ON k.rule_id = r.id;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CHATBOT_RUN_INSIGHTS_DAILY_V" ("DAY_KEY", "DATASET", "ENVIRONMENT", "RUNS_TOTAL", "RUNS_SUCCESS", "RUNS_FAILED", "SUCCESS_RATE_PCT", "AVG_LATENCY_MS", "P95_LATENCY_MS", "AVG_TOKENS_TOTAL", "TOTAL_COST_USD")  AS 
  SELECT
  TRUNC(created_at) AS day_key,
  dataset,
  environment,
  COUNT(*) AS runs_total,
  SUM(CASE WHEN UPPER(NVL(log_status,'X')) IN ('DONE','SUCCEEDED') AND error_code IS NULL THEN 1 ELSE 0 END) AS runs_success,
  SUM(CASE WHEN UPPER(NVL(log_status,'X')) IN ('FAILED','FAIL') OR error_code IS NOT NULL THEN 1 ELSE 0 END) AS runs_failed,
  ROUND(
    100 * SUM(CASE WHEN UPPER(NVL(log_status,'X')) IN ('DONE','SUCCEEDED') AND error_code IS NULL THEN 1 ELSE 0 END)
    / NULLIF(COUNT(*), 0), 2
  ) AS success_rate_pct,
  ROUND(AVG(latency_ms), 2) AS avg_latency_ms,
  ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY latency_ms), 2) AS p95_latency_ms,
  ROUND(AVG(NVL(input_tokens_total,0) + NVL(output_tokens_total,0)), 2) AS avg_tokens_total,
  ROUND(SUM(NVL(cost_total_usd,0)), 6) AS total_cost_usd
FROM chatbot_run_insights
GROUP BY TRUNC(created_at), dataset, environment;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "CHATBOT_VALUE_RULES_ADMIN_V" ("ID", "DATASET", "ENVIRONMENT", "ACTIVE_YN", "PRIORITY", "SOURCE_TABLE", "SOURCE_COLUMN", "MATCH_MODE", "MAX_VALUES", "GENERATED_AT", "GENERATED_BY", "DESCRIPTION", "CREATED_AT", "CREATED_BY", "UPDATED_AT", "UPDATED_BY", "GENERATED_VALUE_COUNT", "VALUES_JSON", "EXTRA_KEYWORDS_JSON")  AS 
  SELECT r.id,
       r.dataset,
       r.environment,
       r.active_yn,
       r.priority,
       r.source_table,
       r.source_column,
       r.match_mode,
       r.max_values,
       r.generated_at,
       r.generated_by,
       r.description,
       r.created_at,
       r.created_by,
       r.updated_at,
       r.updated_by,
       (
         SELECT COUNT(*)
           FROM JSON_TABLE(
                  r.values_json,
                  '$[*]' COLUMNS (
                    value_txt VARCHAR2(4000) PATH '$.value'
                  )
                )
       ) AS generated_value_count,
       values_json,
       EXTRA_KEYWORDS_JSON
  FROM chatbot_value_rules r;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "COST_USAGE_DAILY_WKLD_V" ("DATE_BUCKET", "BILLINGACCOUNTID", "SUBACCOUNTNAME", "INVOICEISSUER", "REGION", "BILLINGCURRENCY", "SERVICECATEGORY", "SERVICENAME", "CHARGEDESCRIPTION", "RESOURCETYPE", "RESOURCEID", "RESOURCENAME", "SKUID", "PRICINGUNIT", "OCI_COMPARTMENTID", "OCI_COMPARTMENTNAME", "OCI_COMPARTMENT_PATH", "USAGEUNIT", "COST", "USAGE", "LAST_REFRESH", "CREATED_BY", "IMPLEMENTOR", "COSTCENTER", "ENVIRONMENT", "WORKLOAD_NAME")  AS 
  SELECT
  cutd."DATE_BUCKET",cutd."BILLINGACCOUNTID",cutd."SUBACCOUNTNAME",cutd."INVOICEISSUER",cutd."REGION",cutd."BILLINGCURRENCY",cutd."SERVICECATEGORY",cutd."SERVICENAME",cutd."CHARGEDESCRIPTION",cutd."RESOURCETYPE",cutd."RESOURCEID",cutd."RESOURCENAME",cutd."SKUID",cutd."PRICINGUNIT",cutd."OCI_COMPARTMENTID",cutd."OCI_COMPARTMENTNAME",cutd."OCI_COMPARTMENT_PATH",cutd."USAGEUNIT",cutd."COST",cutd."USAGE",cutd."LAST_REFRESH",cutd."CREATED_BY",cutd."IMPLEMENTOR",cutd."COSTCENTER",cutd."ENVIRONMENT",
  ow.WORKLOAD_NAME AS workload_name
FROM cost_usage_timeseries_daily cutd
JOIN OCI_WORKLOADS ow ON INSTR(',' || ow.VALUE || ',', ',' || cutd.OCI_COMPARTMENTID || ',') > 0 OR INSTR(',' || ow.VALUE || ',', ',' || cutd.COSTCENTER || ',') > 0;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "COST_USAGE_MONTHLY_WKLD_V" ("DATE_BUCKET", "BILLINGACCOUNTID", "SUBACCOUNTNAME", "INVOICEISSUER", "REGION", "BILLINGCURRENCY", "SERVICECATEGORY", "SERVICENAME", "CHARGEDESCRIPTION", "RESOURCETYPE", "RESOURCEID", "RESOURCENAME", "SKUID", "PRICINGUNIT", "OCI_COMPARTMENTID", "OCI_COMPARTMENTNAME", "OCI_COMPARTMENT_PATH", "USAGEUNIT", "COST", "USAGE", "LAST_REFRESH", "CREATED_BY", "IMPLEMENTOR", "COSTCENTER", "ENVIRONMENT", "WORKLOAD_NAME")  AS 
  SELECT
  cutd."DATE_BUCKET",cutd."BILLINGACCOUNTID",cutd."SUBACCOUNTNAME",cutd."INVOICEISSUER",cutd."REGION",cutd."BILLINGCURRENCY",cutd."SERVICECATEGORY",cutd."SERVICENAME",cutd."CHARGEDESCRIPTION",cutd."RESOURCETYPE",cutd."RESOURCEID",cutd."RESOURCENAME",cutd."SKUID",cutd."PRICINGUNIT",cutd."OCI_COMPARTMENTID",cutd."OCI_COMPARTMENTNAME",cutd."OCI_COMPARTMENT_PATH",cutd."USAGEUNIT",cutd."COST",cutd."USAGE",cutd."LAST_REFRESH",cutd."CREATED_BY",cutd."IMPLEMENTOR",cutd."COSTCENTER",cutd."ENVIRONMENT",
  ow.WORKLOAD_NAME AS workload_name
FROM cost_usage_timeseries_monthly cutd
JOIN OCI_WORKLOADS ow ON INSTR(',' || ow.VALUE || ',', ',' || cutd.OCI_COMPARTMENTID || ',') > 0 OR INSTR(',' || ow.VALUE || ',', ',' || cutd.COSTCENTER || ',') > 0;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "GENAI_MODEL_RATES" ("MODEL_KEY", "PRICING_MODE", "INPUT_DISPLAY_NAME", "INPUT_METRIC", "INPUT_UNIT_PRICE_EUR", "INPUT_UNIT_RATE_EUR", "OUTPUT_DISPLAY_NAME", "OUTPUT_METRIC", "OUTPUT_UNIT_PRICE_EUR", "OUTPUT_UNIT_RATE_EUR")  AS 
  with latest_price as (
  select c.*
  from oci_price_catalog c
  join (
    select part_number, currency_code, price_model,
           max(fetched_at) as max_fetched
    from oci_price_catalog
    group by part_number, currency_code, price_model
  ) m
    on m.part_number   = c.part_number
   and m.currency_code = c.currency_code
   and m.price_model   = c.price_model
   and m.max_fetched   = c.fetched_at
  where c.currency_code = 'EUR'
    and c.price_model   = 'PAY_AS_YOU_GO'
)
select
  m.model_key,
  m.pricing_mode,
  li.display_name    as input_display_name,
  li.metric_name     as input_metric,
  li.unit_price      as input_unit_price_eur,
  case
    when li.metric_name like '10,000 Transaction%' then li.unit_price / 10000
    when li.metric_name like '1,000,000 Token%'    then li.unit_price / 1e6
  end               as input_unit_rate_eur,    -- €/char or €/token
  lo.display_name    as output_display_name,
  lo.metric_name     as output_metric,
  lo.unit_price      as output_unit_price_eur,
  case
    when lo.metric_name like '10,000 Transaction%' then lo.unit_price / 10000
    when lo.metric_name like '1,000,000 Token%'    then lo.unit_price / 1e6
  end               as output_unit_rate_eur    -- €/token typically
from genai_model_price_map m
left join latest_price li
  on li.part_number = m.input_part_number
left join latest_price lo
  on lo.part_number = m.output_part_number;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_POLICY_LIMIT_COUNTS_V" ("COMPARTMENT_ID", "COMPARTMENT_NAME", "COMPARTMENT_PATH", "PARENT_ID", "DIRECT_STATEMENT_COUNT", "CUMULATIVE_STATEMENT_COUNT", "LIMIT_VALUE", "REMAINING_TO_LIMIT", "OVER_LIMIT_FLAG")  AS 
  WITH direct_counts AS (
  SELECT
    p.compartment_id,
    COUNT(*) AS direct_statement_count
  FROM OCI_POLICIES_PY p
  GROUP BY p.compartment_id
),
comp_path_totals AS (
  SELECT
    c.compartment_id,
    SUM(NVL(dc.direct_statement_count, 0)) AS cumulative_statement_count
  FROM OCI_COMPARTMENTS_PY c
  JOIN OCI_COMPARTMENTS_PY a
    ON c.path LIKE a.path || '%'
  LEFT JOIN direct_counts dc
    ON dc.compartment_id = a.compartment_id
  GROUP BY c.compartment_id
)
SELECT
  c.compartment_id,
  c.name AS compartment_name,
  c.path AS compartment_path,
  c.parent_id,
  NVL(dc.direct_statement_count, 0) AS direct_statement_count,
  NVL(cp.cumulative_statement_count, 0) AS cumulative_statement_count,
  500 AS limit_value,
  500 - NVL(cp.cumulative_statement_count, 0) AS remaining_to_limit,
  CASE WHEN NVL(cp.cumulative_statement_count, 0) > 500 THEN 'Y' ELSE 'N' END AS over_limit_flag
FROM OCI_COMPARTMENTS_PY c
LEFT JOIN direct_counts dc
  ON dc.compartment_id = c.compartment_id
LEFT JOIN comp_path_totals cp
  ON cp.compartment_id = c.compartment_id;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_POLICY_TREE_V" ("NODE_ID", "PARENT_NODE_ID", "NODE_LABEL", "NODE_TYPE", "SORT_GROUP", "SORT_TEXT", "IS_LEAF", "COMPARTMENT_ID", "POLICY_ID", "POLICY_LINE_NO", "TOOLTIP", "ICON_CSS_CLASSES", "NODE_CSS_CLASSES")  AS 
  WITH scope_cfg AS (
  SELECT MAX(config_value) AS root_tenancy_id
  FROM APP_CONFIG
  WHERE config_key = 'OCI_ROOT_COMPARTMENT_OCID'
),
scope_compartments AS (
  SELECT c.*
  FROM OCI_COMPARTMENTS_PY c
  CROSS JOIN scope_cfg s
  WHERE s.root_tenancy_id IS NULL
     OR c.tenancy_id = s.root_tenancy_id
),
policy_nodes AS (
  SELECT
    p.compartment_id,
    p.policy_id,
    MIN(p.policy_name) AS policy_name,
    MIN(p.description) AS policy_description,
    COUNT(*) AS statement_count
  FROM OCI_POLICIES_PY p
  GROUP BY
    p.compartment_id,
    p.policy_id
),
comp_metrics AS (
  SELECT
    c.compartment_id,
    c.parent_id,
    c.name,
    c.description,
    c.path,
    NVL(l.direct_statement_count, 0) AS direct_statement_count,
    NVL(l.cumulative_statement_count, 0) AS cumulative_statement_count,
    NVL(COUNT(pn.policy_id), 0) AS direct_policy_count,
    CASE
      WHEN NVL(COUNT(pn.policy_id), 0) > 120 OR NVL(l.cumulative_statement_count, 0) > 450 THEN 'is-danger'
      WHEN NVL(COUNT(pn.policy_id), 0) > 80 OR NVL(l.cumulative_statement_count, 0) > 400 THEN 'is-warning'
      ELSE 'is-ok'
    END AS node_css_classes
  FROM scope_compartments c
  LEFT JOIN OCI_POLICY_LIMIT_COUNTS_V l
    ON l.compartment_id = c.compartment_id
  LEFT JOIN policy_nodes pn
    ON pn.compartment_id = c.compartment_id
  GROUP BY
    c.compartment_id,
    c.parent_id,
    c.name,
    c.description,
    c.path,
    l.direct_statement_count,
    l.cumulative_statement_count
),
comp_tag_source AS (
  SELECT
    c.compartment_id,
    r.defined_tags,
    r.freeform_tags,
    r.system_tags
  FROM scope_compartments c
  LEFT JOIN OCI_RESOURCES_PY r
    ON r.identifier = c.compartment_id
   AND UPPER(NVL(r.resource_type, '')) LIKE '%COMPARTMENT%'
),
tag_texts AS (
  SELECT compartment_id, DBMS_LOB.SUBSTR(defined_tags, 4000, 1) AS tag_json, 1 AS tag_sort
  FROM comp_tag_source
  WHERE defined_tags IS NOT NULL
    AND JSON_EXISTS(defined_tags, '$.*' FALSE ON ERROR)
  UNION ALL
  SELECT compartment_id, DBMS_LOB.SUBSTR(freeform_tags, 4000, 1) AS tag_json, 2 AS tag_sort
  FROM comp_tag_source
  WHERE freeform_tags IS NOT NULL
    AND JSON_EXISTS(freeform_tags, '$.*' FALSE ON ERROR)
  UNION ALL
  SELECT compartment_id, DBMS_LOB.SUBSTR(system_tags, 4000, 1) AS tag_json, 3 AS tag_sort
  FROM comp_tag_source
  WHERE system_tags IS NOT NULL
    AND JSON_EXISTS(system_tags, '$.*' FALSE ON ERROR)
),
tag_kv AS (
  SELECT
    tt.compartment_id,
    REGEXP_SUBSTR(tt.tag_json, '"([^"]+)":"([^"]*)"', 1, lvl.n, NULL, 1) AS tag_key,
    REGEXP_SUBSTR(tt.tag_json, '"([^"]+)":"([^"]*)"', 1, lvl.n, NULL, 2) AS tag_val,
    tt.tag_sort
  FROM tag_texts tt
  CROSS JOIN (
    SELECT LEVEL AS n FROM dual CONNECT BY LEVEL <= 200
  ) lvl
  WHERE REGEXP_SUBSTR(tt.tag_json, '"([^"]+)":"([^"]*)"', 1, lvl.n, NULL, 1) IS NOT NULL
),
tag_docs AS (
  SELECT DISTINCT
    tk.compartment_id,
    tk.tag_key || ': ' || tk.tag_val AS tag_line,
    tk.tag_sort
  FROM tag_kv tk
  WHERE tk.tag_key NOT IN ('Oracle-Tags', 'Oracle-Standard')
)
SELECT
  'C:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS node_id,
  CASE
    WHEN EXISTS (SELECT 1 FROM scope_compartments p WHERE p.compartment_id = cm.parent_id)
    THEN 'C:' || RAWTOHEX(STANDARD_HASH(cm.parent_id, 'SHA1'))
    ELSE NULL
  END AS parent_node_id,
  'Compartment: ' || cm.name ||
  ' (direct: ' || TO_CHAR(cm.direct_statement_count) ||
  ', cumulative: ' || TO_CHAR(cm.cumulative_statement_count) || ')' AS node_label,
  'COMPARTMENT' AS node_type,
  10 AS sort_group,
  NVL(cm.path, cm.name) AS sort_text,
  'N' AS is_leaf,
  cm.compartment_id,
  CAST(NULL AS VARCHAR2(200)) AS policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  'Direct policies: ' || TO_CHAR(cm.direct_policy_count) ||
  ', direct statements: ' || TO_CHAR(cm.direct_statement_count) ||
  ', cumulative statements: ' || TO_CHAR(cm.cumulative_statement_count) AS tooltip,
  'fa fa-folder-o' AS icon_css_classes,
  cm.node_css_classes
FROM comp_metrics cm

UNION ALL

SELECT
  'D:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS node_id,
  'C:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS parent_node_id,
  'Description: ' || NVL(cm.description, '-') AS node_label,
  'DESCRIPTION' AS node_type,
  30 AS sort_group,
  NVL(cm.path, cm.name) AS sort_text,
  'Y' AS is_leaf,
  cm.compartment_id,
  CAST(NULL AS VARCHAR2(200)) AS policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  NULL AS tooltip,
  'fa fa-circle-o' AS icon_css_classes,
  NULL AS node_css_classes
FROM comp_metrics cm

UNION ALL

SELECT
  'TG:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS node_id,
  'C:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS parent_node_id,
  'Tags:' AS node_label,
  'TAGS_FOLDER' AS node_type,
  40 AS sort_group,
  NVL(cm.path, cm.name) AS sort_text,
  'N' AS is_leaf,
  cm.compartment_id,
  CAST(NULL AS VARCHAR2(200)) AS policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  NULL AS tooltip,
  'fa fa-tags' AS icon_css_classes,
  NULL AS node_css_classes
FROM comp_metrics cm

UNION ALL

SELECT
  'T:' || RAWTOHEX(STANDARD_HASH(td.compartment_id || '|' || td.tag_sort || '|' || td.tag_line, 'SHA1')) AS node_id,
  'TG:' || RAWTOHEX(STANDARD_HASH(td.compartment_id, 'SHA1')) AS parent_node_id,
  td.tag_line AS node_label,
  'TAG' AS node_type,
  45 AS sort_group,
  NVL(cm.path, cm.name) || '|tag|' || LPAD(TO_CHAR(td.tag_sort), 4, '0') AS sort_text,
  'Y' AS is_leaf,
  td.compartment_id,
  CAST(NULL AS VARCHAR2(200)) AS policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  NULL AS tooltip,
  'fa fa-tag' AS icon_css_classes,
  NULL AS node_css_classes
FROM tag_docs td
JOIN comp_metrics cm
  ON cm.compartment_id = td.compartment_id

UNION ALL

SELECT
  'PG:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS node_id,
  'C:' || RAWTOHEX(STANDARD_HASH(cm.compartment_id, 'SHA1')) AS parent_node_id,
  'Policies' AS node_label,
  'POLICIES_FOLDER' AS node_type,
  50 AS sort_group,
  NVL(cm.path, cm.name) AS sort_text,
  'N' AS is_leaf,
  cm.compartment_id,
  CAST(NULL AS VARCHAR2(200)) AS policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  'Direct policies: ' || TO_CHAR(cm.direct_policy_count) AS tooltip,
  'fa fa-list' AS icon_css_classes,
  cm.node_css_classes
FROM comp_metrics cm

UNION ALL

SELECT
  'P:' || RAWTOHEX(STANDARD_HASH(pn.compartment_id || '|' || pn.policy_id, 'SHA1')) AS node_id,
  'PG:' || RAWTOHEX(STANDARD_HASH(pn.compartment_id, 'SHA1')) AS parent_node_id,
  'Policy: ' || pn.policy_name AS node_label,
  'POLICY' AS node_type,
  60 AS sort_group,
  NVL(cm.path, cm.name) || '|policy|' || pn.policy_name AS sort_text,
  'N' AS is_leaf,
  pn.compartment_id,
  pn.policy_id,
  CAST(NULL AS NUMBER) AS policy_line_no,
  NVL(pn.policy_description, '(no description)') || ' | statements: ' || TO_CHAR(pn.statement_count) AS tooltip,
  'fa fa-file-text-o' AS icon_css_classes,
  NULL AS node_css_classes
FROM policy_nodes pn
JOIN comp_metrics cm
  ON cm.compartment_id = pn.compartment_id

UNION ALL

SELECT
  'L:' || RAWTOHEX(STANDARD_HASH(p.compartment_id || '|' || p.policy_id || '|' || TO_CHAR(p.policy_line_no), 'SHA1')) AS node_id,
  'P:' || RAWTOHEX(STANDARD_HASH(p.compartment_id || '|' || p.policy_id, 'SHA1')) AS parent_node_id,
  p.policy_statement AS node_label,
  'STATEMENT' AS node_type,
  70 AS sort_group,
  NVL(cm.path, cm.name) || '|policy_stmt|' || p.policy_name || '|' || LPAD(TO_CHAR(p.policy_line_no), 6, '0') AS sort_text,
  'Y' AS is_leaf,
  p.compartment_id,
  p.policy_id,
  p.policy_line_no,
  'Line ' || TO_CHAR(p.policy_line_no) || ' of ' || p.policy_name AS tooltip,
  'fa fa-angle-right' AS icon_css_classes,
  NULL AS node_css_classes
FROM OCI_POLICIES_PY p
JOIN comp_metrics cm
  ON cm.compartment_id = p.compartment_id;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_EFFECTIVE_PRICE" ("PART_NUMBER", "DISPLAY_NAME", "METRIC_NAME", "SERVICE_CATEGORY", "CURRENCY_CODE", "PRICE_MODEL", "CATALOG_UNIT_PRICE", "RATECARD_ACTUAL_UNIT_PRICE", "RATECARD_LIST_UNIT_PRICE", "EFFECTIVE_UNIT_PRICE", "PRICE_SOURCE", "FETCHED_AT", "SRC_URL")  AS 
  select lp.part_number,
       lp.display_name,
       lp.metric_name,
       lp.service_category,
       lp.currency_code,
       lp.price_model,
       lp.unit_price as catalog_unit_price,
       case
         when lp.currency_code = 'EUR' then rm.actualunitprice
         else null
       end as ratecard_actual_unit_price,
       rm.listunitprice as ratecard_list_unit_price,
       case
         when lp.currency_code = 'EUR' and rm.actualunitprice is not null then rm.actualunitprice
         else lp.unit_price
       end as effective_unit_price,
       case
         when lp.currency_code = 'EUR' and rm.actualunitprice is not null then 'RATECARD_MV.ACTUALUNITPRICE'
         else 'OCI_PRICE_CATALOG.UNIT_PRICE'
       end as price_source,
       lp.fetched_at,
       lp.src_url
  from oci_v_latest_catalog_price lp
  left join ratecard_mv rm
    on trim(rm.skuid) = trim(lp.part_number);

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_LINE_PRICE" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "EST_CONFIG_ID", "CONFIG_LABEL", "EST_SERVICE_ID", "SERVICE_ID", "SERVICE_LABEL", "EST_ITEM_ID", "PART_NUMBER", "QUANTITY", "IN_PRESET", "MIN_QUANTITY", "PRICE_MODEL", "CATALOG_UNIT_PRICE", "RATECARD_ACTUAL_UNIT_PRICE", "RATECARD_LIST_UNIT_PRICE", "EFFECTIVE_UNIT_PRICE", "PRICE_SOURCE", "STORED_UNIT_PRICE", "STORED_MONTHLY_COST", "COMPUTED_MONTHLY_COST", "COMPUTED_YEARLY_COST")  AS 
  select h.est_id,
       h.est_name,
       h.owner_username,
       h.currency_code,
       c.est_config_id,
       c.config_label,
       s.est_service_id,
       s.service_id,
       s.label as service_label,
       i.est_item_id,
       i.part_number,
       i.quantity,
       i.in_preset,
       i.min_quantity,
       ep.price_model,
       ep.catalog_unit_price,
       ep.ratecard_actual_unit_price,
       ep.ratecard_list_unit_price,
       ep.effective_unit_price,
       ep.price_source,
       i.unit_price as stored_unit_price,
       i.monthly_cost as stored_monthly_cost,
       (nvl(i.quantity, 0) * nvl(ep.effective_unit_price, nvl(i.unit_price, 0))) as computed_monthly_cost,
       (nvl(i.quantity, 0) * nvl(ep.effective_unit_price, nvl(i.unit_price, 0)) * 12) as computed_yearly_cost
  from oci_est_header h
  join oci_est_config c
    on c.est_id = h.est_id
  join oci_est_service s
    on s.est_config_id = c.est_config_id
  join oci_est_item i
    on i.est_service_id = s.est_service_id
  left join oci_v_effective_price ep
    on ep.part_number = i.part_number
   and ep.currency_code = h.currency_code
   and ep.price_model = 'PAY_AS_YOU_GO';

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_SERVICE_TOTAL" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "EST_SERVICE_ID", "SERVICE_ID", "SERVICE_LABEL", "TOTAL_MONTHLY_COST", "TOTAL_YEARLY_COST")  AS 
  select est_id,
       est_name,
       owner_username,
       currency_code,
       est_service_id,
       service_id,
       service_label,
       sum(computed_monthly_cost) as total_monthly_cost,
       sum(computed_yearly_cost) as total_yearly_cost
  from oci_v_estimate_line_price
 group by est_id,
          est_name,
          owner_username,
          currency_code,
          est_service_id,
          service_id,
          service_label;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_ESTIMATE_TOTAL" ("EST_ID", "EST_NAME", "OWNER_USERNAME", "CURRENCY_CODE", "TOTAL_MONTHLY_COST", "TOTAL_YEARLY_COST")  AS 
  select est_id,
       est_name,
       owner_username,
       currency_code,
       sum(computed_monthly_cost) as total_monthly_cost,
       sum(computed_yearly_cost) as total_yearly_cost
  from oci_v_estimate_line_price
 group by est_id,
          est_name,
          owner_username,
          currency_code;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "OCI_V_LATEST_CATALOG_PRICE" ("PART_NUMBER", "DISPLAY_NAME", "METRIC_NAME", "SERVICE_CATEGORY", "CURRENCY_CODE", "PRICE_MODEL", "UNIT_PRICE", "FETCHED_AT", "SRC_URL")  AS 
  select p.part_number,
       p.display_name,
       p.metric_name,
       p.service_category,
       p.currency_code,
       p.price_model,
       p.unit_price,
       p.fetched_at,
       p.src_url
  from oci_price_catalog p
  join (
    select part_number,
           currency_code,
           price_model,
           max(fetched_at) as max_fetched_at
      from oci_price_catalog
     group by part_number, currency_code, price_model
  ) x
    on x.part_number = p.part_number
   and x.currency_code = p.currency_code
   and x.price_model = p.price_model
   and x.max_fetched_at = p.fetched_at;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "RESOURCE_GRAPH_DOMAIN_HEALTH_V" ("DOMAIN_CODE", "DISPLAY_NAME", "COVERAGE_STATUS", "ENABLED_FLAG", "DEFAULT_HOP_DEPTH", "DEFAULT_MAX_NODES", "NODE_COUNT", "EDGE_COUNT", "PHYSICAL_EDGE_COUNT", "SYNTHETIC_EDGE_COUNT", "VALIDATION_STATUS", "SNAPSHOT_ID", "CHECKED_TS")  AS 
  WITH latest AS (
  SELECT MAX(snapshot_id) AS snapshot_id
    FROM resource_graph_snapshots
   WHERE status = 'READY'
), domain_nodes AS (
  SELECT d.domain_code,
         n.node_id,
         n.node_kind,
         n.compartment_id
    FROM resource_graph_domain_catalog d
    CROSS JOIN latest l
    JOIN resource_graph_nodes n
      ON n.snapshot_id = l.snapshot_id
   WHERE d.enabled_flag = 'Y'
     AND (
           d.domain_code IN ('CORE', 'ALL')
        OR (d.domain_code = 'SUBSCRIPTION' AND n.node_kind = 'COMPARTMENT')
        OR (d.domain_code = 'COMPUTE_VOLUME' AND (
              UPPER(NVL(n.category, '')) IN ('COMPUTE', 'STORAGE')
           OR LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.volume.%'
           OR LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.bootvolume.%'
           OR LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.volumegroup.%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%volume%'
        )
        AND LOWER(NVL(n.oci_identifier, '')) NOT LIKE 'ocid1.volumebackup.%'
        AND LOWER(NVL(n.oci_identifier, '')) NOT LIKE 'ocid1.bootvolumebackup.%'
        AND LOWER(NVL(n.oci_identifier, '')) NOT LIKE 'ocid1.volumegroupbackup.%'
        AND LOWER(NVL(n.resource_type, '')) NOT LIKE '%backup%'
        AND LOWER(NVL(n.display_name, '')) NOT LIKE '%backup%')
        OR (d.domain_code = 'DBAAS' AND (
              UPPER(NVL(n.category, '')) = 'DATABASES'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%database%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%autonomous%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%dbsystem%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%db_system%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%exadata%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%vmcluster%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%vm_cluster%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%cloudvmcluster%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%cloud_vm_cluster%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%rediscluster%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%redis_cluster%'
        ))
        OR (d.domain_code = 'OKE' AND (
              LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.cluster.%'
           OR LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.nodepool.%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%kubernetes%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%nodepool%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%node_pool%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%oke%'
           OR EXISTS (
                SELECT 1
                  FROM resource_graph_edges oe
                 WHERE oe.snapshot_id = l.snapshot_id
                   AND oe.provenance = 'OCI_OKE_TOPOLOGY_LOADER_PKG'
                   AND n.node_id IN (oe.source_node_id, oe.target_node_id)
                   AND UPPER(NVL(oe.edge_subtype, oe.edge_type)) IN ('NODE_VM','NODE_STORAGE','OKE_RELATED_RESOURCE','NODE_POOL')
              )
        ))
        OR (d.domain_code = 'LBAAS' AND (
              LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.loadbalancer.%'
           OR LOWER(NVL(n.oci_identifier, '')) LIKE 'ocid1.networkloadbalancer.%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%load%balancer%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%network%load%balancer%'
        ))
        OR (d.domain_code = 'NETWORK' AND UPPER(NVL(n.category, '')) = 'NETWORKING')
        OR (d.domain_code = 'OBJECT_STORAGE' AND (
              LOWER(NVL(n.resource_type, '')) LIKE '%bucket%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%objectstorage%'
        ))
        OR (d.domain_code = 'LOGGING' AND LOWER(NVL(n.resource_type, '')) LIKE '%log%')
        OR (d.domain_code = 'NETWORK_FIREWALL' AND (
              LOWER(NVL(n.resource_type, '')) LIKE '%firewall%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%waf%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%origin%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%networkaddresslist%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%network%address%list%'
        ))
        OR (d.domain_code = 'OCI_CACHE' AND (
              LOWER(NVL(n.resource_type, '')) LIKE '%redis%'
           OR LOWER(NVL(n.resource_type, '')) LIKE '%cache%'
        ))
        OR (d.domain_code = 'OPENSEARCH' AND LOWER(NVL(n.resource_type, '')) LIKE '%opensearch%')
        OR (d.domain_code = 'INTEGRATION' AND LOWER(NVL(n.resource_type, '')) LIKE '%integration%')
     )
), node_domain AS (
  SELECT domain_code,
         COUNT(DISTINCT node_id) AS node_count
    FROM domain_nodes
   GROUP BY domain_code
), synthetic_domain_edges AS (
  -- Synthetic DOMAIN_RESOURCE edges are dashboard-only visual scaffolding and
  -- are intentionally excluded from domain-health edge counts.
  SELECT d.domain_code,
         0 AS synthetic_edge_count
    FROM resource_graph_domain_catalog d
   WHERE d.enabled_flag = 'Y'
), physical_edges AS (
  SELECT d.domain_code,
         e.source_node_id,
         e.target_node_id
    FROM resource_graph_domain_catalog d
    CROSS JOIN latest l
    JOIN resource_graph_traversal_edges e
      ON e.snapshot_id = l.snapshot_id
   WHERE d.enabled_flag = 'Y'
     AND (
           d.domain_code IN ('CORE', 'ALL')
        OR (d.domain_code = 'SUBSCRIPTION' AND UPPER(NVL(e.edge_subtype, e.edge_type)) = 'COMPARTMENT')
        OR (UPPER(NVL(e.edge_subtype, e.edge_type)) = 'COMPARTMENT'
            AND EXISTS (
              SELECT 1
                FROM domain_nodes dn
               WHERE dn.domain_code = d.domain_code
                 AND dn.node_kind <> 'COMPARTMENT'
                 AND dn.node_id IN (e.source_node_id, e.target_node_id)
            ))
        OR (d.domain_code = 'COMPUTE_VOLUME' AND (
              e.provenance = 'OCI_COMPUTE_TOPOLOGY_LOADER_PKG'
           OR LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) LIKE '%volume%'
        )
        AND LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) NOT LIKE '%backup%'
        AND LOWER(NVL(e.source_node_id, '')) NOT LIKE '%backup%'
        AND LOWER(NVL(e.target_node_id, '')) NOT LIKE '%backup%')
        OR (d.domain_code = 'DBAAS' AND e.provenance IN ('OCI_DATABASE_TOPOLOGY_LOADER_PKG', 'OCI_CACHE_TOPOLOGY_LOADER_PKG'))
        OR (d.domain_code = 'OKE' AND e.provenance = 'OCI_OKE_TOPOLOGY_LOADER_PKG')
        OR (d.domain_code = 'LBAAS' AND (
              e.provenance = 'OCI_LOAD_BALANCER_TOPOLOGY_LOADER_PKG'
           OR LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) LIKE '%network%load%balancer%'
        ))
        OR (d.domain_code = 'NETWORK' AND e.provenance = 'OCI_NETWORK_TOPOLOGY_LOADER_PKG')
        OR (d.domain_code = 'OBJECT_STORAGE' AND e.provenance = 'OCI_OBJECT_STORAGE_TOPOLOGY_LOADER_PKG')
        OR (d.domain_code = 'LOGGING' AND LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) LIKE '%log%')
        OR (d.domain_code = 'NETWORK_FIREWALL' AND e.provenance = 'OCI_WAF_TOPOLOGY_LOADER_PKG')
        OR (d.domain_code = 'OCI_CACHE' AND e.provenance = 'OCI_CACHE_TOPOLOGY_LOADER_PKG')
        OR (d.domain_code = 'OPENSEARCH' AND LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) LIKE '%opensearch%')
        OR (d.domain_code = 'INTEGRATION' AND LOWER(NVL(e.edge_subtype, '') || ' ' || NVL(e.edge_type, '')) LIKE '%integration%')
     )
), edge_domain AS (
  SELECT domain_code,
         COUNT(DISTINCT source_node_id || '->' || target_node_id) AS physical_edge_count
    FROM physical_edges
   GROUP BY domain_code
)
SELECT d.domain_code,
       d.display_name,
       d.coverage_status,
       d.enabled_flag,
       d.default_hop_depth,
       d.default_max_nodes,
       NVL(n.node_count, 0) AS node_count,
       NVL(e.physical_edge_count, 0) + NVL(se.synthetic_edge_count, 0) AS edge_count,
       NVL(e.physical_edge_count, 0) AS physical_edge_count,
       NVL(se.synthetic_edge_count, 0) AS synthetic_edge_count,
       CASE
         WHEN d.enabled_flag = 'N' THEN 'DISABLED'
         WHEN d.domain_code = 'COST' AND d.coverage_status = 'READY' THEN 'PASS'
         WHEN d.coverage_status = 'READY' AND NVL(n.node_count, 0) > 0 THEN 'PASS'
         WHEN d.coverage_status = 'PARTIAL' AND NVL(n.node_count, 0) > 0 THEN 'PARTIAL_DATA_FOUND'
         WHEN d.coverage_status = 'PLANNED' THEN 'PLANNED'
         ELSE 'CHECK_DATA'
       END AS validation_status,
       (SELECT snapshot_id FROM latest) AS snapshot_id,
       SYSTIMESTAMP AS checked_ts
  FROM resource_graph_domain_catalog d
  LEFT JOIN node_domain n ON n.domain_code = d.domain_code
  LEFT JOIN edge_domain e ON e.domain_code = d.domain_code
  LEFT JOIN synthetic_domain_edges se ON se.domain_code = d.domain_code;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "RESOURCE_GRAPH_NATIVE_RESOURCES_V" ("IDENTIFIER", "DISPLAY_NAME", "RESOURCE_TYPE", "CATEGORY", "REGION", "AVAILABILITY_DOMAIN", "COMPARTMENT_ID", "LIFECYCLE_STATE", "TIME_CREATED", "RAW_SOURCE")  AS 
  SELECT identifier,
       display_name,
       resource_type,
       category,
       region,
       availability_domain,
       compartment_id,
       lifecycle_state,
       time_created,
       raw_source
  FROM (
    SELECT identifier,
           display_name,
           resource_type,
           category,
           region,
           availability_domain,
           compartment_id,
           lifecycle_state,
           time_created,
           raw_source,
           ROW_NUMBER() OVER (PARTITION BY identifier ORDER BY source_rank, snapshot_ts DESC NULLS LAST) rn
      FROM (
        SELECT instance_id AS identifier,
               display_name,
               'Instance' AS resource_type,
               'Compute' AS category,
               region,
               availability_domain,
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP) AS time_created,
               'OCI_COMPUTE_INSTANCES_PY' AS raw_source,
               snapshot_ts,
               10 AS source_rank
          FROM oci_compute_instances_py
         WHERE instance_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT resource_id,
               display_name,
               CASE resource_kind
                 WHEN 'BOOT_VOLUME' THEN 'BootVolume'
                 WHEN 'BLOCK_VOLUME' THEN 'Volume'
                 WHEN 'VOLUME' THEN 'Volume'
                 WHEN 'VOLUME_GROUP' THEN 'VolumeGroup'
                 WHEN 'VOLUME_GROUP_REPLICA' THEN 'VolumeGroupReplica'
                 ELSE INITCAP(REPLACE(resource_kind, '_', ' '))
               END,
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP),
               'OCI_STORAGE_RESOURCES_PY',
               snapshot_ts,
               20
          FROM oci_storage_resources_py
         WHERE resource_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
           AND LOWER(NVL(resource_kind,'') || ' ' || NVL(resource_id,'') || ' ' || NVL(display_name,'')) NOT LIKE '%backup%'
        UNION ALL
        SELECT namespace_id,
               namespace_name,
               'ObjectStorageNamespace',
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               CAST(NULL AS VARCHAR2(1000)),
               'ACTIVE',
               CAST(NULL AS TIMESTAMP),
               'OCI_OBJECT_STORAGE_NAMESPACES_PY',
               snapshot_ts,
               21
          FROM oci_object_storage_namespaces_py
         WHERE namespace_id IS NOT NULL
        UNION ALL
        SELECT bucket_id,
               display_name,
               'Bucket',
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               'ACTIVE',
               CAST(NULL AS TIMESTAMP),
               'OCI_OBJECT_STORAGE_BUCKETS_PY',
               snapshot_ts,
               22
          FROM oci_object_storage_buckets_py
         WHERE bucket_id IS NOT NULL
        UNION ALL
        SELECT retention_rule_id,
               display_name,
               'ObjectStorageRetentionRule',
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               'ACTIVE',
               CAST(NULL AS TIMESTAMP),
               'OCI_OBJECT_STORAGE_RETENTION_RULES_PY',
               snapshot_ts,
               23
          FROM oci_object_storage_retention_rules_py
         WHERE retention_rule_id IS NOT NULL
        UNION ALL
        SELECT replication_policy_id,
               policy_name,
               'ObjectStorageReplicationPolicy',
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               'ACTIVE',
               CAST(NULL AS TIMESTAMP),
               'OCI_OBJECT_STORAGE_REPLICATION_POLICIES_PY',
               snapshot_ts,
               24
          FROM oci_object_storage_replication_policies_py
         WHERE replication_policy_id IS NOT NULL
        UNION ALL
        SELECT lifecycle_rule_id,
               rule_name,
               'ObjectStorageLifecycleRule',
               'Storage',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               'ACTIVE',
               CAST(NULL AS TIMESTAMP),
               'OCI_OBJECT_STORAGE_LIFECYCLE_RULES_PY',
               snapshot_ts,
               25
          FROM oci_object_storage_lifecycle_rules_py
         WHERE lifecycle_rule_id IS NOT NULL
        UNION ALL
        SELECT vcn_id, display_name, 'Vcn', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id,
               'ACTIVE', CAST(NULL AS TIMESTAMP), 'OCI_NETWORK_VCNS_PY', snapshot_ts, 30
          FROM oci_network_vcns_py
         WHERE vcn_id IS NOT NULL
        UNION ALL
        SELECT subnet_id, display_name, 'Subnet', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id,
               'ACTIVE', CAST(NULL AS TIMESTAMP), 'OCI_NETWORK_SUBNETS_PY', snapshot_ts, 31
          FROM oci_network_subnets_py
         WHERE subnet_id IS NOT NULL
        UNION ALL
        SELECT private_ip_id, NVL(private_ip, private_ip_id), 'PrivateIp', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id,
               'ACTIVE', CAST(NULL AS TIMESTAMP), 'OCI_NETWORK_PRIVATE_IPS_PY', snapshot_ts, 32
          FROM oci_network_private_ips_py
         WHERE private_ip_id IS NOT NULL
        UNION ALL
        SELECT resource_id,
               display_name,
               CASE resource_kind
                 WHEN 'VCN' THEN 'Vcn'
                 WHEN 'SUBNET' THEN 'Subnet'
                 WHEN 'DRG_ATTACHMENT' THEN 'DrgAttachment'
                 WHEN 'IPSEC_CONNECTION' THEN 'IPSecConnection'
                 WHEN 'DRG_ROUTE_TABLE' THEN 'DrgRouteTable'
                 WHEN 'DRG_ROUTE_DISTRIBUTION' THEN 'DrgRouteDistribution'
                 WHEN 'NETWORK_SECURITY_GROUP' THEN 'NetworkSecurityGroup'
                 WHEN 'SECURITY_LIST' THEN 'SecurityList'
                 WHEN 'ROUTE_TABLE' THEN 'RouteTable'
                 WHEN 'INTERNET_GATEWAY' THEN 'InternetGateway'
                 WHEN 'NAT_GATEWAY' THEN 'NatGateway'
                 WHEN 'SERVICE_GATEWAY' THEN 'ServiceGateway'
                 ELSE INITCAP(REPLACE(resource_kind, '_', ' '))
               END,
               'Networking',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP),
               'OCI_NETWORK_RESOURCES_PY',
               snapshot_ts,
               33
          FROM oci_network_resources_py
         WHERE resource_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT web_app_firewall_id, display_name, 'WebAppFirewall', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_WAF_WEB_APP_FIREWALLS_PY', snapshot_ts, 34
          FROM oci_waf_web_app_firewalls_py
         WHERE web_app_firewall_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT web_app_firewall_policy_id, display_name, 'WebAppFirewallPolicy', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_WAF_POLICIES_PY', snapshot_ts, 35
          FROM oci_waf_policies_py
         WHERE web_app_firewall_policy_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT network_address_list_id, display_name, 'WafNetworkAddressList', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_WAF_NETWORK_ADDRESS_LISTS_PY', snapshot_ts, 36
          FROM oci_waf_network_address_lists_py
         WHERE network_address_list_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT origin_id, origin_name, 'WafOrigin', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id, 'ACTIVE',
               CAST(NULL AS TIMESTAMP), 'OCI_WAF_ORIGINS_PY', snapshot_ts, 37
          FROM oci_waf_origins_py
         WHERE origin_id IS NOT NULL
        UNION ALL
        -- Cost-usage fallback for domains where we do not yet have dedicated
        -- collectors (Object Storage, OCI Cache). This keeps Resource Analytics
        -- decoupled from OCI_RESOURCES_PY while still surfacing resources that
        -- are present in billing data by OCID/resource name/type.
        SELECT identifier,
               display_name,
               CASE
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.bucket.%' OR LOWER(NVL(resource_type, '')) LIKE '%bucket%' THEN 'Bucket'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.rediscluster.%' OR LOWER(NVL(resource_type, '')) LIKE '%redis%cluster%' THEN 'RedisCluster'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.ocicacheuser.%' OR LOWER(NVL(resource_type, '')) LIKE '%cache%user%' THEN 'OciCacheUser'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.webappfirewallpolicy.%' THEN 'WebAppFirewallPolicy'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.webappfirewall.%' THEN 'WebAppFirewall'
                 ELSE resource_type
               END,
               CASE
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.bucket.%' OR LOWER(NVL(resource_type, '')) LIKE '%bucket%' THEN 'Storage'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.rediscluster.%' OR LOWER(NVL(resource_type, '')) LIKE '%redis%' OR LOWER(NVL(resource_type, '')) LIKE '%cache%' THEN 'Databases'
                 WHEN LOWER(NVL(identifier, '')) LIKE 'ocid1.webappfirewall%' OR LOWER(NVL(resource_type, '')) LIKE '%firewall%' OR LOWER(NVL(resource_type, '')) LIKE '%waf%' THEN 'Networking'
                 ELSE 'Other'
               END,
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP),
               'OCI_RESOURCES_PY',
               time_created,
               38
          FROM oci_resources_py
         WHERE identifier IS NOT NULL
           AND (
                LOWER(NVL(identifier, '')) LIKE 'ocid1.bucket.%'
             OR LOWER(NVL(identifier, '')) LIKE 'ocid1.rediscluster.%'
             OR LOWER(NVL(identifier, '')) LIKE 'ocid1.ocicacheuser.%'
             OR LOWER(NVL(identifier, '')) LIKE 'ocid1.webappfirewall.%'
             OR LOWER(NVL(identifier, '')) LIKE 'ocid1.webappfirewallpolicy.%'
             OR LOWER(NVL(resource_type, '')) LIKE '%bucket%'
             OR LOWER(NVL(resource_type, '')) LIKE '%redis%'
             OR LOWER(NVL(resource_type, '')) LIKE '%cache%'
             OR LOWER(NVL(resource_type, '')) LIKE '%webappfirewall%'
             OR LOWER(NVL(resource_type, '')) LIKE '%web%app%firewall%'
           )
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT d.resourceid,
               MAX(d.resourcename) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket),
               MAX(d.resourcetype) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket),
               CASE
                 WHEN LOWER(MAX(d.resourcetype) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket)) LIKE '%bucket%'
                   OR LOWER(MAX(d.servicename) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket)) LIKE '%object%storage%' THEN 'Storage'
                 WHEN LOWER(MAX(d.resourcetype) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket)) LIKE '%redis%'
                   OR LOWER(MAX(d.resourcetype) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket)) LIKE '%cache%'
                   OR LOWER(MAX(d.servicename) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket)) LIKE '%cache%' THEN 'Databases'
                 ELSE 'Other'
               END,
               MAX(d.region) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket),
               CAST(NULL AS VARCHAR2(100)),
               MAX(d.oci_compartmentid) KEEP (DENSE_RANK LAST ORDER BY d.date_bucket),
               'ACTIVE',
               CAST(MAX(d.date_bucket) AS TIMESTAMP),
               'COST_USAGE_TIMESERIES_DAILY',
               CAST(MAX(d.date_bucket) AS TIMESTAMP),
               39
          FROM cost_usage_timeseries_daily d
         WHERE d.resourceid IS NOT NULL
           AND (
                LOWER(NVL(d.resourcetype, '')) LIKE '%bucket%'
             OR LOWER(NVL(d.servicename, '')) LIKE '%object%storage%'
             OR LOWER(NVL(d.resourcetype, '')) LIKE '%redis%'
             OR LOWER(NVL(d.resourcetype, '')) LIKE '%cache%'
             OR LOWER(NVL(d.servicename, '')) LIKE '%cache%'
           )
         GROUP BY d.resourceid
        UNION ALL
        SELECT resource_id,
               display_name,
               CASE resource_kind
                 WHEN 'AUTONOMOUS_DATABASE' THEN 'AutonomousDatabase'
                 WHEN 'DB_SYSTEM' THEN 'DbSystem'
                 WHEN 'DB_HOME' THEN 'DbHome'
                 WHEN 'DATABASE' THEN 'Database'
                 WHEN 'VM_CLUSTER' THEN 'VmCluster'
                 ELSE INITCAP(REPLACE(resource_kind, '_', ' '))
               END,
               'Databases',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP),
               'OCI_DATABASE_RESOURCES_PY',
               snapshot_ts,
               40
          FROM oci_database_resources_py
         WHERE resource_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT redis_cluster_id, display_name, 'RedisCluster', 'Databases', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_REDIS_CLUSTERS_PY', snapshot_ts, 41
          FROM oci_redis_clusters_py
         WHERE redis_cluster_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT node_id, display_name, 'RedisNode', 'Databases', region, availability_domain, compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_REDIS_NODES_PY', snapshot_ts, 42
          FROM oci_redis_nodes_py
         WHERE node_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT config_set_id, display_name, 'RedisConfigSet', 'Databases', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_REDIS_CONFIG_SETS_PY', snapshot_ts, 43
          FROM oci_redis_config_sets_py
         WHERE config_set_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT user_id, display_name, 'OciCacheUser', 'Databases', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_REDIS_USERS_PY', snapshot_ts, 44
          FROM oci_redis_users_py
         WHERE user_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT resource_id,
               display_name,
               CASE resource_kind WHEN 'CLUSTER' THEN 'Cluster' WHEN 'NODE_POOL' THEN 'NodePool' ELSE INITCAP(REPLACE(resource_kind, '_', ' ')) END,
               'Containers',
               region,
               CAST(NULL AS VARCHAR2(100)),
               compartment_id,
               lifecycle_state,
               CAST(NULL AS TIMESTAMP),
               'OCI_OKE_RESOURCES_PY',
               snapshot_ts,
               50
          FROM oci_oke_resources_py
         WHERE resource_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT node_id, display_name, 'Instance', 'Compute', region, availability_domain, compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_OKE_NODES_PY', snapshot_ts, 51
          FROM oci_oke_nodes_py
         WHERE node_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
        UNION ALL
        SELECT load_balancer_id, display_name, 'LoadBalancer', 'Networking', region, CAST(NULL AS VARCHAR2(100)), compartment_id, lifecycle_state,
               CAST(NULL AS TIMESTAMP), 'OCI_LOAD_BALANCERS_PY', snapshot_ts, 60
          FROM oci_load_balancers_py
         WHERE load_balancer_id IS NOT NULL
           AND UPPER(NVL(lifecycle_state, 'ACTIVE')) NOT IN ('TERMINATED','TERMINATING','DELETED','DELETING')
      )
     WHERE identifier IS NOT NULL
  )
 WHERE rn = 1;

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "V_CHAT_NL2SQL_COSTS" ("ID", "CHAT_ID", "APP_USER", "USER_PROMPT", "SUMMARY_TEXT", "STARTED_AT", "FINISHED_AT", "MODEL_ID", "INPUT_CHARS_TOTAL", "OUTPUT_CHARS_TOTAL", "INPUT_TOKENS_TOTAL", "OUTPUT_TOKENS_TOTAL", "EST_IN_TOKENS", "EST_OUT_TOKENS", "PRICING_MODE", "INPUT_DISPLAY_NAME", "INPUT_METRIC", "INPUT_UNIT_PRICE_EUR", "INPUT_UNIT_RATE_EUR", "OUTPUT_DISPLAY_NAME", "OUTPUT_METRIC", "OUTPUT_UNIT_PRICE_EUR", "OUTPUT_UNIT_RATE_EUR", "PROMPT_COST_EUR", "RESPONSE_COST_EUR", "ROW_COST_EUR")  AS 
  WITH latest_price AS (
  SELECT c.*
  FROM oci_price_catalog c
  JOIN (
    SELECT part_number, currency_code, price_model, MAX(fetched_at) AS max_fetched
    FROM oci_price_catalog
    GROUP BY part_number, currency_code, price_model
  ) m
    ON m.part_number   = c.part_number
   AND m.currency_code = c.currency_code
   AND m.price_model   = c.price_model
   AND m.max_fetched   = c.fetched_at
  WHERE c.currency_code = 'EUR'
    AND c.price_model   = 'PAY_AS_YOU_GO'
),
model_rates AS (
  SELECT
    mp.model_key,
    mp.pricing_mode,
    li.display_name  AS input_display_name,
    li.metric_name   AS input_metric,
    li.unit_price    AS input_unit_price_eur,
    CASE
      WHEN li.metric_name LIKE '10,000 Transaction%' THEN li.unit_price / 10000
      WHEN li.metric_name LIKE '1,000,000 Token%'    THEN li.unit_price / 1e6
    END              AS input_unit_rate_eur,
    lo.display_name  AS output_display_name,
    lo.metric_name   AS output_metric,
    lo.unit_price    AS output_unit_price_eur,
    CASE
      WHEN lo.metric_name LIKE '10,000 Transaction%' THEN lo.unit_price / 10000
      WHEN lo.metric_name LIKE '1,000,000 Token%'    THEN lo.unit_price / 1e6
    END              AS output_unit_rate_eur
  FROM genai_model_price_map mp
  LEFT JOIN latest_price li ON li.part_number = mp.input_part_number
  LEFT JOIN latest_price lo ON lo.part_number = mp.output_part_number
),
archive_with_logs AS (
  SELECT
    a.log_id,
    a.chat_id,
    a.app_user,
    a.started_at,
    a.model_id,
    COALESCE(a.input_chars_total,  l.input_chars_total)  AS input_chars_total,
    COALESCE(a.output_chars_total, l.output_chars_total) AS output_chars_total,
    COALESCE(a.input_tokens_total, l.input_tokens_total) AS input_tokens_total,
    COALESCE(a.output_tokens_total,l.output_tokens_total) AS output_tokens_total,
    l.user_prompt,
    l.summary_text,
    l.finished_at
  FROM chatbot_cost_archive a
  LEFT JOIN chatbot_nl2sql_log l
    ON l.id = a.log_id
)
SELECT
  cl.log_id          AS id,
  cl.chat_id,
  cl.app_user,
  cl.user_prompt,
  cl.summary_text,
  cl.started_at,
  cl.finished_at,
  cl.model_id,
  cl.input_chars_total,
  cl.output_chars_total,
  cl.input_tokens_total,
  cl.output_tokens_total,
  COALESCE(cl.input_tokens_total,
           CEIL(NVL(cl.input_chars_total,0)/4))  AS est_in_tokens,
  COALESCE(cl.output_tokens_total,
           CEIL(NVL(cl.output_chars_total,0)/4)) AS est_out_tokens,
  mr.pricing_mode,
  mr.input_display_name,
  mr.input_metric,
  mr.input_unit_price_eur,
  mr.input_unit_rate_eur,
  mr.output_display_name,
  mr.output_metric,
  mr.output_unit_price_eur,
  mr.output_unit_rate_eur,
  CASE mr.pricing_mode
    WHEN 'CHAR' THEN
      NVL(cl.input_chars_total,0) * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_UNIFIED' THEN
      COALESCE(cl.input_tokens_total,
               CEIL(NVL(cl.input_chars_total,0)/4)) * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_SPLIT' THEN
      COALESCE(cl.input_tokens_total,
               CEIL(NVL(cl.input_chars_total,0)/4)) * NVL(mr.input_unit_rate_eur,0)
    ELSE 0
  END AS prompt_cost_eur,
  CASE mr.pricing_mode
    WHEN 'CHAR' THEN
      NVL(cl.output_chars_total,0) * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_UNIFIED' THEN
      COALESCE(cl.output_tokens_total,
               CEIL(NVL(cl.output_chars_total,0)/4)) * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_SPLIT' THEN
      COALESCE(cl.output_tokens_total,
               CEIL(NVL(cl.output_chars_total,0)/4)) * NVL(mr.output_unit_rate_eur,0)
    ELSE 0
  END AS response_cost_eur,
  CASE mr.pricing_mode
    WHEN 'CHAR' THEN
      ( NVL(cl.input_chars_total,0)
      + NVL(cl.output_chars_total,0) )
      * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_UNIFIED' THEN
      ( COALESCE(cl.input_tokens_total,
                 CEIL(NVL(cl.input_chars_total,0)/4))
      + COALESCE(cl.output_tokens_total,
                 CEIL(NVL(cl.output_chars_total,0)/4)) )
      * NVL(mr.input_unit_rate_eur,0)
    WHEN 'TOKEN_SPLIT' THEN
      COALESCE(cl.input_tokens_total,
               CEIL(NVL(cl.input_chars_total,0)/4))
      * NVL(mr.input_unit_rate_eur,0)
    +
      COALESCE(cl.output_tokens_total,
               CEIL(NVL(cl.output_chars_total,0)/4))
      * NVL(mr.output_unit_rate_eur,0)
    ELSE 0
  END AS row_cost_eur
FROM archive_with_logs cl
LEFT JOIN model_rates mr
  ON mr.model_key = cl.model_id;
