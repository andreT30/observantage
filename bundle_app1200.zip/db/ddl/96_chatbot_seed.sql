/* Seed data for CHATBOT_* tables exported from source environment. */
/* Adjust schema prefix (oci_focus_reports) if needed before running manually. */

/* CHATBOT_PARAMETERS */
/* TODO: adjust column list / keys to your actual structure. */
/* Example MERGE (replace cols and key as needed): */
/*
MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT :PARAM_ID       AS PARAM_ID,
         :DATASET_ID     AS DATASET_ID,
         :PARAM_KEY      AS PARAM_KEY,
         :PARAM_JSON     AS PARAM_JSON
  FROM dual
) s
ON (t.PARAM_ID = s.PARAM_ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET_ID = s.DATASET_ID,
  t.PARAM_KEY  = s.PARAM_KEY,
  t.PARAM_JSON = s.PARAM_JSON
WHEN NOT MATCHED THEN INSERT (
  PARAM_ID, DATASET_ID, PARAM_KEY, PARAM_JSON
) VALUES (
  s.PARAM_ID, s.DATASET_ID, s.PARAM_KEY, s.PARAM_JSON
);
*/

/* CHATBOT_PARAMETER_COMPONENTS */
/* TODO: adjust column list / keys to your actual structure. */
/* Example MERGE (replace cols and key as needed): */
/*
MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENTS t
USING (
  SELECT :COMPONENT_ID   AS COMPONENT_ID,
         :PARAM_ID       AS PARAM_ID,
         :COMPONENT_KEY  AS COMPONENT_KEY,
         :COMPONENT_JSON AS COMPONENT_JSON
  FROM dual
) s
ON (t.COMPONENT_ID = s.COMPONENT_ID)
WHEN MATCHED THEN UPDATE SET
  t.PARAM_ID       = s.PARAM_ID,
  t.COMPONENT_KEY  = s.COMPONENT_KEY,
  t.COMPONENT_JSON = s.COMPONENT_JSON
WHEN NOT MATCHED THEN INSERT (
  COMPONENT_ID, PARAM_ID, COMPONENT_KEY, COMPONENT_JSON
) VALUES (
  s.COMPONENT_ID, s.PARAM_ID, s.COMPONENT_KEY, s.COMPONENT_JSON
);
*/

/* CHATBOT_GLOSSARY_RULES */
/* TODO: adjust column list / keys to your actual structure. */
/* Example MERGE (replace cols and key as needed): */
/*
MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT :RULE_ID        AS RULE_ID,
         :DATASET_ID     AS DATASET_ID,
         :TARGET_TABLE   AS TARGET_TABLE,
         :TARGET_COLUMN  AS TARGET_COLUMN,
         :TARGET_ROLE    AS TARGET_ROLE,
         :FILTER_JSON    AS FILTER_JSON
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET_ID    = s.DATASET_ID,
  t.TARGET_TABLE  = s.TARGET_TABLE,
  t.TARGET_COLUMN = s.TARGET_COLUMN,
  t.TARGET_ROLE   = s.TARGET_ROLE,
  t.FILTER_JSON   = s.FILTER_JSON
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, DATASET_ID, TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, FILTER_JSON
) VALUES (
  s.RULE_ID, s.DATASET_ID, s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.FILTER_JSON
);
*/

/* CHATBOT_GLOSSARY_KEYWORDS */
/* TODO: adjust column list / keys to your actual structure. */
/* Example MERGE (replace cols and key as needed): */
/*
MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT :KEYWORD_ID  AS KEYWORD_ID,
         :RULE_ID     AS RULE_ID,
         :KEYWORD     AS KEYWORD,
         :MATCH_MODE  AS MATCH_MODE
  FROM dual
) s
ON (t.KEYWORD_ID = s.KEYWORD_ID)
WHEN MATCHED THEN UPDATE SET
  t.RULE_ID    = s.RULE_ID,
  t.KEYWORD    = s.KEYWORD,
  t.MATCH_MODE = s.MATCH_MODE
WHEN NOT MATCHED THEN INSERT (
  KEYWORD_ID, RULE_ID, KEYWORD, MATCH_MODE
) VALUES (
  s.KEYWORD_ID, s.RULE_ID, s.KEYWORD, s.MATCH_MODE
);
*/

