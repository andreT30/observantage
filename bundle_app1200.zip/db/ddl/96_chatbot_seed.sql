/* Seed data for CHATBOT_* tables exported from source environment. */
/* Tables: CHATBOT_PARAMETERS, CHATBOT_PARAMETER_COMPONENT, CHATBOT_GLOSSARY_RULES, CHATBOT_GLOSSARY_KEYWORDS, FR_AUTHZ_GROUPS */

/* CHATBOT_PARAMETERS */

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 383 AS ID,
         q'~CHART_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return exactly one JSON object only (no prose, no markdown) using keys: version, chart_id, chart_title, chart_subtitle, chart_type, x, series, sort, legend, notes. Allowed chart_type: bar, line, area, scatter, pie, donut, none. Choose the best chart_type from the data and question intent; prefer pie/donut for part-to-whole composition and line for trend/time progression. If the x field is temporal/date-like according to COLUMN_INFO, set sort=''asc'' and prefer line unless another chart type is explicitly required by the user. Do not sort temporal charts by measure value even when the table/result is a ranked top-N subset. If YEAR and MONTH are separate fields but no combined period field exists, do not use YEAR as a numeric measure; choose chart_type=''none'' and explain that a combined year-month axis is required. Return chart_type=''none'' only when no valid category+numeric measure exists, when a required temporal axis is missing, or when RESULT_ROWS_JSON has <=1 row and the user did not explicitly ask for a chart. If there are at least 2 rows, one valid x/category field, and one valid numeric measure, produce a chart. Use only fields present in input columns/rows. For each series item include name plus y (or field) with an existing numeric column. For pie/donut, use one numeric measure and one category x field.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 384 AS ID,
         q'~CONTEXT_TURNS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~20~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 385 AS ID,
         q'~DEBUG_FLAG~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Y~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 386 AS ID,
         q'~FOLLOWUP_DECIDER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return strict JSON only: {intent,confidence,reason,answer_text,followup_question}. intent must be one of answer_directly|modify_previous_sql|new_query|ask_clarifying.

You receive DECISION_CONTEXT plus the previous user prompt, previous assistant answer, previous summary, previous SQL, previous reasoning/output artifacts, previous execution data, previous chart spec, and latest user prompt.

Decision contract:
- Choose modify_previous_sql when previous_sql_available=true and the latest user prompt is best interpreted as continuing, narrowing, broadening, correcting, reformatting, reranking, regrouping, or otherwise changing the immediately previous SQL-backed analytical result.
- Choose answer_directly when the latest user prompt asks about the previous answer/result and can be answered from the provided previous context without generating SQL.
- Choose new_query when the latest user prompt is a standalone data request that should not inherit the previous SQL/result.
- Choose ask_clarifying only when the provided context is insufficient to distinguish modify_previous_sql, answer_directly, or new_query.
- If previous_sql_available=false, do not choose modify_previous_sql.
- Do not fabricate result values. If an answer requires data that is not present in the previous context, choose modify_previous_sql or new_query rather than answer_directly.
- For ask_clarifying, provide exactly one short followup_question.

Use all provided context, not keyword matching. Confidence should reflect how strongly the latest prompt depends on the previous SQL-backed turn.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 387 AS ID,
         q'~FOLLOWUP_SQL_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Rewrite previous Oracle SQL based on follow-up. Return exactly one Oracle SELECT or NO_SQL. No prose, no markdown, no comments, no semicolon. Keep minimal changes and preserve SELECT columns unless user explicitly asks to change them. For monthly/year-month analysis, preserve or produce one combined period column such as TRUNC(date_col,''MM'') AS month_dt or TO_CHAR(TRUNC(date_col,''MM''),''YYYY-MM'') AS year_month; do not split the same monthly grain into separate YEAR and MONTH output columns unless the user explicitly asks for separate fields.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 388 AS ID,
         q'~FOLLOWUP_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~If clarification is required, produce one short clarification question only. No extra text.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 389 AS ID,
         q'~CLARIFY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return strict JSON only: {"clarify_question":"...","options":["..."],"confidence":0.0,"why_short":"..."}. Ask one concise clarification question and provide 3-4 short options. No prose, no markdown.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 390 AS ID,
         q'~GENERAL_CHAT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Answer directly and helpfully. Do not generate SQL. Do not echo the user question verbatim. No external links. Avoid promise-only phrasing like "I can provide...". If the user asks for code, include a complete runnable example, list requirements/dependencies, include minimal setup steps, and add one short usage example. If placeholders are needed, label them clearly.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 391 AS ID,
         q'~DEBUG_ANALYZER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are the final reducer for NL2SQL debug diagnostics. Combine shard diagnostics into one coherent root-cause analysis. Do not speculate. Use only provided evidence. Output plain text with these section headers exactly: 1) EXECUTION PATH 2) PRIMARY FAILURE CHAIN 3) PHASE FINDINGS (INTENT/ROUTER/SQL/EXECUTION/SUMMARY) 4) ROOT CAUSE 5) ACTIONABLE FIXES (ordered).~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 392 AS ID,
         q'~BUSINESS_DOC_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Answer only from provided business document context. If context is insufficient, say so briefly and ask one specific follow-up.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 393 AS ID,
         q'~BUSINESS_DICTIONARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You answer strictly from the business dictionary context. If nothing relevant is present, return exactly: NO_BUSINESS_DICTIONARY_MATCH. Do not wrap output in code fences. Do not add JSON.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 394 AS ID,
         q'~BUSINESS_DICTIONARY_EXTRACT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You will receive a business dictionary excerpt and a user question. Answer concisely using only the business dictionary content. If nothing relevant is present, return exactly: NO_BUSINESS_DICTIONARY_MATCH. No markdown, no code fences.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 395 AS ID,
         q'~BUSINESS_DICTIONARY_TEXT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Business dictionary for demo_util dataset
- kWh (kilowatt-hour): unit of energy consumption; 1 kWh equals using 1,000 watts for one hour.
- kW (kilowatt): unit of power demand; rate of electricity usage at a point in time.
- Customer Type (RES, COM, IND): account class as Residential, Commercial, or Industrial.
- Service Point (SP): connection point between customer premise and utility network.
- Premise: physical service location where electricity is delivered.
- Meter: device that measures electricity usage at a service point.
- Feeder: high-voltage circuit delivering power from a substation to transformers.
- Transformer: equipment stepping voltage down for end customers.
- Tariff: pricing plan defining kWh, demand, and fixed-charge rates.
- Interval Usage: usage measured at fixed intervals (e.g., 15 min/hourly).
- Quality Flag (GOOD, EST, BAD): indicates valid, estimated, or invalid meter read.
- Outage: period of service interruption.
- Outage Minutes: outage duration in minutes.
- Work Order: operational job assigned to a crew.
- Bill: periodic statement of charges.
- Bill Line: detailed charge item within a bill.
- Payment: settlement transaction for a bill.
- Open Balance: amount still owed after payments.

Business dictionary for demo_fin_fraud dataset
- Transaction: debit or credit movement in a customer account on a given day.
- Transaction Count: total number of transactions recorded for the day.
- Transaction Total Amount: sum of all transaction values for the day.
- Transaction Average Amount: average transaction size for the day.
- Suspicious Transaction (Suspicious Tx): transaction flagged as unusual/high-risk.
- Suspicious Tx Count/Amount: number and total value of suspicious transactions.
- Chargeback: reversal of a disputed transaction.
- Chargeback Count/Amount: number and total value of chargebacks.
- Fraud Score: numeric indicator (0-100) of fraud likelihood.
- Risk Level: LOW, MEDIUM, HIGH category derived from fraud score.
- Alerts Triggered: number of AML/fraud alerts generated.
- AML Flag: indicator of AML watchlist association (Y/N).~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 396 AS ID,
         q'~BUSINESS_DICTIONARY_THRESHOLD_SCORE10~' AS COMPONENT_TYPE,
         TO_CLOB(q'~4~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 397 AS ID,
         q'~DATASET_RULES_EXTRACT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Given DATASET_RULES_TEXT and user question, return strict JSON only: {matches:[{term,reason,score10}],top_terms:[string],confidence}. Use score10 0..10.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 398 AS ID,
         q'~DATASET_RULES_TEXT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Dictionary terms for cost/usage analytics: COST, USAGE, REGION, SERVICECATEGORY, SERVICENAME, RESOURCETYPE, RESOURCENAME, SKUID, PRICINGUNIT, OCI_COMPARTMENTNAME, COSTCENTER, ENVIRONMENT, WORKLOAD_NAME, DATE_BUCKET.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 399 AS ID,
         q'~DATASET_RULES_THRESHOLD_SCORE10~' AS COMPONENT_TYPE,
         TO_CLOB(q'~4~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 400 AS ID,
         q'~DATASET_RULES_HINTS_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~[]~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 401 AS ID,
         q'~DICTIONARY_EXTRACT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Given DICTIONARY_TEXT and user question, return strict JSON only: {matches:[{term,reason,score10}],top_terms:[string],confidence}. Use score10 0..10.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 402 AS ID,
         q'~DICTIONARY_TEXT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Dictionary terms for cost/usage analytics: COST, USAGE, REGION, SERVICECATEGORY, SERVICENAME, RESOURCETYPE, RESOURCENAME, SKUID, PRICINGUNIT, OCI_COMPARTMENTNAME, COSTCENTER, ENVIRONMENT, WORKLOAD_NAME, DATE_BUCKET.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 403 AS ID,
         q'~DICTIONARY_THRESHOLD_SCORE10~' AS COMPONENT_TYPE,
         TO_CLOB(q'~4~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 404 AS ID,
         q'~HISTORY_MAX_CHARS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~20000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 405 AS ID,
         q'~INTENT_CLARIFY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return one short disambiguation question only.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 406 AS ID,
         q'~INTENT_SCHEMA_CTX_MAX_CHARS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~20000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 407 AS ID,
         q'~INTENT_SCHEMA_CTX_TABLE_LIMIT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~10~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 408 AS ID,
         q'~INTENT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~
You are an intent classifier for a data assistant.
Return STRICT JSON only with exactly this schema (no extra keys, no prose):
{"label":"NL2SQL|FOLLOWUP|GENERAL_CHAT|BUSINESS_CHAT","scores":{"NL2SQL":0-1,"FOLLOWUP":0-1,"GENERAL_CHAT":0-1,"BUSINESS_CHAT":0-1},"score10":0-10,"needs_clarify":true|false,"clarifyQuestion":""}

Definitions:
- FOLLOWUP: short message that refines, constrains, or modifies the immediately previous query/answer intent (for example: date window, filters, sort, limit, scope).
- NL2SQL: user expects a query over their data. If the question asks for metrics, rankings, filters, or time windows AND those terms map to DATA_CONTEXT (table summaries/metrics/attributes), choose NL2SQL.
- GENERAL_CHAT: general knowledge, definitions, advice, tool/how-to, or anything answerable without querying the user's data.
- BUSINESS_CHAT: questions that must be answered strictly from business documents if provided (else ask one clarification).

Decision rules:
- Default to GENERAL_CHAT only when the user request is clearly conversational/non-data/help.
- Use DATA_CONTEXT: if the user request references fields/metrics/attributes/time windows that map to DATA_CONTEXT, that is evidence for NL2SQL.
- If prior context includes previous SQL or a previous analytical answer, and the new message can plausibly be interpreted as either FOLLOWUP or new NL2SQL, do not force a high-confidence NL2SQL label.
- In ambiguity between FOLLOWUP and NL2SQL, set needs_clarify=true and ask one short disambiguation question.
- In ambiguity between GENERAL_CHAT and any data-query intent, prefer clarification over direct GENERAL_CHAT.
- If the user message is brief proceed-like continuation phrasing (for example: proceed, continue, go ahead, yes do it, apply this) and History contains prior assistant context, avoid unnecessary clarification unless intent is genuinely ambiguous.

Scoring:
- scores are confidences in [0,1] and should sum to ~~1.
- score10 = round(10 * max(scores)).
- If GENERAL_CHAT is chosen, NL2SQL score should be low (<= 0.2).
- When ambiguity exists between FOLLOWUP and NL2SQL, max score should be <= 0.6.

Clarify:
- needs_clarify=true when max(scores) < 0.7 OR when NL2SQL in [0.3, 0.7] OR when FOLLOWUP in [0.3, 0.7] OR when FOLLOWUP and NL2SQL are both >= 0.3.
- clarifyQuestion must be a single short disambiguation question; empty string otherwise.
- For FOLLOWUP vs new query ambiguity, prefer: "Should I modify the previous query or start a new one?"

Examples (format only):
{"label":"GENERAL_CHAT","scores":{"FOLLOWUP":0.02,"NL2SQL":0.10,"GENERAL_CHAT":0.88,"BUSINESS_CHAT":0.00},"score10":9,"needs_clarify":false,"clarifyQuestion":""}
{"label":"NL2SQL","scores":{"FOLLOWUP":0.05,"NL2SQL":0.88,"GENERAL_CHAT":0.07,"BUSINESS_CHAT":0.00},"score10":9,"needs_clarify":false,"clarifyQuestion":""}
{"label":"GENERAL_CHAT","scores":{"FOLLOWUP":0.05,"NL2SQL":0.35,"GENERAL_CHAT":0.60,"BUSINESS_CHAT":0.00},"score10":6,"needs_clarify":true,"clarifyQuestion":"Do you want me to query your data for this?"}
{"label":"NL2SQL","scores":{"FOLLOWUP":0.44,"NL2SQL":0.46,"GENERAL_CHAT":0.10,"BUSINESS_CHAT":0.00},"score10":5,"needs_clarify":true,"clarifyQuestion":"Should I modify the previous query or start a new one?"}
~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 409 AS ID,
         q'~LLM_TEMPERATURE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~0.1~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 410 AS ID,
         q'~LLM_TOP_P~' AS COMPONENT_TYPE,
         TO_CLOB(q'~0.9~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 411 AS ID,
         q'~LLM_TOP_K~' AS COMPONENT_TYPE,
         TO_CLOB(q'~40~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 412 AS ID,
         q'~LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 413 AS ID,
         q'~LLM_REASONING_EFFORT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~minimal~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 414 AS ID,
         q'~LLM_REASONING_SUMMARY~' AS COMPONENT_TYPE,
         TO_CLOB(q'~off~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 415 AS ID,
         q'~LLM_STRUCTURED_OUTPUT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~N~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 416 AS ID,
         q'~INTENT_CLASSIFIER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"intent_classifier_result","structured_schema":{"type":"object","additionalProperties":false,"required":["label","scores","score10","needs_clarify","clarifyQuestion"],"properties":{"label":{"type":"string","enum":["NL2SQL","FOLLOWUP","GENERAL_CHAT","BUSINESS_CHAT"]},"scores":{"type":"object","additionalProperties":false,"required":["NL2SQL","FOLLOWUP","GENERAL_CHAT","BUSINESS_CHAT"],"properties":{"NL2SQL":{"type":"number","minimum":0,"maximum":1},"FOLLOWUP":{"type":"number","minimum":0,"maximum":1},"GENERAL_CHAT":{"type":"number","minimum":0,"maximum":1},"BUSINESS_CHAT":{"type":"number","minimum":0,"maximum":1}}},"score10":{"type":"integer","minimum":0,"maximum":10},"needs_clarify":{"type":"boolean"},"clarifyQuestion":{"type":"string"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 417 AS ID,
         q'~ROUTER_LLM_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"router_llm_result","structured_schema":{"type":"object","additionalProperties":false,"required":["selected_tables","join_path","filters_hint","aggregation_hint","confidence","why"],"properties":{"selected_tables":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["table","reason"],"properties":{"table":{"type":"string"},"reason":{"type":"string"}}}},"join_path":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["left_table","right_table","join","reason"],"properties":{"left_table":{"type":"string"},"right_table":{"type":"string"},"join":{"type":"string"},"reason":{"type":"string"}}}},"filters_hint":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["field","op","value","reason"],"properties":{"field":{"type":"string"},"op":{"type":"string"},"value":{"anyOf":[{"type":"string"},{"type":"number"},{"type":"boolean"},{"type":"array"},{"type":"object"},{"type":"null"}]},"reason":{"type":"string"}}}},"aggregation_hint":{"type":"object","additionalProperties":false,"required":["grain","metrics","group_by"],"properties":{"grain":{"type":"string"},"metrics":{"type":"array","items":{"type":"string"}},"group_by":{"type":"array","items":{"type":"string"}},"order_by":{"type":"array"},"limit":{"anyOf":[{"type":"number"},{"type":"null"}]}}},"confidence":{"type":"number","minimum":0,"maximum":1},"why":{"type":"string"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 418 AS ID,
         q'~ROUTER_LLM_RETRY_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"router_llm_retry_result","structured_schema":{"type":"object","additionalProperties":false,"required":["selected_tables","join_path","filters_hint","aggregation_hint","confidence","why"],"properties":{"selected_tables":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["table","reason"],"properties":{"table":{"type":"string"},"reason":{"type":"string"}}}},"join_path":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["left_table","right_table","join","reason"],"properties":{"left_table":{"type":"string"},"right_table":{"type":"string"},"join":{"type":"string"},"reason":{"type":"string"}}}},"filters_hint":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["field","op","value","reason"],"properties":{"field":{"type":"string"},"op":{"type":"string"},"value":{"anyOf":[{"type":"string"},{"type":"number"},{"type":"boolean"},{"type":"array"},{"type":"object"},{"type":"null"}]},"reason":{"type":"string"}}}},"aggregation_hint":{"type":"object","additionalProperties":false,"required":["grain","metrics","group_by"],"properties":{"grain":{"type":"string"},"metrics":{"type":"array","items":{"type":"string"}},"group_by":{"type":"array","items":{"type":"string"}},"order_by":{"type":"array"},"limit":{"anyOf":[{"type":"number"},{"type":"null"}]}}},"confidence":{"type":"number","minimum":0,"maximum":1},"why":{"type":"string"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 419 AS ID,
         q'~FOLLOWUP_DECIDER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"followup_decider_result","structured_schema":{"type":"object","additionalProperties":false,"required":["intent","confidence"],"properties":{"intent":{"type":"string","enum":["answer_directly","modify_previous_sql","new_query","ask_clarifying"]},"confidence":{"type":"number","minimum":0,"maximum":1},"reason":{"type":"string"},"answer_text":{"type":"string"},"clarify_question":{"type":"string"},"clarification_question":{"type":"string"},"followup_question":{"type":"string"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 420 AS ID,
         q'~CLARIFY_BUILDER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"clarify_builder_result","structured_schema":{"type":"object","additionalProperties":false,"required":["clarify_question","options","confidence","why_short"],"properties":{"clarify_question":{"type":"string"},"options":{"type":"array","minItems":2,"items":{"type":"string"}},"confidence":{"type":"number","minimum":0,"maximum":1},"why_short":{"type":"string"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 422 AS ID,
         q'~SQL_DRAFT_BUILDER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"sql_draft_builder_result","structured_schema":{"type":"object","additionalProperties":false,"required":["sql"],"properties":{"sql":{"type":"string","minLength":1}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 423 AS ID,
         q'~SQL_REPAIR_BUILDER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"sql_repair_builder_result","structured_schema":{"type":"object","additionalProperties":false,"required":["sql"],"properties":{"sql":{"type":"string","minLength":1}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 424 AS ID,
         q'~SCHEMA_PROBE_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"schema_probe_result","max_output_tokens":4000,"structured_schema":{"type":"object","additionalProperties":false,"required":["sql","confidence","why","reason"],"properties":{"sql":{"type":"string","minLength":20},"confidence":{"type":"number","minimum":0,"maximum":1},"why":{"type":"string","minLength":30},"reason":{"type":"string","minLength":180,"pattern":".*Chosen columns dictionary:.*"}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 426 AS ID,
         q'~VALUE_RULES_ENRICH_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"value_rules_enrich_result","structured_schema":{"type":"object","additionalProperties":false,"required":["items"],"properties":{"items":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["value","synonyms"],"properties":{"value":{"type":"string"},"synonyms":{"type":"array","items":{"type":"string"}}}}}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 427 AS ID,
         q'~RESULT_SUMMARIZER_TEMPLATE_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"result_summarizer_template","structured_schema":{"type":"object","additionalProperties":false,"required":["answer_mode","list_count","number_format","comparison_mode","must_include","must_avoid"],"properties":{"answer_mode":{"type":"string","enum":["direct","list","comparison","timeseries","empty_result","not_available"]},"list_count":{"type":"integer","minimum":1,"maximum":5},"number_format":{"type":"string","enum":["integer_default_avg2"]},"comparison_mode":{"type":"string","enum":["none","YoY","MoM","QoQ","DoD"]},"must_include":{"type":"array","items":{"type":"string"}},"must_avoid":{"type":"array","items":{"type":"string"}}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 428 AS ID,
         q'~RESULT_SUMMARIZER_TEMPLATE_RETRY_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"minimal","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"result_summarizer_template_retry","structured_schema":{"type":"object","additionalProperties":false,"required":["answer_mode","list_count","number_format","comparison_mode","must_include","must_avoid"],"properties":{"answer_mode":{"type":"string","enum":["direct","list","comparison","timeseries","empty_result","not_available"]},"list_count":{"type":"integer","minimum":1,"maximum":5},"number_format":{"type":"string","enum":["integer_default_avg2"]},"comparison_mode":{"type":"string","enum":["none","YoY","MoM","QoQ","DoD"]},"must_include":{"type":"array","items":{"type":"string"}},"must_avoid":{"type":"array","items":{"type":"string"}}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 429 AS ID,
         q'~CHART_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0.1,"top_p":0.9,"top_k":40,"reasoning_effort":"off","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"chart_result","structured_schema":{"type":"object","additionalProperties":false,"required":["version","chart_id","chart_title","chart_subtitle","chart_type","x","series","sort","legend","notes"],"properties":{"version":{"type":"string"},"chart_id":{"type":"string"},"chart_title":{"type":"string"},"chart_subtitle":{"type":"string"},"chart_type":{"type":"string","enum":["bar","line","area","scatter","pie","donut","none"]},"x":{"anyOf":[{"type":"string"},{"type":"null"}]},"series":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["name","y"],"properties":{"name":{"type":"string"},"y":{"type":"string"}}}},"sort":{"anyOf":[{"type":"string"},{"type":"null"}]},"legend":{"type":"boolean"},"notes":{"anyOf":[{"type":"string"},{"type":"null"}]}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 430 AS ID,
         q'~CHART_SPEC_BUILDER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0.1,"top_p":0.9,"top_k":40,"reasoning_effort":"off","reasoning_summary":"off","structured_output":true,"structured_strict":true,"structured_name":"chart_result","structured_schema":{"type":"object","additionalProperties":false,"required":["version","chart_id","chart_title","chart_subtitle","chart_type","x","series","sort","legend","notes"],"properties":{"version":{"type":"string"},"chart_id":{"type":"string"},"chart_title":{"type":"string"},"chart_subtitle":{"type":"string"},"chart_type":{"type":"string","enum":["bar","line","area","scatter","pie","donut","none"]},"x":{"anyOf":[{"type":"string"},{"type":"null"}]},"series":{"type":"array","items":{"type":"object","additionalProperties":false,"required":["name","y"],"properties":{"name":{"type":"string"},"y":{"type":"string"}}}},"sort":{"anyOf":[{"type":"string"},{"type":"null"}]},"legend":{"type":"boolean"},"notes":{"anyOf":[{"type":"string"},{"type":"null"}]}}}}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 440 AS ID,
         q'~LLM_MAX_OUTPUT_TOKENS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~4000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 441 AS ID,
         q'~LLM_MAX_INPUT_CHARS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~60000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 442 AS ID,
         q'~LLM_COHERE_OUTPUT_CAP_TOKENS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~4000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 443 AS ID,
         q'~LLM_API_FORMAT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~GENERIC~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 444 AS ID,
         q'~LLM_ENDPOINT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~https://inference.generativeai.eu-frankfurt-1.oci.oraclecloud.com/openai/v1~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-05-01 14:46:51.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 445 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an Oracle NL2SQL compiler. Return exactly one Oracle SELECT statement or NO_SQL. Use only provided schema/tables/columns/joins and planning hints. No DML/DDL. No markdown, no comments, no semicolon, no invented objects. Prefer explicit aliases and deterministic predicates. Oracle 19c syntax only (no LIMIT/OFFSET). Use FETCH FIRST or ROWNUM for limits. Avoid SELECT *; output explicit columns. Use TRUNC(CURRENT_DATE) for day-level time filters. Use case-insensitive comparisons for user-supplied text (UPPER/LOWER). For monthly/year-month analysis, output one combined period column such as TRUNC(date_col,''MM'') AS month_dt or TO_CHAR(TRUNC(date_col,''MM''),''YYYY-MM'') AS year_month; do not output separate YEAR and MONTH columns for the same grain unless the user explicitly asks for separate fields. Return final executable Oracle SQL, not a template. Never emit unresolved placeholders or macros such as {{START_DATE}}, {{END_DATE}}, <DATE>, :START_DATE, or pseudo-variables. When the request implies a relative time window, compile it directly into Oracle expressions in the SQL you return.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 446 AS ID,
         q'~NO_SQL_FOLLOWUP_QUESTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~I need one clarification to produce valid SQL. What exact metric, filters, and time window should I use?~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 449 AS ID,
         q'~ROUTER_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Y~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 450 AS ID,
         q'~ROUTER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return strict JSON only: {selected_tables,join_path,filters_hint,aggregation_hint,confidence,why}. Select minimal relevant tables from candidates; use concrete OWNER.TABLE.COLUMN names when possible; do not invent tables/columns. filters_hint.op is an abstract semantic operator, not SQL syntax. Allowed operators: EQ, CONTAINS_CI, PREFIX_CI, SUFFIX_CI, BETWEEN, IN. Use CONTAINS_CI for fuzzy case-insensitive substring matching such as "AI-related"; do not emit ILIKE or LIKE as router operators. Use EQ only when the user clearly asks for an exact categorical/code match. If DICTIONARY_MATCHES provides authoritative target.filter constraints, preserve them exactly and do not weaken them into fuzzy matching. If multiple authoritative matches apply to the same field, preserve all matched values by using IN rather than dropping one. aggregation_hint is semantic planning guidance, not final SQL: group_by must contain only existing concrete column tokens from TABLE_SUMMARIES, never SQL functions, aliases, partial identifiers, or expressions. For monthly/year-month analysis, set aggregation_hint.grain="YEAR_MONTH" and group_by=["OWNER.TABLE.DATE_COLUMN"] using the relevant date column; SQL_DRAFT_BUILDER will create the month bucket expression. metrics may describe aggregate intent but must reference existing columns. If unsure, select the single most likely table.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 451 AS ID,
         q'~STRICT_SQL_OUTPUT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return exactly one Oracle SELECT statement and nothing else. If impossible, return NO_SQL.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 452 AS ID,
         q'~SQL_STABILITY_RULES~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Prefer stable SQL shape across equivalent prompts.
- If request asks for both a time-series ("per month"/"per year month"/trend) and top N performers, return full time-series rows and include a top-N helper flag via CASE WHEN rank<=N THEN ''Y'' ELSE ''N'' END; do not return rank ordinal columns unless the user explicitly asks for rank/position/index.
- For monthly/year-month analysis, use one combined bucket expression, preferably TRUNC(datetime_col,''MM'') AS month_dt, and ORDER BY that bucket ascending. Do not split the same monthly grain into separate YEAR and MONTH output columns unless explicitly requested.
- Use half-open date intervals for period bounds when possible (>= start, < next period boundary) to avoid ambiguity between <= end-date and < next-day forms.
- Keep column naming and ordering stable for equivalent intents.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 453 AS ID,
         q'~FOLLOWUP_SQL_EDIT_RULES~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Follow-up intent is modify_previous_sql. Treat PREVIOUS_SQL as the baseline query and preserve its semantics, grain, joins, and existing mandatory filters unless the user explicitly asks to change them. If the follow-up changes only top N, limit, ordering, or presentation, keep the same selected dimensions and measures and update only the requested part. For monthly/year-month analysis, preserve or rewrite to one combined period column such as TRUNC(date_col,''MM'') AS month_dt or TO_CHAR(TRUNC(date_col,''MM''),''YYYY-MM'') AS year_month; do not split the same monthly grain into separate YEAR and MONTH output columns unless explicitly requested. If PREVIOUS_SQL already split YEAR and MONTH for a monthly grain, normalize it to one combined period column before applying the follow-up.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 454 AS ID,
         q'~SUMMARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a domain expert analyst for business and technical SQL results. Be strictly data-grounded: use only provided rows, column metadata, SQL context, and user question. Ignore prior conversation values, prior runs, and prior totals unless they are explicitly present in the current result payload. Provide a direct answer first, then concise supporting evidence from the result set. When the data is cloud cost/usage oriented, prefer clear FinOps/FOCUS-style wording such as cost, usage, service, billing period, provider, region, and scope when those concepts are supported by the result columns. Do not invent values, trends, entities, periods, causes, or calculations not derivable from the provided results. If rows are empty, state that no rows matched the filters. Use "Not available in this result set." only when rows exist but required fields/calculations are missing. Keep tone professional and concise. Output Markdown only (no code fences). You may use at most one lightweight visual marker if it improves readability, and it must be an inline Material Symbol span such as <span class="material-symbols-outlined">query_stats</span>. Do not use emoji or other decorative UTF8 symbols. Do not output SQL.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 455 AS ID,
         q'~SUMMARY_TEMPLATE_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are constructing a summary template for a downstream summarizer. Return STRICT JSON only (single object), no markdown, no code fences, no commentary. Use exactly this schema: {"answer_mode":"direct|list|comparison|timeseries|empty_result|not_available","list_count":1-5,"number_format":"integer_default_avg2","comparison_mode":"none|YoY|MoM|QoQ|DoD","must_include":[string],"must_avoid":[string]}. Deterministic rules: (1) If rows_total=0 choose answer_mode="empty_result". (2) If rows_total>0 and the requested metric is present in columns/rows, do NOT choose "not_available". (3) Use "not_available" only when rows exist but required fields/calculations are truly missing. (4) must_include may contain only short semantic hints (max 3). (5) must_avoid must never contain metric names from result columns, numeric literals, or phrases like "not available". Template logic: infer intent from user question and result context. Use comparison mode for vs/versus, compare, increase/decrease, higher/lower trend questions; include appropriate comparison_mode when possible. Use list mode for ranking/top/most/least questions (unless user explicitly asks for only one). Keep template minimal and derivable only from provided context.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 603 AS ID,
         q'~OPENAI_PROJECT_ID~' AS COMPONENT_TYPE,
         TO_CLOB(q'~ocid1.generativeaiproject.oc1.eu-frankfurt-1.amaaaaaagla5i5iaogev6l6wok6j3hsolcn3hlpiddbdvsrckdh33zt2egma~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-04-30 22:10:23.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 604 AS ID,
         q'~WELCOME_MESSAGE_MD~' AS COMPONENT_TYPE,
         TO_CLOB(q'~# 👋 OCI Focus Cost Assistant

Ask questions about OCI spend, usage, services, SKUs, compartments, regions, tags, trends, and cost drivers.

## 💬 Try asking

- 📊 What was the total cost last month?
- 📈 Show monthly cost by service.
- 🗂️ Which compartments had the highest spend?
- 🔁 Compare compute cost between the last two months.
- ⚠️ Find unusual cost increases.
- 🏷️ Summarize cost by tag or project.

## ✅ Tip

For better answers, include a **time period**, **metric**, and **grouping**.

> Show total cost by service for March 2026.

## ℹ️ Note

Answers are based on the cost data currently available in this application.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-04-30 22:08:36.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 606 AS ID,
         q'~ROUTER_LLM_RETRY_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Previous output was malformed JSON. Return strict JSON only (single object), no markdown, no code fences, no commentary.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 607 AS ID,
         q'~ROUTER_FOLLOWUP_ROUTING_GUIDANCE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~User is modifying the previous query. Prefer PREVIOUS_SQL tables/joins and keep route changes minimal unless user asks to change subject.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 609 AS ID,
         q'~VALUE_RULES_ENRICH_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You generate generic lexical variants for canonical string values used in SQL router matching. Return strict JSON only (single object): {"items":[{"value":"<exact-input-value>","synonyms":["s1","s2","s3"]}]}. Keep each value unchanged; do not include the original value in synonyms; avoid duplicates/null/empty; avoid case-only/punctuation-only/spacing-only variants; expand coded values only when clearly supported by context; avoid inferred meaning/ranking/temporal assumptions.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 610 AS ID,
         q'~INSIGHTS_HYPOTHESIS_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are ranking candidate analytics hypotheses for a pinned SQL result. Return strict JSON only: {"hypotheses":[{"hypothesis_id":"H1","dimension":"...","relevance":0.0-1.0,"why":"...","expected_signal":"..."}]}. Use only provided candidates; no causality claims (contributors only); prefer high actionability and clarity; max 5 hypotheses; include dimension exactly as provided.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 611 AS ID,
         q'~JSON_CONVERTER_SUMMARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a precise SQL DDL + metadata summarization engine that converts table definitions into a structured JSON description for an NL2SQL router. You receive CREATE_TABLE_JSON and TABLE_DESCRIPTION_JSON for the same table. Use both inputs (TABLE_DESCRIPTION_JSON is primary semantics). Return only one valid JSON object with keys: table_name, summary, keys, metrics, attributes, column_comments, keywords, sample_questions. Use only columns present in CREATE_TABLE_JSON, uppercase column names in output sets/maps, classify conservatively (when unsure use attributes), and keep output syntactically valid JSON matching the schema.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 612 AS ID,
         q'~STRICT_JSON_CONTRACT_TEMPLATE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Return one valid JSON object only, matching the required schema exactly.
No markdown, no code fences, no prose outside JSON, no duplicate objects, no trailing fragments.
Do not invent tables, columns, joins, or identifiers beyond provided context.
Never emit placeholders (<...>, ???, TBD) or corrupted tokens.
If uncertain, still return one best valid JSON object that satisfies schema.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 613 AS ID,
         q'~LLM_DISABLE_CONVERSATION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~FALSE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 614 AS ID,
         q'~LLM_USE_CONVERSATION_ALL_PHASES~' AS COMPONENT_TYPE,
         TO_CLOB(q'~FALSE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 615 AS ID,
         q'~GENERIC_LONG_MEMORY_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 616 AS ID,
         q'~GENERIC_MEMORY_ACCESS_POLICY~' AS COMPONENT_TYPE,
         TO_CLOB(q'~recall_and_store~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 617 AS ID,
         q'~NL2SQL_LONG_MEMORY_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~FALSE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 618 AS ID,
         q'~NL2SQL_MEMORY_ACCESS_POLICY~' AS COMPONENT_TYPE,
         TO_CLOB(q'~recall_and_store~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 619 AS ID,
         q'~RESULT_SUMMARIZER_LLM_CONFIG_JSON~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"temperature":0,"top_p":1,"top_k":40,"reasoning_effort":"low","reasoning_summary":"auto"}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 629 AS ID,
         q'~MOM_SQL_REQUIREMENT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~MoM requirement is active. SQL must compute month-over-month outputs using window LAG over monthly grain and return columns for CURRENT, PREVIOUS, DELTA, and PCT_CHANGE. Do not return only monthly totals.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 631 AS ID,
         q'~SUMMARY_TEMPLATE_RETRY_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Previous output was malformed JSON. Return strict JSON only (single object), no markdown, no code fences, no commentary.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 632 AS ID,
         q'~SUMMARY_FOLLOWUP_CONTEXT_RULE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~This is a follow-up on the previous SQL result. Preserve the same business metric and subject unless the new user question explicitly changes them.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 633 AS ID,
         q'~SUMMARY_FINAL_TASK_INSTRUCTIONS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Produce the final summary in Markdown only, following SUMMARY_TEMPLATE_JSON and all grounding rules. No JSON, no SQL, no markdown code fences.
Hard rules: If rows_total>0 and a numeric metric is present in RESULT_ROWS_JSON, provide the metric value directly and do not answer "Not available in this result set.".
FINAL_SUMMARIZER_INSTRUCTIONS:
- Use only the current RESULT_ROWS_JSON, COLUMN INFO, and USER QUESTION. Ignore prior conversation values or previous-run totals not present in the current result.
- Apply semantic normalization between business terms and returned metric labels (for example: revenue/cost/value/amount may map to TOTAL_COST or other monetary aggregates).
- Do not require exact lexical match between user wording and column alias when numeric aggregate evidence is present.
- If exactly one numeric aggregate row is returned, answer with that value directly as the primary answer.
- If the answer requires arithmetic across multiple current rows, compute it only from the numeric values in the current RESULT_ROWS_JSON and re-check the arithmetic before finalizing the answer.
- For grouped results such as monthly, service, region, or provider breakdowns, keep the structure scan-friendly: one short answer line first, then a compact breakdown list or table only if it adds value.
- For monetary outputs, use EUR symbol (€) formatting as instructed by SUMMARY_SYSTEM.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 634 AS ID,
         q'~SCHEMA~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"COST_USAGE_DAILY_WKLD_V","alias":"cudwv","columns":[{"name":"DATE_BUCKET","type":"DATE"},{"name":"BILLINGACCOUNTID","type":"VARCHAR2"},{"name":"SUBACCOUNTNAME","type":"VARCHAR2"},{"name":"INVOICEISSUER","type":"VARCHAR2"},{"name":"REGION","type":"VARCHAR2"},{"name":"BILLINGCURRENCY","type":"VARCHAR2"},{"name":"SERVICECATEGORY","type":"VARCHAR2"},{"name":"SERVICENAME","type":"VARCHAR2"},{"name":"CHARGEDESCRIPTION","type":"VARCHAR2"},{"name":"RESOURCETYPE","type":"VARCHAR2"},{"name":"RESOURCEID","type":"VARCHAR2"},{"name":"RESOURCENAME","type":"VARCHAR2"},{"name":"SKUID","type":"VARCHAR2"},{"name":"PRICINGUNIT","type":"VARCHAR2"},{"name":"OCI_COMPARTMENTID","type":"VARCHAR2"},{"name":"OCI_COMPARTMENTNAME","type":"VARCHAR2"},{"name":"OCI_COMPARTMENT_PATH","type":"VARCHAR2"},{"name":"USAGEUNIT","type":"VARCHAR2"},{"name":"COST","type":"NUMBER"},{"name":"USAGE","type":"NUMBER"},{"name":"LAST_REFRESH","type":"DATE"},{"name":"CREATED_BY","type":"VARCHAR2"},{"name":"IMPLEMENTOR","type":"VARCHAR2"},{"name":"COSTCENTER","type":"VARCHAR2"},{"name":"ENVIRONMENT","type":"VARCHAR2"},{"name":"WORKLOAD_NAME","type":"VARCHAR2"}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-04-30 20:49:24.382333','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 635 AS ID,
         q'~TABLE_DESCRIPTIONS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"COST_USAGE_DAILY_WKLD_V","description":"Table COST_USAGE_DAILY_WKLD_V: daily OCI cost and usage fact view enriched with workload mapping. Use this as the primary table for workload-based NL2SQL questions about spend, usage, daily trends, service breakdowns, compartment rollups, cost centers, environments, implementors, and creators.","columns":[{"name":"DATE_BUCKET","description":"daily date bucket for the cost and usage record"},{"name":"BILLINGACCOUNTID","description":"billing account identifier"},{"name":"SUBACCOUNTNAME","description":"billing subaccount or subscription name"},{"name":"INVOICEISSUER","description":"provider or legal entity that issued the invoice"},{"name":"REGION","description":"OCI region where the usage occurred"},{"name":"BILLINGCURRENCY","description":"currency code used for billing amounts"},{"name":"SERVICECATEGORY","description":"broad OCI service family used for high-level grouping and filtering, such as Compute, Storage, Network, Database, or Security"},{"name":"SERVICENAME","description":"specific OCI service or product name within a service family, used for a more detailed breakdown than SERVICECATEGORY"},{"name":"CHARGEDESCRIPTION","description":"detailed billing line item description, often more granular than SERVICECATEGORY or SERVICENAME and useful for charge-type analysis"},{"name":"RESOURCETYPE","description":"technical OCI resource class associated with the usage, such as instance, boot volume, bucket, load balancer, or database"},{"name":"RESOURCEID","description":"OCI resource identifier, usually an OCID"},{"name":"RESOURCENAME","description":"human-readable display name of a specific resource instance, more specific than RESOURCETYPE"},{"name":"SKUID","description":"billing SKU identifier for the consumed item"},{"name":"PRICINGUNIT","description":"billing unit used to price the SKU, such as per hour, per GB-month, or per request"},{"name":"OCI_COMPARTMENTID","description":"OCI compartment OCID tied to the usage"},{"name":"OCI_COMPARTMENTNAME","description":"leaf compartment name tied to the usage record"},{"name":"OCI_COMPARTMENT_PATH","description":"full compartment hierarchy path used for organizational rollups and subtree filtering"},{"name":"USAGEUNIT","description":"measurement unit of the consumed quantity, such as OCPU hour, GB, GB-month, or requests"},{"name":"COST","description":"billed cost amount for the date bucket"},{"name":"USAGE","description":"normalized usage quantity for the date bucket, measured in USAGEUNIT"},{"name":"LAST_REFRESH","description":"date when the fact record was last refreshed"},{"name":"CREATED_BY","description":"creator or owner tag value extracted from OCI tags"},{"name":"IMPLEMENTOR","description":"implementor or responsible engineer tag value extracted from OCI tags"},{"name":"COSTCENTER","description":"business cost center tag value used for financial allocation and workload mapping"},{"name":"ENVIRONMENT","description":"deployment environment tag value such as prod, dev, test, or sandbox"},{"name":"WORKLOAD_NAME","description":"business workload assigned by matching OCI_COMPARTMENTID or COSTCENTER against OCI_WORKLOADS.VALUE"}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-04-30 20:49:24.433947','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 773 AS ID,
         q'~GENERIC_GUARDRAILS_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 774 AS ID,
         q'~GENERIC_GUARDRAILS_FAIL_CLOSED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 775 AS ID,
         q'~GENERIC_GUARDRAILS_CONTENT_MODERATION_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 776 AS ID,
         q'~GENERIC_GUARDRAILS_PROMPT_INJECTION_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 777 AS ID,
         q'~GENERIC_GUARDRAILS_PII_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 778 AS ID,
         q'~GENERIC_GUARDRAILS_BLOCK_INPUT_PII~' AS COMPONENT_TYPE,
         TO_CLOB(q'~FALSE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 779 AS ID,
         q'~GENERIC_GUARDRAILS_BLOCK_OUTPUT_PII~' AS COMPONENT_TYPE,
         TO_CLOB(q'~TRUE~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 780 AS ID,
         q'~GENERIC_GUARDRAILS_PII_TYPES~' AS COMPONENT_TYPE,
         TO_CLOB(q'~EMAIL,TELEPHONE_NUMBER,ADDRESS~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2026-05-03 14:20:21.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 781 AS ID,
         q'~GENERIC_GUARDRAILS_LANGUAGE_CODE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~en~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO CHATBOT_PARAMETERS t
USING (
  SELECT 782 AS ID,
         q'~GENERIC_GUARDRAILS_BLOCK_MESSAGE~' AS COMPONENT_TYPE,
         TO_CLOB(q'~I can't help with that request because it triggered the configured safety guardrails. Please rephrase without unsafe, sensitive, or policy-bypassing instructions.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

/* CHATBOT_PARAMETER_COMPONENT */

/* CHATBOT_GLOSSARY_RULES */

/* CHATBOT_GLOSSARY_KEYWORDS */

/* FR_AUTHZ_GROUPS (ADMIN/CONTRIBUTOR/USER) */

MERGE INTO FR_AUTHZ_GROUPS t
USING (
  SELECT q'~ADMIN~' AS GROUP_CODE,
         q'~Administrators~' AS APEX_GROUP,
         q'~focus-reports-apex-admins~' AS SSO_GROUP,
         NULL AS WORKLOAD_NAME
  FROM dual
) s
ON (t.GROUP_CODE = s.GROUP_CODE)
WHEN MATCHED THEN UPDATE SET
  t.APEX_GROUP    = s.APEX_GROUP,
  t.SSO_GROUP     = s.SSO_GROUP,
  t.WORKLOAD_NAME = s.WORKLOAD_NAME
WHEN NOT MATCHED THEN INSERT (
  GROUP_CODE, APEX_GROUP, SSO_GROUP, WORKLOAD_NAME
) VALUES (
  s.GROUP_CODE, s.APEX_GROUP, s.SSO_GROUP, s.WORKLOAD_NAME
);

MERGE INTO FR_AUTHZ_GROUPS t
USING (
  SELECT q'~CONTRIBUTOR~' AS GROUP_CODE,
         q'~Contributors~' AS APEX_GROUP,
         q'~focus-reports-apex-contributors~' AS SSO_GROUP,
         NULL AS WORKLOAD_NAME
  FROM dual
) s
ON (t.GROUP_CODE = s.GROUP_CODE)
WHEN MATCHED THEN UPDATE SET
  t.APEX_GROUP    = s.APEX_GROUP,
  t.SSO_GROUP     = s.SSO_GROUP,
  t.WORKLOAD_NAME = s.WORKLOAD_NAME
WHEN NOT MATCHED THEN INSERT (
  GROUP_CODE, APEX_GROUP, SSO_GROUP, WORKLOAD_NAME
) VALUES (
  s.GROUP_CODE, s.APEX_GROUP, s.SSO_GROUP, s.WORKLOAD_NAME
);

MERGE INTO FR_AUTHZ_GROUPS t
USING (
  SELECT q'~USER~' AS GROUP_CODE,
         q'~Users~' AS APEX_GROUP,
         q'~focus-reports-apex-users~' AS SSO_GROUP,
         NULL AS WORKLOAD_NAME
  FROM dual
) s
ON (t.GROUP_CODE = s.GROUP_CODE)
WHEN MATCHED THEN UPDATE SET
  t.APEX_GROUP    = s.APEX_GROUP,
  t.SSO_GROUP     = s.SSO_GROUP,
  t.WORKLOAD_NAME = s.WORKLOAD_NAME
WHEN NOT MATCHED THEN INSERT (
  GROUP_CODE, APEX_GROUP, SSO_GROUP, WORKLOAD_NAME
) VALUES (
  s.GROUP_CODE, s.APEX_GROUP, s.SSO_GROUP, s.WORKLOAD_NAME
);

