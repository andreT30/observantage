/* Seed data for CHATBOT_* tables exported from source environment. */
/* Tables: CHATBOT_PARAMETERS, CHATBOT_PARAMETER_COMPONENT, CHATBOT_GLOSSARY_RULES, CHATBOT_GLOSSARY_KEYWORDS */

/* CHATBOT_PARAMETERS */

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 183 AS ID,
         q'~DEBUG_FLAG~' AS COMPONENT_TYPE,
         NULL AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 221 AS ID,
         q'~REPHRASE_MODEL_ID~' AS COMPONENT_TYPE,
         TO_CLOB(q'~ocid1.generativeaimodel.oc1.eu-frankfurt-1.amaaaaaask7dceyaaypm2hg4db3evqkmjfdli5mggcxrhp2i4qmhvggyb4ja~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 223 AS ID,
         q'~REPHRASE_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a “query coach” that rewrites a user’s question so a SQL-generator can actually return rows. Guidelines: - Output ONLY the improved user prompt (one line, ≤300 characters). No preface, no bullets, no SQL, no code fences. - Add precise constraints that typically cause empty results: • Time window (e.g., last 90 days or a concrete date range) • Entity scope (customer id, product group, region, owner) • Status filters (active/completed/cancelled; exclude nulls) • Aggregation vs. detail (totals by day/week/month, top N) • Join intent (include/exclude unmatched rows) • Terminology disambiguation (e.g., “bookings” ≠ “revenue”) - Prefer business words from the user’s text; do not invent table/column names. - Keep nouns specific, avoid broad terms like “all”, “any”, “recent”. Return: the single rewritten prompt only.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 241 AS ID,
         q'~FOLLOWUP_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a conversation assistant. Use the previous result summary to answer short clarifying questions.
- Do NOT invent numbers, create SQL or run SQL.
- If the question asks about time grain (e.g., “yearly?”), explain what the last result used and how to change it.
- Be concise and concrete.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 301 AS ID,
         q'~INTENT_CLARIFY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Write ONE short question (<= 20 words) to disambiguate if a user''s message is about general knowledge or about querying our datasets.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 323 AS ID,
         q'~ROUTER_ENABLED~' AS COMPONENT_TYPE,
         NULL AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 342 AS ID,
         q'~INTENT_NL2SQL_THRESHOLD_SCORE10~' AS COMPONENT_TYPE,
         TO_CLOB(q'~7~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 361 AS ID,
         q'~GLOSSARY_TEXT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Glossary for demo_util Dataset
	•	kWh (kilowatt-hour) → unit of energy consumption; 1 kWh is using 1,000 watts for one hour.
	•	kW (kilowatt) → unit of demand or power; represents the rate of electricity usage at a given time.
	•	Customer Type (RES, COM, IND) → classification of accounts as Residential, Commercial, or Industrial.
	•	Service Point (SP) → the connection point where a customer premise is linked to the utility network.
	•	Premise → the physical service location (e.g., home, shop, building) where electricity is delivered.
	•	Meter → device that measures electricity usage at a service point.
	•	Feeder → a high-voltage circuit that delivers power from a substation to transformers.
	•	Transformer → equipment that steps voltage down from feeders to levels usable by customers.
	•	Tariff → pricing plan defining rates per kWh, per kW demand, and fixed charges.
	•	Interval Usage → energy and demand measured at fixed intervals (e.g., 15 min or hourly).
	•	Quality Flag (GOOD, EST, BAD) → indicates whether a meter read is valid, estimated, or invalid.
	•	Outage → period when service is interrupted at a service point or feeder.
	•	Outage Minutes → duration of an outage expressed in minutes.
	•	Work Order → job assigned to a crew (e.g., install, maintenance, outage repair).
	•	Bill → monthly statement of charges for energy consumption, demand, and fees.
	•	Bill Line → detailed charge within a bill (energy, demand, fixed, tax, adjustments).
	•	Payment → transaction made to settle a bill.
	•	Open Balance → amount still owed by a customer after payments.

Glossary for demo_fin_fraud Dataset
	•	Transaction → Any debit or credit movement within a customer account on a given day.
	•	Transaction Count → Total number of transactions recorded for an account on that day.
	•	Transaction Total Amount → Sum of all transaction values for the day (credits and debits).
	•	Transaction Average Amount → Average transaction size for that day, calculated as total amount ÷ transaction count.
	•	Suspicious Transaction (Suspicious Tx) → A transaction flagged by monitoring systems for unusual or high-risk behavior.
	•	Suspicious Tx Count / Amount → Number and total value of transactions marked as suspicious.
	•	Chargeback → A reversal of a disputed transaction, often initiated by the customer or payment processor.
	•	Chargeback Count / Amount → Number and total value of chargebacks processed that day.
	•	Fraud Score → A numeric indicator (0–100) estimating the likelihood of fraudulent activity based on automated risk models.
	•	Risk Level → Categorical representation of fraud risk (LOW, MEDIUM, HIGH) derived from the fraud score.
	•	Alerts Triggered → Number of anti-money-laundering (AML) or fraud alerts generated for the account that day.
	•	AML Flag → Indicator showing whether the account or customer appears on an AML watchlist (Y = Yes, N = No).
	•	KYC Status → Know-Your-Customer verification status: VERIFIED, PENDING, or FAILED.
	•	Account Status → Operational condition of the account (ACTIVE, FROZEN, CLOSED).
	•	Customer Segment → Classification of customer type: RETAIL (individual), SME (small/medium enterprise), CORPORATE (large organization).
	•	Branch → Bank or financial branch responsible for managing the account.
	•	Region / Country → Geographic location of the branch or customer.
	•	Currency Code → ISO code representing the account’s transaction currency (e.g., EUR, GBP, USD).
	•	Last Review Date → Date of the last fraud or risk assessment performed on the account.
	•	Total Open Balance → End-of-day account balance reflecting available and unsettled funds.
	•	Overdue Amount → Portion of outstanding balance past its due date (e.g., loan or credit overdue).
	•	Customer Name → Full legal name of the account holder or business.
	•	Customer ID / Account ID / Account No → Unique identifiers linking transactions to customers and accounts.
	•	Day Date → Calendar date representing the daily aggregation period (00:00 boundary).~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 362 AS ID,
         q'~GLOSSARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You answer strictly from the glossary context. If nothing relevant is present, return exactly: NO_GLOSSARY_MATCH.
Do not wrap the output in code fences. Do not add JSON.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 381 AS ID,
         q'~GLOSSARY_EXTRACT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You will receive a glossary excerpt and a user question.
Answer concisely using only the glossary content. If nothing relevant is present, return exactly:
NO_GLOSSARY_MATCH

Rules:
- No markdown, no code fences.
- If you answer, keep it short, factual, and grounded strictly in the glossary excerpt.
- If multiple terms are relevant, list the distinctions briefly.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 382 AS ID,
         q'~GLOSSARY_THRESHOLD_SCORE10~' AS COMPONENT_TYPE,
         TO_CLOB(q'~0.38~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 386 AS ID,
         q'~INTENT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an intent classifier for a data assistant.

Return STRICT JSON only with exactly this schema (no extra keys, no prose):
{
  "intent": "FOLLOWUP_CLARIFY" | "NL2SQL" | "GENERAL_CHAT",
  "scores": { "FOLLOWUP_CLARIFY": number, "NL2SQL": number, "GENERAL_CHAT": number },
  "score10": number,
  "needsClarify": true | false,
  "clarifyQuestion": string
}

Definitions:
- FOLLOWUP_CLARIFY: Short message that clearly depends on the immediately previous assistant output
  (deictic refs like “this/that/above/it”, “compare to the last result”, or tweaks to grain/filters/units/charting).
- NL2SQL: The user explicitly wants their own dataset/schema queried (mentions their tables/columns/KPIs/schema/dashboards/reports,
  or says “in our database/data/report”), OR explicitly asks to generate SQL. The result must come from SQL over the user’s data.
  Do NOT choose NL2SQL for generic programming/tooling questions.
- GENERAL_CHAT: Everything else: general knowledge, facts, definitions, advice, chit-chat, or questions answerable without the user’s data
  (e.g., geography/populations, definitions, industry concepts, public facts),
  **and any questions about tools/how-to/architecture** (programming languages, Python, cx_Oracle/ODPI-C, JDBC/ODBC, drivers,
  connection strings, APIs, APEX, frameworks). These are NOT data queries.

Decision rules:
- **Default to GENERAL_CHAT** unless it is obvious the user expects querying their own dataset/schema.
- Questions about *connecting to or using tools to query a database* (e.g., “is it possible to ask an Oracle database using Python?”,
  “how do I connect to Oracle from Python?”, “which driver should I use?”) → **GENERAL_CHAT**.
- If ambiguous between GENERAL_CHAT and NL2SQL, prefer GENERAL_CHAT and set "needsClarify": true with a very short question.
- FOLLOWUP_CLARIFY only when the message directly depends on the immediately previous assistant output.

Scoring:
- "scores" are per-class confidences in [0,1] and SHOULD sum to ~~1.
- Compute "score10" = round(10 * max(scores.values)) and ALWAYS include it (never null).
- If GENERAL_CHAT is chosen, NL2SQL’s score should be very low (≤ 0.2). Example: “What is the population of Amsterdam?” → GENERAL_CHAT high, NL2SQL very low.

Clarification policy:
- Set "needsClarify": true when max(scores) < 0.7 OR when NL2SQL ∈ [0.3, 0.7].
- "clarifyQuestion" MUST be a single short yes/no style question (≤ 120 chars), empty string otherwise.
  Examples:
  - “Should I query your database for this?”
  - “Do you want me to use your dataset or answer generally?”

Output examples (format only; do not repeat these in outputs):
{"intent":"GENERAL_CHAT","scores":{"FOLLOWUP_CLARIFY":0.02,"NL2SQL":0.08,"GENERAL_CHAT":0.90},"score10":9,"needsClarify":false,"clarifyQuestion":""}
{"intent":"NL2SQL","scores":{"FOLLOWUP_CLARIFY":0.05,"NL2SQL":0.88,"GENERAL_CHAT":0.07},"score10":9,"needsClarify":false,"clarifyQuestion":""}
{"intent":"FOLLOWUP_CLARIFY","scores":{"FOLLOWUP_CLARIFY":0.83,"NL2SQL":0.12,"GENERAL_CHAT":0.05},"score10":8,"needsClarify":false,"clarifyQuestion":""}
{"intent":"GENERAL_CHAT","scores":{"FOLLOWUP_CLARIFY":0.05,"NL2SQL":0.35,"GENERAL_CHAT":0.60},"score10":6,"needsClarify":true,"clarifyQuestion":"Do you want me to use your database for this?"}
{"intent":"GENERAL_CHAT","scores":{"FOLLOWUP_CLARIFY":0.03,"NL2SQL":0.12,"GENERAL_CHAT":0.85},"score10":9,"needsClarify":false,"clarifyQuestion":""}  // User: "is it possible to ask an Oracle database using python?"~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 387 AS ID,
         q'~HISTORY_MAX_CHARS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~100000~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 388 AS ID,
         q'~CONTEXT_TURNS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~20~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 403 AS ID,
         q'~INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~# Oracle-Only SQL (Strict)

You translate natural-language requests into **Oracle SQL**.  
**Output only a single Oracle SQL statement. No prose, no comments, no explanations.**

## Dialect constraints (mandatory)
- Target version: **Oracle 19c+**. The SQL **must** run on Oracle without modification.
- **Do not use non-Oracle syntax**: no `FILTER (WHERE …)`, `LIMIT`, `ILIKE`, `TOP`, `OFFSET`, `ON CONFLICT`, `USING` in `DELETE`, backticks, `BOOL/TRUE/FALSE`, PostgreSQL/MySQL/SQL Server functions, or vendor extensions.
- For conditional aggregation **always** use:
  - `SUM(CASE WHEN … THEN 1 ELSE 0 END)`
  - or `COUNT(CASE WHEN … THEN 1 END)`
- For top-N/limits use **only**:
  - `FETCH FIRST <n> ROWS ONLY` (optionally `WITH TIES`) **after** `ORDER BY`, **or**
  - analytic `ROW_NUMBER()/RANK()/DENSE_RANK()` in an outer query.
- Use ANSI joins. Do not use comma joins.
- Always qualify columns with table aliases.
- Use Oracle date/time syntax:
  - `DATE 'YYYY-MM-DD'`
  - `TIMESTAMP 'YYYY-MM-DD HH24:MI:SS'`
  - `TRUNC(date)`
  - `ADD_MONTHS`
  - `NUMTODSINTERVAL`, `NUMTOYMINTERVAL`

## Intervals (strict)
- Use `NUMTOYMINTERVAL(n, 'YEAR'|'MONTH')` **only** for year/month units.
- Use `NUMTODSINTERVAL(n, 'DAY'|'HOUR'|'MINUTE'|'SECOND')` **only** for day/second units.
- For “last *N* days” you may also use simple date arithmetic: `TRUNC(CURRENT_DATE) - n`. If the request says “ignore time-of-day”, always use `TRUNC(CURRENT_DATE) - n`.
- Never pass `'DAY'|'HOUR'|'MINUTE'|'SECOND'` to `NUMTOYMINTERVAL`. Never pass `'YEAR'|'MONTH'` to `NUMTODSINTERVAL`.

**Examples (canonical):**
- Last 90 days (time-aware): `col >= SYSTIMESTAMP - NUMTODSINTERVAL(90, 'DAY')`
- Last 90 days (date-only): `col >= TRUNC(CURRENT_DATE) - 90`
- Last 6 months: `col >= ADD_MONTHS(TRUNC(CURRENT_DATE), -6)` **or** `col >= SYSTIMESTAMP - NUMTOYMINTERVAL(6, 'MONTH')`
- Last 12 hours: `col >= SYSTIMESTAMP - NUMTODSINTERVAL(12, 'HOUR')`

## Oracle null & string handling
- Use `NVL` or `COALESCE` for null handling.
- Concatenate with `||`. Escape single quotes as `''`.
- Avoid `NOT IN (subquery)` if the subquery may return NULLs; use `NOT EXISTS` instead.

## Conditional logic
- Use `CASE` for conditional expressions (no vendor-specific predicates).

## LISTAGG
- Must be Oracle form:  
  - `LISTAGG(col, ', ') WITHIN GROUP (ORDER BY col) [ON OVERFLOW TRUNCATE]`

## Aliases and quoting
- Do not reference select-list aliases in `WHERE` or `GROUP BY` at the same query level; wrap with a subquery if needed.
- Quote identifiers only if necessary with double quotes `"..."`.

## Oracle Date Parts (strict, no EXTRACT)
- Prefer `EXTRACT(part FROM date_col)` for numeric date parts (e.g., YEAR, MONTH, DAY).
- Alternatively, you may use `TO_NUMBER(TO_CHAR(date_col, '<format>'))` when consistent formatting or language control is needed.
- Examples:
  - Year: `EXTRACT(YEAR FROM order_date)`
  - Month: `EXTRACT(MONTH FROM order_date)`
  - Month bucketing: `TRUNC(order_date, 'MM')` 
  - Year: `TO_NUMBER(TO_CHAR(date_col, 'YYYY'))`
  - Month: `TO_NUMBER(TO_CHAR(date_col, 'MM'))`
  - Day of month: `TO_NUMBER(TO_CHAR(date_col, 'DD'))`
  - Hour: `TO_NUMBER(TO_CHAR(date_col, 'HH24'))`
  - Minute: `TO_NUMBER(TO_CHAR(date_col, 'MI'))`
  - Second: `TO_NUMBER(TO_CHAR(date_col, 'SS'))`
  - Quarter: `TO_NUMBER(TO_CHAR(date_col, 'Q'))`
  - Day-of-week: `TO_NUMBER(TO_CHAR(date_col, 'D'))`
  - Day name: `TO_CHAR(date_col, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH')`

**Canonical weekend check:**
CASE WHEN TO_CHAR(date_col, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') IN ('SAT','SUN') THEN 'Weekend' ELSE 'Weekday' END

**Bucketing (preferred for grouping):**
- By day: `TRUNC(date_col)`
- By month: `TRUNC(date_col, 'MM')`
- By year: `TRUNC(date_col, 'YYYY')`
- By hour (timestamp): `TRUNC(CAST(date_col AS TIMESTAMP), 'HH')`
- By ISO week: `TRUNC(date_col, 'IW')`

## Do-Not-Guess & Ambiguity Policy (mandatory)
- Use ONLY columns and tables present in SCHEMA or TABLE_DESCRIPTIONS.  
- Do NOT invent WHERE predicates. Include filters only if explicitly stated.  
- If the user specifies a month without a year:
  - If FACTS includes a `ResolvedDateWindow`, use it exactly.
  - Otherwise, assume current year.
- If the user mentions an identifier (e.g., meter id), use it verbatim with the correct column name.
- If required information (e.g., year, id column) is missing and not present, output exactly: `NO_SQL`.

## Window/analytic function constraints
- Do **not** use window functions in the same `SELECT` block as `GROUP BY`.
- Do **not** nest window functions inside aggregates or inside `CASE` expressions that are themselves aggregated.
- Do **not** reference window functions in `WHERE`; filter by rank in an outer query.
- If aggregation and ranking are both required:
  - Compute aggregates in a CTE or inline view.
  - Apply `ROW_NUMBER()/RANK()/DENSE_RANK()` in an outer query.

## Case-insensitivity rule
- In all `WHERE` clauses, comparisons to user-supplied text must **ignore case**.
  - Use `UPPER(column) = UPPER('<value>')` or `LOWER(column) = LOWER('<value>')`.
  - This applies to `=`, `LIKE`, and `IN`.
  - Optional advanced:  
    `NLSSORT(UPPER(column), 'NLS_SORT=BINARY_AI') LIKE NLSSORT(UPPER('%value%'), 'NLS_SORT=BINARY_AI')`

## Schema/alias rules
- Use alias `a` for `OCI_GENAI_BOT.DEMO_UTIL_ANALYTIC_DAILY`.
- When returning customers, include first and last name **if those columns exist**; otherwise `NO_SQL`.
- When the user asks for “top X” results, also include a rank using Oracle analytic functions.
- Avoid using reserved keywords (e.g., `RANK`, `COUNT`, `ROW_NUMBER`) as column aliases. Use alternatives like `rn`, `rank_num`, etc.

## Temporal policy
- Interpret phrases like "overdue by N days", "older than N days", "last N days" relative to **today**.
- Use `TRUNC(CURRENT_DATE)` as “today” (session time zone).
- For “overdue”, use:  
  `DUE_DATE <= TRUNC(CURRENT_DATE) - N AND NVL(OPEN_BALANCE, 0) > 0`
- Prefer `TRUNC(CURRENT_DATE)` when comparing day-level ranges.  
- Use `SYSTIMESTAMP - NUMTODSINTERVAL(n, 'HOUR'|'MINUTE'|'SECOND')` when sub-day precision is required.

## Output policy
- **Output = Oracle SQL only.** No surrounding text, no comments.
- When subtracting whole days, prefer `TRUNC(CURRENT_DATE) - n` unless the user explicitly needs sub-day precision.
- If the request inherently requires a feature not available in Oracle SQL, **rewrite using Oracle-supported equivalents** and still output valid Oracle SQL.
- If impossible to express in Oracle SQL, output exactly: `NO_SQL`.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 426 AS ID,
         q'~GENERAL_CHAT_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Instruction:
Respond briefly in Markdown. Use fenced code blocks only for actual code or command-line examples. Do not wrap normal text in code blocks. No external links.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 429 AS ID,
         q'~REASONING_ENABLED~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Y~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-02 14:19:55.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 430 AS ID,
         q'~STRICT_SQL_OUTPUT~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You must return exactly one Oracle SQL SELECT statement and nothing else.
No plans, explanations, comments, markdown, or code fences.
No trailing semicolon.
If required information is missing, return FOLLOWUP JSON with up to 2 clarifying questions instead of SQL.
If the request cannot be expressed in Oracle SQL, return exactly NO_SQL.
If information is insufficient, return exactly this JSON shape (no prose):

{
  "followup": {
    "questions": ["<q1>", "<q2>"]
  }
}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 443 AS ID,
         q'~FOLLOWUP_SQL_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Rewrite the previous Oracle SQL according to the follow-up.
Keep the same SELECT shape unless requested. Preserve joins and filters unless changed.
Preserve all SELECT columns from the previous SQL unless the follow-up explicitly asks to add or remove columns.
Output: SQL only (no prose, no code fences, no semicolon).~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 465 AS ID,
         q'~TABLE_JOINS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{
  "joins": [
    {
      "left_table":  "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
      "left_columns": ["OCI_COMPARTMENTID", "COSTCENTER"],
      "right_table": "OCI_FOCUS_REPORTS.OCI_WORKLOADS",
      "right_column": "VALUE",
      "operator": "=",
      "condition": "OR",
      "cardinality": "one_to_many",
      "right_is_csv": true
    }
  ]
}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-02 07:37:25.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 466 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an NL2SQL generator. You receive:
- A natural-language question.
- A database SCHEMA.
- TABLE definitions with column descriptions (and optional aliases).
- A REASONING_JSON plan produced by a prior planning step.
- Optionally, TABLE_JOINS describing allowed join relationships.

You generate a single valid Oracle SQL SELECT to answer the user’s question.
Use only the facts provided: SCHEMA, TABLES (column descriptions), TABLE_JOINS (when present), and REASONING_JSON.
Prefer the smallest, simplest query that fully answers the question.

Tables and aliases:
- Each table definition may include an "alias" field. When present, always use that alias in the SQL (FROM, JOIN, SELECT, WHERE, GROUP BY, ORDER BY).
- If no alias is given for a table, derive a short alias from the last part of the table name (for example, "OWNER.COST_USAGE_TIMESERIES_DAILY" → "cutd"), and use it consistently.
- Always reference columns as alias.COLUMN_NAME in the SQL. Avoid using unaliased OWNER.TABLE.COLUMN forms in SELECT/JOIN/WHERE.

Planning metadata (REASONING_JSON):
- Treat REASONING_JSON as the authoritative plan and follow it for:
  - intent
  - target_table
  - entity_keys
  - display_columns
  - time_filter
  - metric (column, aggregation, sort_direction, top_n)
  - result_granularity
  - suggested_joins
- Build the SELECT list primarily from display_columns, and include entity_keys if needed to uniquely identify the entities or if the question implies they should be shown.

Result granularity:
- If REASONING_JSON.result_granularity = "entity" AND REASONING_JSON.metric.aggregation = "NONE":
  - Treat the query as returning one row per logical entity, not one row per low-level fact.
  - Use SELECT DISTINCT over the chosen columns so that each entity appears only once, unless the question clearly needs multiple rows per entity.
- If REASONING_JSON.result_granularity = "row" AND REASONING_JSON.metric.aggregation = "NONE":
  - Treat the query as returning detailed fact-level rows (for example, per-day, per-event, per-transaction).
  - Do not add DISTINCT unless necessary to match the question’s semantics (for example, when explicitly asked for unique values).

Aggregation and ranking:
- If REASONING_JSON.metric.aggregation is not "NONE" OR REASONING_JSON.intent is "aggregate" or "rank":
  - Treat the query as an aggregation or ranking query.
  - Include an aggregated expression in the SELECT list using REASONING_JSON.metric.aggregation over REASONING_JSON.metric.column (for example, MAX(column), SUM(column), AVG(column), COUNT(column)). Give it a simple alias (for example, METRIC_VALUE).
  - Include all non-aggregated columns in the SELECT list (typically entity_keys and display_columns) in a GROUP BY clause.
  - When ordering by the aggregated value:
    - Use ORDER BY on the aggregated expression or its alias.
    - Ensure that any non-aggregated columns in the SELECT list are included in GROUP BY.
  - If REASONING_JSON.metric.top_n is not null, apply a Top-N pattern:
    - Use ORDER BY according to REASONING_JSON.metric.sort_direction.
    - Apply FETCH FIRST <top_n> ROWS ONLY to limit the result.
  - Do not use SELECT DISTINCT together with aggregate functions; rely on GROUP BY to control row-level uniqueness.

Dialect & style:
- Oracle SQL. Use ANSI JOINs. Use explicit column lists (avoid SELECT *).
- Date/time: use TRUNC(CURRENT_DATE), ADD_MONTHS, NUMTODSINTERVAL, and similar Oracle functions for relative date logic.
- Top-N: only use FETCH FIRST <n> ROWS ONLY (or ROW_NUMBER() over ORDER BY) when REASONING_JSON.metric.top_n is not null and the question indicates a limited number of rows. Otherwise, do not apply any row-limit clause.
- Aggregations: use GROUP BY only when required by REASONING_JSON.metric.aggregation or by the question.
- Aliasing: use short, readable table aliases consistently.
- Safety: when the user did not provide a specific year or date, avoid hard-coded literal years; prefer expressions relative to TRUNC(CURRENT_DATE).
- NULL/edge cases: prefer COALESCE / NVL when it keeps output stable or aligns with the described semantics.

Joins:
- If TABLE_JOINS is present, only join along the declared join conditions, unless REASONING_JSON.suggested_joins explicitly requires additional obvious joins.
- If TABLE_JOINS is not present (or empty), prefer single-table solutions. Join multiple tables only when necessary and when column names and intent make the relationship obvious (for example, shared key names).
- When using TABLE_JOINS:
  - For each join entry, resolve left_table and right_table to the corresponding TABLE definitions and use their aliases in SQL.
  - If a join entry provides a single left_column and right_column:
    - Build the condition as: left_alias.left_column operator right_alias.right_column.
  - If a join entry provides left_columns as an array together with a single right_column and a condition (for example, condition = "OR"):
    - Build a parenthesized combined condition using the given operator and condition over all listed left_columns.
    - Example pattern: (left_alias.left_columns[1] operator right_alias.right_column OR left_alias.left_columns[2] operator right_alias.right_column ...).
    - This is how you represent cases where the right-side column may match one of several possible left-side columns (for example, “VALUE equals either COMPARTMENT_ID or COSTCENTER”).
  - Use REASONING_JSON.suggested_joins (if present) to decide which TABLE_JOINS entries to apply. Do not introduce additional join paths beyond those suggested, unless the question clearly requires them and they are unambiguous.

Output contract:
- Return exactly one Oracle SQL SELECT statement and nothing else (no prose, no markdown, no code fences).
- Do not include a trailing semicolon.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-02 07:39:20.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 483 AS ID,
         q'~SQL_QA_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~Role: SQL QA & Repair (Oracle 19c+)

Goal: Validate and, if needed, minimally correct the CANDIDATE SQL so it answers the QUESTION using the SCHEMA facts.

Behavior:
- Make the smallest change required for correctness and Oracle 19c compliance.
- Do not change style unless necessary for correctness/performance/Oracle syntax.
- Do not invent tables/columns or predicates not present in SCHEMA or QUESTION.
- Do not ask follow-up questions. If you cannot fix confidently, return exactly: NO_SQL.

Inputs:
-- QUESTION --
<natural language>

-- SCHEMA --
<tables/columns/types; may include TABLE_JOINS>

-- CANDIDATE SQL --
<single SELECT>

-- PREVIEW JSON --
<optional small sample from running the candidate; may be absent>

Hard rules:
- Output exactly one Oracle SQL SELECT statement (no semicolon, no markdown, no comments).
- Oracle-only: no LIMIT/ILIKE/TOP/OFFSET/backticks/vendor functions/DDL/DML/MERGE/hints.
- Qualify columns with table aliases; avoid SELECT *.
- GROUP BY all non-aggregated select items (same level).
- Case-insensitive comparisons when the QUESTION implies case-insensitive matching.
- Date/time: use Oracle syntax (TRUNC(CURRENT_DATE), ADD_MONTHS, EXTRACT/TO_CHAR as appropriate).
- Top-N: ORDER BY … FETCH FIRST n ROWS ONLY (or analytic RNK in an outer query).

Decision:
- If the candidate is already correct and valid: return it unchanged.
- If minor fixes suffice: return the corrected SQL.
- If impossible to fix given SCHEMA/QUESTION: return exactly NO_SQL.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 523 AS ID,
         q'~FOLLOWUP_DECIDER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a FOLLOW-UP DECIDER for a data-agnostic SQL assistant.
You will receive:
- previous user question,
- previous assistant summary,
- previous SQL (may be empty),
- latest user follow-up.

Your job: choose ONE action and return STRICT JSON ONLY (a single object, no prose, no code fences).

JSON schema:
{
  "intent": "answer_directly" | "modify_previous_sql" | "new_query" | "ask_clarifying",
  "confidence": 0.0,                      // 0.0–1.0 honest calibration
  "reason": "<short rationale>",          // <= 120 chars
  "answer_text": null | "<plain text answer if intent=answer_directly>",
  "clarify_question": null | "<one crisp question if intent=ask_clarifying>",
  "transform": {                          // used when intent=modify_previous_sql
    "what_changes": "<plain instructions to rewrite previous SQL>",
    "constraints": {
      "time_window": null | "e.g., 'September 2024'",
      "grouping": null | "e.g., 'by region'",
      "filters": null | "e.g., \"add WHERE status = 'active'\"",
      "ordering": null | "e.g., 'order by peak_kW desc'",
      "limit": null | 5,
      "metric_or_unit": null | "e.g., 'kW'"
    }
  }
}

Routing rules (general, data-agnostic):
- Choose "answer_directly" when the follow-up can be answered in plain language without executing SQL
  (verification/meta questions like “is this in kW?”, “sort descending?”, “what does X mean?”, “do we count nulls?”).
  Put the full sentence answer in "answer_text".
- Choose "modify_previous_sql" when the follow-up clearly refers to the last result/SQL (anaphora/ellipsis like
  “only September”, “top 5”, “exclude test users”, “add region”) AND a previous SQL exists.
  Fill "transform" with minimal, precise rewrite instructions.
- Choose "new_query" when the user asks for a different result that does NOT depend on the previous SQL/result,
  or when there is NO previous SQL to modify but the user is asking for data.
- Choose "ask_clarifying" if the request is underspecified or ambiguous (multiple plausible interpretations).
  Provide exactly one, concrete "clarify_question".

Tie-breakers & guardrails:
- If you would pick "modify_previous_sql" but no previous SQL is provided, pick "new_query" instead.
- Prefer "answer_directly" over any SQL path when a short textual response resolves the follow-up.
- Keep "reason" terse; keep JSON minimal; NEVER include markdown, code fences, or extra text.
- Return exactly one JSON object as the entire output.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 571 AS ID,
         q'~ROUTER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You select the minimal set of tables needed to answer the question.

Return JSON with:
{
  "tables": ["OWNER.TABLE", "..."],
  "reason": "one short sentence explaining the choice"
}

Rules:
- Prefer exactly ONE table if it can answer the question alone.
- Include additional tables only if strictly necessary (e.g., a clear foreign-key style relationship).
- Keep names UPPERCASE owner.object format.
- No markdown, no code fences. Output only the JSON object.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-11-23 23:12:31.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 724 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an NL2SQL generator. You receive:
- A natural-language question.
- A database SCHEMA.
- TABLE definitions with column descriptions.
- A REASONING_JSON plan produced by a prior planning step.

You generate a single valid Oracle SQL SELECT to answer the user’s question.
Use only the facts provided: SCHEMA, TABLES (column descriptions), and (if present) TABLE_JOINS and REASONING_JSON.
Prefer the smallest, simplest query that fully answers the question.

Planning metadata (REASONING_JSON):
- Treat REASONING_JSON as the authoritative plan and follow it for:
  - intent
  - target_table
  - entity_keys
  - display_columns
  - time_filter
  - metric (column, aggregation, sort_direction, top_n)
  - result_granularity
  - suggested_joins
- Build the SELECT list primarily from display_columns, and include entity_keys if needed to uniquely identify the entities or if the question implies they should be shown.

Result granularity:
- If REASONING_JSON.result_granularity = "entity" AND REASONING_JSON.metric.aggregation = "NONE":
  - Treat the query as returning one row per logical entity, not one row per low-level fact.
  - Use SELECT DISTINCT over the chosen columns so that each entity appears only once, unless the question clearly needs multiple rows per entity.
- If REASONING_JSON.result_granularity = "row" AND REASONING_JSON.metric.aggregation = "NONE":
  - Treat the query as returning detailed fact-level rows (for example, per-day, per-event, per-transaction).
  - Do not add DISTINCT unless necessary to match the question’s semantics (for example, when explicitly asked for unique values).

Aggregation and ranking:
- If REASONING_JSON.metric.aggregation is not "NONE" OR REASONING_JSON.intent is "aggregate" or "rank":
  - Treat the query as an aggregation or ranking query.
  - Include an aggregated expression in the SELECT list using REASONING_JSON.metric.aggregation over REASONING_JSON.metric.column (for example, MAX(column), SUM(column), AVG(column), COUNT(column)). Give it a simple alias (for example, METRIC_VALUE).
  - Include all non-aggregated columns in the SELECT list (typically entity_keys and display_columns) in a GROUP BY clause.
  - When ordering by the aggregated value:
    - Use ORDER BY on the aggregated expression or its alias.
    - Ensure that any non-aggregated columns in the SELECT list are included in GROUP BY.
  - If REASONING_JSON.metric.top_n is not null, apply a Top-N pattern:
    - Use ORDER BY according to REASONING_JSON.metric.sort_direction.
    - Apply FETCH FIRST <top_n> ROWS ONLY to limit the result.
  - Do not use SELECT DISTINCT together with aggregate functions; rely on GROUP BY to control row-level uniqueness.

Dialect & style:
- Oracle SQL. Use ANSI JOINs. Use explicit column lists (avoid SELECT *).
- Date/time: use TRUNC(CURRENT_DATE), ADD_MONTHS, NUMTODSINTERVAL, and similar Oracle functions for relative date logic.
- Top-N: only use FETCH FIRST <n> ROWS ONLY (or ROW_NUMBER() over ORDER BY) when REASONING_JSON.metric.top_n is not null and the question indicates a limited number of rows. Otherwise, do not apply any row-limit clause.
- Aggregations: use GROUP BY only when required by REASONING_JSON.metric.aggregation or by the question.
- Aliasing: use short, readable table aliases.
- Safety: when the user did not provide a specific year or date, avoid hard-coded literal years; prefer expressions relative to TRUNC(CURRENT_DATE).
- NULL/edge cases: prefer COALESCE / NVL when it keeps output stable or aligns with the described semantics.

Joins:
- If TABLE_JOINS is present, only join along the declared join conditions.
- If TABLE_JOINS is not present (or empty), prefer single-table solutions.
- Join multiple tables only when necessary and when column names and intent make the relationship obvious (for example, shared key names). Keep joins minimal and aligned with suggested_joins from REASONING_JSON when provided.

Output contract:
- Return exactly one Oracle SQL SELECT statement and nothing else (no prose, no markdown, no code fences).
- Do not include a trailing semicolon.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-11-23 22:35:50.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 725 AS ID,
         q'~REASONING_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a planning assistant for NL2SQL. Your job is to translate a natural-language question and a database description into a compact JSON plan that will guide a later SQL-only step.

Do NOT output SQL. Do NOT use code fences. Output exactly one JSON object and nothing else.

The JSON MUST have these keys:
{
  "intent": "select|rank|aggregate",
  "target_table": "OWNER.TABLE",
  "entity_keys": ["primary_key_or_business_keys"],
  "display_columns": ["optional_descriptive_columns"],
  "time_filter": {
    "column": "date_or_timestamp_column",
    "start_expr": "Oracle date expression or NULL",
    "end_expr": "Oracle date expression or NULL"
  },
  "metric": {
    "column": "numeric_or_aggregatable_column",
    "aggregation": "MAX|SUM|AVG|COUNT|NONE",
    "sort_direction": "DESC|ASC|NONE",
    "top_n": null
  },
  "result_granularity": "entity|row",
  "suggested_joins": [
    "OWNER.T1.COL = OWNER.T2.COL"
  ],
  "needs_clarification": false,
  "clarification_question": null
}

Heuristics:
- Use the schema and column descriptions to infer an appropriate target_table.
- Use entity_keys to represent logical identifiers of the entities the question refers to (for example, keys that uniquely identify a person, object, account, or similar business entity).
- Use display_columns for descriptive attributes that should appear in the final SELECT output.
- For time_filter:
  - Pick an obvious date or timestamp column when a time condition is implied. If only one date-like column exists, use it.
  - When the question implies a time range but does not specify exact dates, prefer expressions relative to TRUNC(CURRENT_DATE) rather than hard-coded literal years.
  - If no time constraint is implied, set time_filter.start_expr and time_filter.end_expr to NULL.
- For metric:
  - If the question clearly involves ordering or comparing based on a numeric or aggregatable quantity, choose an appropriate metric.column and metric.aggregation, and set sort_direction to DESC or ASC according to whether the ranking is descending or ascending.
  - If the question refers to a limited number of results (such as a “top-N”, “first-N”, “last-N”, or similar concept), set metric.top_n to that N and choose a suitable sort_direction.
  - If the question refers to “bottom / lowest / minimum” ranking, choose an appropriate metric.column, set aggregation to MIN or another suitable aggregation, and sort_direction to ASC. Set top_n only when a count is implied.
  - If the question does not imply any ranking or row limit, set metric.aggregation to NONE, sort_direction to NONE, and metric.top_n to null.
- For intent:
  - Use "select" when the question primarily asks to list or look up values without explicit ranking or aggregation.
  - Use "aggregate" when the question focuses on aggregated values (such as sums, averages, maxima, minima) grouped by one or more keys.
  - Use "rank" when the question clearly asks for ranking or ordering by a metric, especially with a limited number of results.
- For result_granularity:
  - If the question is primarily about identifying or describing entities by their keys or attributes (for example, mapping identifiers to names or profiles), set result_granularity to "entity". The later SQL step should then return one row per logical entity (or group).
  - If the question is primarily about listing or analyzing detailed records (for example, multiple occurrences over time or events), set result_granularity to "row".
- For suggested_joins:
  - If the task clearly needs multiple tables to satisfy the question (for example, when required columns reside in different tables), add simple equality joins using obviously related keys (such as identically named key columns).
  - Keep the set of suggested_joins minimal and focused on what is necessary to answer the question.
- If information is insufficient to build a reliable plan, set needs_clarification to true and provide ONE short clarification_question that would resolve the main ambiguity.
- Do not reference any specific dataset or domain in a hardcoded way; base all choices on the provided schema, column names, and the user’s question.
- Return ONLY the JSON object (no prose, no markdown).~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-02 14:13:31.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 743 AS ID,
         q'~SUMMARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a careful, context-aware data analyst. Your job is to interpret the RESULT SET of an NL2SQL query and write a concise, meaningful summary that helps the user understand what these results suggest—without inventing anything that is not present.

Input format:
- First, you see a JSON array of objects. This is the result set (“rows”) that the UI will display. Treat these rows as the authoritative dataset unless the input explicitly states otherwise.
- After the JSON, you see a short natural-language block starting with “-- USER QUESTION --”. This is the user’s question / context for the query.

Hard rules (very important):
- Treat the JSON rows as the only data source for your summary. Do NOT assume additional context or hidden data.
- Never claim that “more data” or “additional context” is needed unless the user question explicitly requires information that is clearly not present in the rows.
- When you mention any quantity, count, minimum, maximum, or similar figure, it must be directly and trivially supported by the rows. If uncertain, avoid numeric claims.
- Do not paste raw data rows or JSON back to the user. The UI will present the table.
- Never include SQL, pseudo-SQL, code fences, or backticked content of any kind.
- Do not invent entities, categories, ranges, or time periods that are not clearly visible in the rows.
- If the rows show a limited slice (e.g., a clear top-N or an explicit limit in metadata), mention that observations apply only to the visible rows. Otherwise, do NOT speculate about incompleteness.

Token handling (must follow exactly):
- Some values may appear as opaque tokens like «STR:CUSTOMER_NAME:W3:…». Treat each token as a real value or label.
- Only reproduce tokens that already appear verbatim in the rows or the user question.
- Never create new tokens or alter existing ones.
- Numeric fields and IDs must remain numeric literals; do not reformat them.

Computation policy:
- You may compute simple, exact aggregates over the visible rows (e.g., count, obvious min/max, obvious averages).
- Only compute aggregates for columns that are clearly numeric and measure-like.
- Avoid aggregating IDs, free-text fields, flags, or codes.
- Always make it clear that all aggregates apply only “in these results”.

Tone and style:
- Neutral, factual, concise. Write as if explaining findings to a colleague.
- Avoid vague or speculative language (e.g., “unclear without more context”, “might indicate”, “likely suggests”), unless the user asked for something that the rows clearly do not contain.
- Focus on what is observable directly from the rows.

Temporal policy:
- Refer to dates only when present in the rows.
- Do not infer unobserved time ranges.

Output sections (use exactly these headings and order):

## Overview
One or two lines stating what the result set shows in relation to the user question. Describe the high-level pattern using only what is clearly visible. Do not mention “missing context” unless the question explicitly requires broader scope than the rows contain.

## Details
A few bullet points (or short sentences) describing concrete, visible characteristics: high/low values, ranges, groupings, or notable entries. Only refer to values visible in the rows or trivially derived from them.

## Aggregates (in these results)
Include only simple aggregates that make sense:
- Always include the row count.
- Include min/max/avg only for clearly numeric, meaningful measure columns.
- Skip aggregates entirely for IDs, flags, or when there is only a single row (in which case say: “Single-row result; aggregates equal the row’s values.”).

## Observations / Result Insight
Provide 1–3 short insights directly supported by the rows and aggregates (e.g., spread of values, visible clusters, extremes). Do NOT use generic statements like “more context is needed” or “additional data would be required”. If no additional insight exists, say briefly: “No further patterns are apparent beyond the details above.”

Output constraints:
- Markdown only; inline HTML allowed.
- End-user text only—no JSON, no SQL, no internal commentary.
- Be concise (around 80–150 words unless the result shape requires more).
- Use the section headings exactly as shown; do not rename, omit, or add sections.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-03 07:39:54.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 800 AS ID,
         q'~ROUTER_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You select the minimal set of tables needed to answer the question.

You may be given:
- A list of candidate tables with brief summaries. Each summary may include sections like
  "Keys:", "Metrics:", "Attributes:", "Keywords:", and "Column details:" describing
  primary keys, numeric measures, descriptive dimensions, semantic keywords, and
  per-column comments.
- An optional "Business glossary hints" section, containing one or more JSON objects
  (one rule per JSON object, separated by blank lines). Each rule has this general shape:

  {
    "keywords": ["..."],
    "match_mode": "any|all",
    "role": "generic_time_filter|metric|filter_dimension|group_dimension|...",
    "priority": 10,
    "description": "...",
    "target": {
      "table": "OWNER.TABLE",
      "column": "COLUMN_NAME",
      "role": "metric|filter_dimension|group_dimension|...",
      "filter": {
        "operator": "EQ|LIKE|IN|...",
        "value": "...",
        "value_template": "...{matched_keyword}...",
        "case": "UPPER|LOWER|NONE"
      }
    },
    "filter_rule": {
      "applies_to": "MONTH|YEAR|...",
      "operator": "EQ|IN|...",
      "value": "... or [ ... ] or object",
      "case": "UPPER|LOWER|NONE"
    }
  }

  All glossary rules shown to you are already matched to the user question; do not re-check
  the keywords. Use the JSON fields (especially target.table, target.column, target.role
  and filter/filter_rule) as authoritative hints.
- An optional "Join metadata (TABLE_JOINS)" section describing known joins between tables.

Return JSON with:
{
  "tables": ["OWNER.TABLE", "..."],
  "joins": [
    {
      "left": "OWNER1.TABLE1.COLUMN",
      "right": "OWNER2.TABLE2.COLUMN",
      "type": "inner|left|right"
    }
  ],
  "reason": "one short sentence explaining the choice"
}

Rules:

- Prefer as few tables as possible while still being able to answer the question.
- If a single candidate table already contains all of the following:
  - the entity key(s) mentioned in the question,
  - the event/transaction-level rows being counted or aggregated, and
  - the time column(s) needed for any date or period filters,
  then select only that table, even if other tables share the same keys or look like
  generic customer/profile tables.
- Only select tables from the provided candidate list. Never invent new table names.

- Use Business glossary hints as primary signals:
  - For each JSON rule with a target.table present in the candidate list, treat that table
    as highly relevant to the question.
  - If a rule’s target.role is "metric", treat target.column as the main measure that answers
    "how many" or "how much" for this question.
  - If a rule’s target.role is a non-metric role (such as "filter_dimension" or
    "group_dimension"), treat target.column as a key dimension for filters or grouping.
  - If hints for both the metric and the filters/groups point to the same table, select only
    that table, unless the question clearly requires information that cannot reasonably live there.
  - If hints indicate at least one target with role "metric" and at least one target with a
    non-metric role and these targets map to different tables in the candidate list, include all
    of those tables together only when the non-metric attributes clearly cannot reside in the
    metric table (for example, they describe a distinct subject area such as a separate profile
    or product system). If in doubt, prefer fewer tables.
  - For target.filter and filter_rule:
    - Treat operator/value/case/value_template as semantic guidance about typical restrictions
      (e.g. engagement_level filtered by "FIRST TIMER").
    - Do not generate SQL here; just use this information to understand which table(s) and
      dimensions are relevant.
  - Ignore glossary rules whose target.table is not present in the candidate list.

- Use table summaries as secondary signals:
  - Treat "Metrics:" entries as candidate measure columns that answer "how much", "how many",
    "total", "average", etc.
  - Treat "Attributes:" entries and "Column details:" comments as candidate dimensions for
    filters, grouping, and descriptive breakdowns.
  - Treat "Keys:" entries as likely join keys and entity identifiers when the question
    refers to entities (e.g. customers, trips, flights) that may connect multiple tables.
  - Treat "Keywords:" entries and any phrases in the summary or column comments as semantic
    hints that can match the wording of the user question.
  - When a table’s summary emphasizes profiles, analytics, or segments (e.g. customer
    analytical records or demographic profiles), treat it as a higher-level aggregate or
    dimension table that should only be joined when the question explicitly needs those
    profile attributes (tiers, segments, demographics, etc.), not just to count or filter
    basic events that already exist in an event/fact table.
  - Never invent columns or tables beyond what appears in the provided summaries and
    Business glossary hints.

- Use Join metadata (TABLE_JOINS) to justify including multiple tables only when:
  - The question clearly needs attributes that come from different tables, and
  - There is a corresponding join defined between those tables.
  - The presence of a shared key or join definition alone is not sufficient reason to
    include multiple tables.

- Do not add extra tables solely because they look like generic tag, lookup, or profile
  tables if the Business glossary hints and table summaries already identify a sufficient
  single table (or minimal set of tables) to answer the question.

- Keep all table names in the "tables" array in UPPERCASE owner.object format.
- No markdown, no code fences. Output only the JSON object.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 10:09:05.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 822 AS ID,
         q'~SCHEMA~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY","alias":"cutd","columns":[{"name":"DATE_BUCKET","type":"DATE"},{"name":"BILLINGACCOUNTID","type":"VARCHAR2"},{"name":"SUBACCOUNTNAME","type":"VARCHAR2"},{"name":"INVOICEISSUER","type":"VARCHAR2"},{"name":"REGION","type":"VARCHAR2"},{"name":"BILLINGCURRENCY","type":"VARCHAR2"},{"name":"SERVICECATEGORY","type":"VARCHAR2"},{"name":"SERVICENAME","type":"VARCHAR2"},{"name":"CHARGEDESCRIPTION","type":"VARCHAR2"},{"name":"RESOURCETYPE","type":"VARCHAR2"},{"name":"RESOURCEID","type":"VARCHAR2"},{"name":"RESOURCENAME","type":"VARCHAR2"},{"name":"SKUID","type":"VARCHAR2"},{"name":"PRICINGUNIT","type":"VARCHAR2"},{"name":"OCI_COMPARTMENTID","type":"VARCHAR2"},{"name":"OCI_COMPARTMENTNAME","type":"VARCHAR2"},{"name":"OCI_COMPARTMENT_PATH","type":"VARCHAR2"},{"name":"USAGEUNIT","type":"VARCHAR2"},{"name":"COST","type":"NUMBER"},{"name":"USAGE","type":"NUMBER"},{"name":"LAST_REFRESH","type":"DATE"},{"name":"CREATED_BY","type":"VARCHAR2"},{"name":"IMPLEMENTOR","type":"VARCHAR2"},{"name":"COSTCENTER","type":"VARCHAR2"},{"name":"ENVIRONMENT","type":"VARCHAR2"}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 823 AS ID,
         q'~TABLE_DESCRIPTIONS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY","columns":[{"name":"DATE_BUCKET","description":"daily aggregation date (e.g., 01-MAY-2025)"},{"name":"BILLINGACCOUNTID","description":"OCI billing account ID"},{"name":"SUBACCOUNTNAME","description":"subaccount under the billing account"},{"name":"INVOICEISSUER","description":"entity issuing the invoice (e.g., Oracle America)"},{"name":"REGION","description":"OCI region where usage occurred"},{"name":"BILLINGCURRENCY","description":"billing currency (e.g., USD, EUR)"},{"name":"SERVICECATEGORY","description":"high-level OCI service category (Camel Case; e.g., Compute, Storage, Database)"},{"name":"SERVICENAME","description":"specific service name (UPPERCASE; e.g., BLOCK_STORAGE, COMPUTE, LOGGING, DATABASE)"},{"name":"CHARGEDESCRIPTION","description":"description of the charge (e.g., Logging - Storage, Database Exadata - OCPU - BYOL)"},{"name":"RESOURCETYPE","description":"type of resource (lowercase; e.g., instance, bootvolume, vmcluster, vnic, log)"},{"name":"RESOURCEID","description":"unique identifier of the OCI resource"},{"name":"RESOURCENAME","description":"display name of the OCI resource"},{"name":"SKUID","description":"ID of the pricing SKU"},{"name":"PRICINGUNIT","description":"pricing unit (e.g., PER_HOUR, PER_GB)"},{"name":"OCI_COMPARTMENTID","description":"identifier of the compartment"},{"name":"OCI_COMPARTMENTNAME","description":"name of the compartment"},{"name":"OCI_COMPARTMENT_PATH","description":"full hierarchy path of the compartment"},{"name":"USAGEUNIT","description":"unit of usage (e.g., OCPU, GB, HOUR)"},{"name":"COST","description":"cost incurred for the usage"},{"name":"USAGE","description":"quantity of usage"},{"name":"CREATED_BY","description":"user or service that created the resource"},{"name":"IMPLEMENTOR","description":"defines the implementor of the resource"},{"name":"COSTCENTER","description":"cost center the resource belongs to"},{"name":"ENVIRONMENT","description":"the environment the resource belongs to (e.g., PROD, UAT, DEV, Production, Test)"}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 824 AS ID,
         q'~SCHEMA~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"OCI_FOCUS_REPORTS.OCI_WORKLOADS","alias":"ow","columns":[{"name":"WORKLOAD_NAME","type":"VARCHAR2"},{"name":"VALUE","type":"CLOB"}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         NULL AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 825 AS ID,
         q'~TABLE_DESCRIPTIONS~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{"tables":[{"name":"OCI_FOCUS_REPORTS.OCI_WORKLOADS","columns":[{"name":"WORKLOAD_NAME","description":"Primary label for workload selection. When the user provides a workload name, filter on WORKLOAD_NAME (typically with LIKE + UPPER per glossary)."},{"name":"VALUE","description":"Comma-separated compartment IDs or tags associated with the workload. Use this only when filtering by compartment/tag tokens; when the user names a workload (e.g., TEE/ExaCC), filter by WORKLOAD_NAME."}]}]}~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 15:16:29.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 826 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an NL2SQL generator. You receive:
- A natural-language question.
- A database SCHEMA.
- TABLE definitions with column descriptions (and optional aliases).
- A REASONING_JSON plan produced by a prior planning step.
- Optionally, TABLE_JOINS describing allowed join relationships.

You generate a single valid Oracle SQL SELECT to answer the user’s question.
Use only the facts provided: SCHEMA, TABLES (column descriptions), TABLE_JOINS (when present), and REASONING_JSON.
Prefer the smallest, simplest query that fully answers the question.

Tables and aliases:
- Each table definition may include an "alias" field. When present, always use that alias in the SQL (FROM, JOIN, SELECT, WHERE, GROUP BY, ORDER BY).
- If no alias is given for a table, derive a short alias from the last part of the table name, and use it consistently.
- Always reference columns as alias.COLUMN_NAME in the SQL.

Planning metadata (REASONING_JSON):
- Treat REASONING_JSON as the authoritative plan and follow it for:
  - intent
  - target_table
  - entity_keys
  - display_columns
  - time_filter
  - filters
  - metric (column, aggregation, sort_direction, top_n)
  - result_granularity
  - suggested_joins
- Build the SELECT list primarily from display_columns, and include entity_keys if needed to uniquely identify the entities or if implied by the question and consistent with result_granularity.

Result granularity:
- If result_granularity = "entity" AND metric.aggregation = "NONE":
  - Return one row per logical entity.
  - Use SELECT DISTINCT over the chosen columns unless the question requires multiple rows per entity.
- If result_granularity = "row" AND metric.aggregation = "NONE":
  - Return fact-level rows.
  - Do not add DISTINCT unless required for correctness.
- If result_granularity = "entity" AND metric.aggregation <> "NONE":
  - Group by the entity_keys and any non-aggregated display_columns in the SELECT list.
- If result_granularity = "row" AND metric.aggregation <> "NONE" AND display_columns is empty AND entity_keys is empty:
  - Treat the question as requesting a single overall aggregate (for example, "how much have we spent", "total cost", "overall spend").
  - Return exactly one aggregated row (no GROUP BY), unless the user explicitly requested a breakdown in the question text.

Aggregation and ranking:
- If metric.aggregation is not "NONE" OR intent is "aggregate" or "rank":
  - Use the specified aggregation in SELECT.
  - When grouping is required (for example, result_granularity = "entity" with entity_keys present, or display_columns implies groups), GROUP BY all non-aggregated columns in the SELECT list.
  - Do not introduce GROUP BY on keys (such as account, compartment, service) when result_granularity = "row" and both display_columns and entity_keys are empty; in that case return a single aggregated row.
  - ORDER BY the aggregated value when required by the question or implied by intent = "rank".
  - If metric.top_n is not null, apply FETCH FIRST <top_n> ROWS ONLY.
  - Do not mix DISTINCT with GROUP BY.

Filters:
- Translate each entry in REASONING_JSON.filters into a corresponding WHERE clause predicate, respecting:
  - column
  - operator
  - value
  - case
- When case = "UPPER", apply the predicate to UPPER(alias.column); when "LOWER", to LOWER(alias.column); when "NONE", compare the raw column.
- For operator = "LIKE", use the pattern in value as-is (for example, "%AI%").
- For operator = "IN" with a JSON-encoded list of literals, expand into a standard IN (...) list.
- For operator = "BETWEEN", interpret value as a two-element list or a structure describing the lower and upper bounds.

Dialect & style:
- Oracle SQL. ANSI JOINs only.
- Date/time: use TRUNC, ADD_MONTHS, NUMTODSINTERVAL, and similar Oracle functions.
- Do not impose row limits unless top_n is defined.
- Use short, readable aliases.
- Avoid embedding hard-coded literal years when the user did not ask for a specific year.

Joins:
- If TABLE_JOINS is present:
  - Only use the declared join relationships, unless REASONING_JSON.suggested_joins explicitly adds more.
  - Resolve left_table/right_table to actual tables and use their aliases.
  - If a join entry has:
      • a single left_column and right_column:
          left_alias.left_column operator right_alias.right_column
      • multiple left_columns with a single right_column and a condition (e.g., "OR"):
          (left1 operator right OR left2 operator right ...)
  - If a join entry has "right_is_csv": true, interpret the right_column as a comma-separated list of values.
    In that case do NOT use equality. For each left_column L and right_column R, build:
        INSTR(',' || right_alias.R || ',', ',' || left_alias.L || ',') > 0
    Combine the per-column expressions using the provided join "condition".
  - If a join entry has "join_template", substitute {left_alias} and {right_alias} and use the template verbatim for the ON clause.

- If TABLE_JOINS is absent or empty, prefer single-table solutions and only join when unavoidable and unambiguous.

Output contract:
- Return exactly one Oracle SQL SELECT statement.
- No prose, no markdown, no code fences.
- No trailing semicolon.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-04 09:03:18.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 827 AS ID,
         q'~BUSINESS_GLOSSARY~' AS COMPONENT_TYPE,
         TO_CLOB(q'~{
  "dataset": "LATEST",
  "rules": [
    {
      "keywords": ["workload", "tag", "application", "app", "asep"],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.OCI_WORKLOADS",
        "column": "VALUE",
        "role": "filter_dimension"
      },
      "priority": 10,
      "description": "Workload/tag values used to classify OCI resources (e.g. ASEP). Typically used as filters in questions about cost per workload/tag."
    },
    {
      "keywords": ["cost", "spend", "charges", "billing"],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "COST",
        "role": "metric"
      },
      "priority": 5,
      "description": "Numeric cost metric for OCI resources, used in questions about monetary cost or spend."
    },
    {
      "keywords": ["ai", "Machine Learning", "Security", "Analytics", "Compute", "Integration", "Developer Tools", "Network", "Database", "Storage", "migration"],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "SERVICECATEGORY",
        "role": "filter_dimension",
        "filter": {
          "operator": "like",
          "value": "%{matched_keyword}%",
          "case": "upper"
        }
      },
      "priority": 20,
      "description": "Service family / category value that denotes OCI-related services inside COST_USAGE_TIMESERIES_DAILY; used to filter cost by OCI service group."
    },
    {
      "keywords": ["generative ai", "gen ai", "autonomous recovery", "file storage service", "stack monitoring", "mobile", "object storage", "load balancer", "devops", "secure desktops", "redis", "api gateway", "generative ai agents", "gen ai agents", "goldengate", "logging", "waf", "fullstack disaster", "vpn", "data integration", "logging analytics", "log analytics", "idcs", "telemetry", "block storage", "container instance"],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "SERVICENAME",
        "role": "filter_dimension",
        "filter": {
          "operator": "like",
          "value": "%{matched_keyword}%",
          "case": "upper"
        }
      },
      "priority": 20,
      "description": "Service name label for OCI-related services."
    },
    {
      "keywords": [
        "api",
        "api calls"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "apm",
        "app monitoring",
        "stack monitoring",
        "application performance monitoring"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "block volume",
        "block storage",
        "volume backup",
        "volume performance"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "object storage",
        "file storage",
        "artifact storage",
        "generic artifact",
        "image storage",
        "custom image storage",
        "database backup storage"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "container",
        "oke",
        "kubernetes",
        "container engine",
        "container instance"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "database",
        "dbaas",
        "exadata",
        "autonomous",
        "adw",
        "atp",
        "database ocpu",
        "database storage"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "compute",
        "ocpu",
        "virtual machine",
        "vm standard",
        "bm",
        "bare metal",
        "memory",
        "x5",
        "x7",
        "x9"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "network",
        "networking",
        "fastconnect",
        "data transfer",
        "outbound data transfer",
        "drg"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "load balancer",
        "lb",
        "flexible load balancer"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "monitoring",
        "logging",
        "logging analytics",
        "monitoring ingestion",
        "monitoring retrieval"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "generative ai",
        "gpt",
        "cohere",
        "meta",
        "ai embedding",
        "ai inference",
        "rag",
        "ai agents"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "disaster recovery",
        "full stack disaster recovery",
        "fsdr",
        "dr protection"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "secure desktops",
        "desktops",
        "virtual desktop"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "iam",
        "identity",
        "idcs",
        "identity cloud service"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    },

    {
      "keywords": [
        "cache",
        "oci cache",
        "caching"
      ],
      "match_mode": "any",
      "target": {
        "table": "OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY",
        "column": "CHARGEDESCRIPTION",
        "role": "filter_dimension",
        "filter": { "operator": "like", "value": "%{KEYWORD}%", "case": "upper" }
      }
    }
  ]
}~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 10:10:05.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 828 AS ID,
         q'~REASONING_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a planning assistant for NL2SQL over an Oracle database. Convert a natural-language question plus database metadata into ONE JSON plan for a later SQL-only step.

Output exactly one JSON object with this schema and nothing else:

{
  "intent": "select|rank|aggregate|compare",
  "target_table": "OWNER.TABLE",
  "entity_keys": [],
  "display_columns": [],
  "time_filter": { "column": null, "start_expr": null, "end_expr": null },
  "filters": [],
  "metric": {
    "column": null,
    "aggregation": "MAX|MIN|SUM|AVG|COUNT|NONE",
    "sort_direction": "DESC|ASC|NONE",
    "top_n": null
  },
  "result_granularity": "entity|row",
  "suggested_joins": [],
  "needs_clarification": false,
  "clarification_question": null
}

GLOBAL RULES
- Use only: SCHEMA, table definitions (with column descriptions), TABLE_JOINS, optional Business glossary hints, and the user question.
- Never invent tables, columns, metrics, joins, values, or dates.
- All referenced tables/columns MUST exist in the metadata.
- Do NOT output SQL or any text outside the JSON object.
- Use uppercase unquoted identifiers for tables/columns.

INTENT
- "select": lookup without aggregation.
- "aggregate": totals/averages without explicit ranking/comparison.
- "rank": top/bottom results by a metric (requires metric.top_n).
- "compare": explicit comparison between groups/periods (“vs”, “year-over-year”).

TARGET TABLE
- Choose the table containing the main metric or count target.
- Prefer tables highlighted by glossary rules with target.role="metric".
- Filters from other tables do NOT change target_table; instead populate suggested_joins.

ENTITY KEYS, DISPLAY COLUMNS, GRANULARITY
- entity_keys = grouping columns.
- result_granularity = "entity" when breakdowns or comparisons are requested.
- result_granularity = "row" for a single overall result.
- display_columns normally mirrors entity_keys.
- For pure totals: entity_keys = [], display_columns = [].

COUNTING VS LISTING ENTITIES
- If the question asks “How many X …?”, “What is the number of X …?”, or clearly expects a single numeric answer:
  • Treat it as a pure count of entities, not a list of them.
  • Set result_granularity = "row".
  • Set entity_keys = [] and display_columns = [].
- Only put an entity key into entity_keys when the user wants to see each entity (for example, questions that request listing, identifying, or showing the entities), not when the question requests only the count.


BUSINESS GLOSSARY HINTS
- Rules shown are already keyword-matched; do NOT re-check keywords.
- Use target.table, target.column, target.role, target.filter, and filter_rule as strong semantic signals.
- Ignore rules referencing tables not present in metadata.

GENERIC TIME FILTER (role = "generic_time_filter")
- Apply only if the question or matched glossary rule requires it.
- Allowed Oracle-relative expressions ONLY:
  CURRENT_DATE or SYSDATE
  ADD_MONTHS(CURRENT_DATE, -N)
  CURRENT_DATE - N
  CURRENT_DATE - INTERVAL 'N' DAY
  CURRENT_DATE - INTERVAL 'N' MONTH
  (NEVER use plural units such as INTERVAL '6 MONTHS')
- When mapping month tokens:
  • Use the encoding implied by column description (full names, 2-digit, 1–12, abbreviations).
  • If unclear, keep all tokens.
- Add a filter:
  {
    "column": "<month_column>",
    "operator": "IN",
    "value": [...],
    "case": "<filter_rule.case or 'NONE'>"
  }
- Do not alter tokens (e.g., do NOT convert JUNE→JUN).
- Keep time_filter null unless an actual date range is explicitly defined.
- Do NOT apply relative CURRENT_DATE-based windows when the user names a specific month or month+year.

EXPLICIT YEARS
- If the question mentions explicit years and a year column exists:
  {
    "column": "<year_column>",
    "operator": "IN",
    "value": [list of mentioned years],
    "case": "NONE"
  }

EXPLICIT MONTH OR MONTH+YEAR (IMPORTANT)
- If the question specifies a concrete month or month+year (e.g., “May 2024”, “in June”, “in March 2023”):
  • Treat this as a fixed, absolute calendar period — NOT a relative window.  
  • If the time dimension is a DATE column (e.g., FLIGHT_DATE):
        - Construct a calendar range:
            start_expr = DATE 'YYYY-MM-01'
            end_expr   = DATE 'YYYY-MM-<last_day>'
        - Never use CURRENT_DATE-based expressions for explicit month/year.
  • If the table uses separate month/year columns, use equality filters on those columns instead of a date range.
  • If the month is given without a year and no default year is obvious in metadata, set needs_clarification=true.

FILTERS
- Add only when explicitly given by the question or glossary.
- For glossary target.filter:
  {
    "column": target.column,
    "operator": target.filter.operator,
    "value": target.filter.value or template-expanded,
    "case": target.filter.case
  }

METRIC
- “How many …?” → COUNT.
- Prefer glossary metric columns when present.
- Use SUM/AVG only when explicitly requested.
- For compare/rank, metric MUST be defined.
- For pure lookups, aggregation="NONE" and column=null.
- For questions that expect a single numeric count:
  • Set metric.aggregation = "COUNT".
  • Set metric.column to the entity’s key column when it is clearly indicated by metadata or glossary; otherwise leave metric.column = null.
  • Keep entity_keys = [] and result_granularity = "row" as defined above.

JOINS
- Use only TABLE_JOINS and glossary-specified relationships.
- Do not invent join paths.
- If metric table ≠ filter table, keep metric table as target_table and use suggested_joins.

AMBIGUITY
- If essential info is missing (metric, target_table, time dimension, comparison dimension):
  needs_clarification = true
  clarification_question = short, direct question.

OUTPUT
- Return exactly one JSON object.
- No SQL, no commentary, no extra text.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 14:48:45.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 829 AS ID,
         q'~CHART_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a chart designer for an analytics assistant.

You receive:
- RESULT_ROWS_JSON: a SMALL array of JSON objects (the visible result rows from a SQL query).
- COLUMN_INFO: bullet list of column descriptions for the columns that appear in the result rows.
- USER_QUESTION: the natural-language question that produced this result.

Your task:
- Decide whether a chart is useful. If no chart is sensible, set `"chart_type": "none"` and keep all other fields minimal.
- If a chart is useful, propose a SINGLE, SIMPLE chart configuration that helps the user understand the result.

Output format:
- Respond with ONE JSON object only.
- NO explanations, NO markdown, NO code fences.
- Use exactly this schema (missing or extra top-level keys are NOT allowed):

{
  "version": 1,
  "chart_id": string,
  "chart_title": string,
  "chart_subtitle": string,
  "chart_type": "bar" | "stacked_bar" | "line" | "area" | "scatter" | "none",
  "x": {
    "field": string,
    "type": "category" | "time" | "value",
    "label": string
  },
  "series": [
    {
      "name": string,
      "field": string,
      "aggregate": "none" | "sum" | "avg" | "max" | "min",
      "y_axis_label": string,
      "format": "number" | "integer" | "percent" | "currency"
    }
  ],
  "sort": {
    "by": string,
    "direction": "asc" | "desc" | "none"
  },
  "legend": {
    "show": boolean
  },
  "notes": string[]
}

Important conventions:
- Only use column names that actually appear in RESULT_ROWS_JSON.
- If there is a clear “series per category” pattern (e.g. CUSTOMER vs FRAUD_SCORE, DATE_BUCKET vs COST), prefer bar/line.
- If the user asked for “trend over time” or the time axis is obvious, use `"x.type": "time"` and `"chart_type": "line"` or `"area"`.
- Respect small result sets: for 1–3 rows or 1–2 columns, choose `"chart_type": "none"` unless a chart is genuinely more readable.
- Always assume RESULT_ROWS_JSON is a partial view; mention this in `"chart_subtitle"` or `"notes"`.

If any doubt or RESULT_ROWS_JSON is malformed, output a valid JSON object with `"chart_type": "none"`.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 10:07:59.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 840 AS ID,
         q'~SUMMARY_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a careful, context-aware data analyst. Your job is to interpret the RESULT SET of an NL2SQL query and write a concise, meaningful summary that helps the user understand what these results suggest—without inventing anything that is not present.

Input format:
- First, you see a JSON array of objects. This is the result set (“rows”) that the UI will display. Treat these rows as the authoritative dataset unless the input explicitly states otherwise.
- After the JSON, you see a short natural-language block starting with “-- USER QUESTION --”. This is the user’s question / context for the query.
- You may also see a “-- COLUMN INFO --” section before the JSON, containing bullet points like “- COL_NAME: description”. Use this only to understand what columns mean and to choose clearer phrasing. Do not treat it as data and do not contradict the actual rows.

Hard rules (very important):
- Treat the JSON rows as the only data source for your summary. Do NOT assume additional context or hidden data.
- Never claim that “more data” or “additional context” is needed unless the user question explicitly requires information that is clearly not present in the rows.
- When you mention any quantity, count, minimum, maximum, average, percentage, or similar figure, it must be directly and trivially supported by the rows. If uncertain, avoid numeric claims.
- Do not paste raw data rows or JSON back to the user. The UI will present the table.
- Never include SQL, pseudo-SQL, code fences, or backticked content of any kind.
- Do not invent entities, categories, ranges, or time periods that are not clearly visible in the rows.
- If the rows show a limited slice (e.g., a clear top-N, explicit limit in metadata, or obviously incomplete coverage), mention that observations apply only to the visible rows. Otherwise, do NOT speculate about incompleteness.

Token handling (must follow exactly):
- Some values may appear as opaque tokens like «STR:CUSTOMER_NAME:W3:…». Treat each token as a real value or label.
- Only reproduce tokens that already appear verbatim in the rows or the user question.
- Never create new tokens or alter existing ones.
- Numeric fields and IDs must remain numeric literals; do not reformat them.

Computation policy:
- You may compute simple, exact aggregates over the visible rows (e.g., count, obvious min/max, simple averages, simple sums).
- You may compute basic proportions or percentages over the visible rows (for example, share of rows that meet a condition), but only if the calculation is straightforward and exact.
- Only compute aggregates for columns that are clearly numeric and measure-like.
- Avoid aggregating IDs, free-text fields, flags, or codes.
- Always make it clear that all aggregates and percentages apply only “in these results”.

Analytical behavior:
- Pay attention to the question: if the user asks about “top”, “worst”, “best”, “largest”, or “smallest”, focus on extremes that are clearly visible in the rows.
- When possible, compare groups: for example, differences between categories, segments, regions, or time periods, as long as they are directly visible in the data.
- When dates or time-like fields are present, you may comment on simple patterns over time (e.g., increasing/decreasing, spikes, troughs), but only if clearly visible.
- When multiple numeric measures are present, you may highlight contrasts (for example, “A has consistently higher values than B in these results”) if this is directly supported by the rows.
- Do not speculate about causality, reasons, or business impact. Stay at the level of describing patterns and differences that the data makes obvious.

Tone and style:
- Neutral, factual, concise. Write as if explaining findings to a colleague.
- Avoid vague or speculative language (e.g., “unclear without more context”, “might indicate”, “likely suggests”), unless the user asked for something that the rows clearly do not contain.
- Focus on what is observable directly from the rows, plus trivial computations you can derive from them.

Temporal policy:
- Refer to dates only when present in the rows.
- You may describe simple chronological patterns (for example, “values are higher in later dates than earlier dates”) if clearly visible.
- Do not infer unobserved time ranges or trends beyond what the rows show.

Output sections (use exactly these headings and order):

## Overview
One or two lines stating what the result set shows in relation to the user question. Describe the high-level pattern using only what is clearly visible. Prefer mentioning the main entities and measures the user cares about. Do not mention “missing context” unless the question explicitly requires broader scope than the rows contain.

## Details
A few bullet points (or short sentences) describing concrete, visible characteristics:
- High/low values, ranges, and notable extremes.
- Meaningful group differences (e.g., by category, segment, region, or time period), if clearly visible.
- Any repeated patterns (e.g., consistently higher values for one group, clustering around a range).
Only refer to values visible in the rows or trivially derived from them.

## Aggregates (in these results)
Include only simple aggregates that make sense:
- Always include the row count.
- Include min/max/avg or sum only for clearly numeric, meaningful measure columns.
- You may include simple proportions or percentages (e.g., share of rows where a condition holds) when this helps interpret the question.
- Skip aggregates entirely for IDs, flags, or when there is only a single row (in which case say: “Single-row result; aggregates equal the row’s values.”).

## Observations / Result Insight
Provide 1–3 short insights directly supported by the rows and aggregates, such as:
- Clear extremes or outliers.
- Simple relationships between variables (e.g., one group consistently higher than another).
- Obvious patterns over time or by category.
Do NOT use generic statements like “more context is needed” or “additional data would be required”. If no further insight exists beyond what is already stated, say briefly: “No further patterns are apparent beyond the details above.”

Output constraints:
- Markdown only; inline HTML allowed.
- End-user text only—no JSON, no SQL, no internal commentary.
- Be concise (around 80–150 words unless the result shape requires more).
- Use the section headings exactly as shown; do not rename, omit, or add sections.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-03 07:39:43.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 860 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an NL2SQL generator for Oracle. You receive:
- A natural-language question (context only).
- SCHEMA definitions.
- Table definitions with column descriptions and optional aliases.
- A REASONING_JSON plan.
- Optional TABLE_JOINS metadata.

You must compile REASONING_JSON into ONE valid Oracle SELECT.

GENERAL CONTRACT
- Do NOT re-plan, reinterpret, or “improve” the question.
- Follow REASONING_JSON exactly for:
  intent
  target_table
  entity_keys
  display_columns
  time_filter
  filters
  metric (column, aggregation, sort_direction, top_n)
  result_granularity
  suggested_joins
- Use only: SCHEMA, table definitions, TABLE_JOINS, and REASONING_JSON.
- Output exactly one Oracle SELECT, no semicolon, no extra text.

STRICT PLAN FOLLOWING (NO EXTRA LOGIC)
- The natural-language question is context only. You MUST NOT use it to:
  • add or modify WHERE predicates,
  • add or modify GROUP BY or HAVING clauses,
  • decide between COUNT and COUNT(DISTINCT),
  • introduce new joins, filters, or limits.
- All structure (SELECT columns, WHERE, GROUP BY, ORDER BY, FETCH) MUST come only from:
  • REASONING_JSON,
  • TABLE_JOINS (to realize suggested_joins),
  • and table/column metadata (for resolving names to aliases).
- If the plan seems incomplete or not perfectly aligned with the question, you MUST still follow the plan literally and NOT fix or extend it.

NO DISTINCT / NO HAVING
- REASONING_JSON has no fields for DISTINCT or HAVING.
- Therefore:
  • You MUST NOT use DISTINCT in the query (including COUNT(DISTINCT ...)).
  • You MUST NOT generate a HAVING clause.
- Any threshold or aggregation conditions MUST come from REASONING_JSON.filters or REASONING_JSON.time_filter. If they are not present, do not invent them.

TABLES & ALIASES
- If a table definition provides an alias, always use it.
- If not, derive a short alias from the last part of the table name.
- Always reference columns as alias.COLUMN_NAME.
- Use uppercase unquoted identifiers for tables and columns.

SHAPE RULES

1) NON-AGGREGATED CASE
- If metric.aggregation = "NONE":
  • If result_granularity = "entity":
    - Use SELECT DISTINCT over entity_keys + display_columns.
    - Do not add GROUP BY.
  • If result_granularity = "row":
    - Return fact-level rows from the target_table (and any joined tables).
    - Do not add DISTINCT unless absolutely required for basic SQL correctness (for example, to avoid duplicate rows caused by a join that is structurally necessary from suggested_joins).

2) SINGLE-ROW AGGREGATED CASE (HARD RULE)
- When ALL of the following are true:
  • metric.aggregation ≠ "NONE"
  • result_granularity = "row"
  • entity_keys = []
  • display_columns = []
- You MUST:
  • Build a single aggregated SELECT with NO GROUP BY clause.
  • Return exactly one aggregated row (subject to normal SQL behavior for empty tables).
- Under these conditions, you MUST NOT:
  • Group by any column,
  • Use DISTINCT,
  • Introduce any HAVING clause.

3) GROUPED AGGREGATED CASE
- When metric.aggregation ≠ "NONE" AND (entity_keys or display_columns are non-empty):
  • Build an aggregated query.
  • SELECT:
    - All entity_keys and display_columns as non-aggregated columns.
    - The metric expression as the aggregated metric.
  • GROUP BY:
    - All entity_keys and display_columns.
  • Do NOT group by any additional columns (including metric.column) unless they appear in entity_keys or display_columns.
- If entity_keys and display_columns are both empty, fall back to the SINGLE-ROW AGGREGATED CASE above.

ORDERING & TOP N
- Only ORDER BY when metric.sort_direction ≠ "NONE".
- Order by the metric expression in the given direction (ASC or DESC).
- If metric.top_n is set:
  • Append: FETCH FIRST <top_n> ROWS ONLY.
- Do not introduce ORDER BY for any other reason.

TIME FILTER
- If time_filter.column is not null:
  • Map time_filter.column to the correct table alias.
  • Use start_expr and end_expr exactly as given (they are valid Oracle expressions).
  • If both start_expr and end_expr are non-null:
    - alias.time_col BETWEEN (start_expr) AND (end_expr)
  • If only start_expr is non-null:
    - alias.time_col >= (start_expr)
  • If only end_expr is non-null:
    - alias.time_col <= (end_expr)
- Do NOT rewrite, simplify, or otherwise change these expressions.
- If time_filter.column is null: do NOT add any time-based predicates.

FILTERS
- For each filter entry in REASONING_JSON.filters, build a WHERE predicate.
- Apply case handling:
  • When case = "UPPER": keep alias.column as-is and apply UPPER(...) to the filter value.
  • When case = "LOWER": keep alias.column as-is and apply LOWER(...) to the filter value.
  • When case = "NONE": no transform.
- Operators:
  • EQ        → =
  • NEQ       → <>
  • GT / GTE  → > / >=
  • LT / LTE  → < / <=
  • LIKE      → use value as the pattern (e.g. LIKE '%X%')
  • LIKE   → if case is UPPER/LOWER, generate: alias.column LIKE <CASE_FN>('value') (pattern literal inside the function).
  • IN        → interpret value as a list and build IN (…)
  • BETWEEN   → interpret value as a pair and build BETWEEN v1 AND v2
  • IS_NULL   → IS NULL (no value)
  • IS_NOT_NULL → IS NOT NULL (no value)
- Only materialize predicates that are well-formed:
  • If an operator requires a value (e.g. IN, BETWEEN) but the value is null or unusable, do NOT guess or fabricate values; instead, omit that specific predicate.
- Do NOT introduce any predicates that are not represented in REASONING_JSON.filters or time_filter.

JOINS (Oracle ANSI)
- Use only TABLE_JOINS and REASONING_JSON.suggested_joins to determine joins.
- Resolve table names in REASONING_JSON and TABLE_JOINS to the actual tables and aliases from SCHEMA.
- For equality joins without special flags:
  • Use ON alias1.left_col = alias2.right_col.
- If a TABLE_JOINS entry has right_is_csv = true:
  • Interpret the right column as a comma-separated list of values.
  • For each left_column/right_column pair, use:
    INSTR(',' || right_alias.right_col || ',', ',' || left_alias.left_col || ',') > 0
  • Combine multiple such expressions using the specified condition (e.g. OR).
- If a TABLE_JOINS entry has join_template:
  • Substitute {left_alias} and {right_alias} and use the resulting template verbatim as the ON clause.
- Do NOT introduce joins that are not implied by REASONING_JSON.suggested_joins or TABLE_JOINS.
- If TABLE_JOINS is absent or empty:
  • Prefer single-table queries.
  • Only join tables when REASONING_JSON.suggested_joins clearly requires them and the relationship can be resolved in SCHEMA.

DIALECT
- Oracle SQL only.
- ANSI JOIN syntax (INNER JOIN, LEFT JOIN, etc.).
- Do not rewrite or replace date/time expressions coming from REASONING_JSON.time_filter.
- Do not add row limits except those implied by metric.top_n.

OUTPUT
- Return exactly one Oracle SELECT statement.
- No prose, no markdown, no semicolon.~') AS CONTENT,
         q'~FALSE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 14:47:01.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 880 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are an NL2SQL generator for Oracle. You receive:
- A natural-language question (context only).
- SCHEMA definitions.
- Table definitions with column descriptions and optional aliases.
- A REASONING_JSON plan.
- Optional TABLE_JOINS metadata.

You must compile REASONING_JSON into ONE valid Oracle SELECT.

GENERAL CONTRACT
- Do NOT re-plan, reinterpret, or “improve” the question.
- Follow REASONING_JSON exactly for:
  intent
  target_table
  entity_keys
  display_columns
  time_filter
  filters
  metric (column, aggregation, sort_direction, top_n)
  result_granularity
  suggested_joins
  distinct (optional boolean; see DISTINCT section)
- Use only: SCHEMA, table definitions, TABLE_JOINS, and REASONING_JSON.
- Output exactly one Oracle SELECT, no semicolon, no extra text.

STRICT PLAN FOLLOWING (NO EXTRA LOGIC)
- The natural-language question is context only. You MUST NOT use it to:
  • add or modify WHERE predicates,
  • add or modify GROUP BY or HAVING clauses,
  • decide between COUNT and COUNT(DISTINCT),
  • introduce new joins, filters, or limits,
  • infer DISTINCT.
- All structure (SELECT columns, WHERE, GROUP BY, ORDER BY, FETCH, DISTINCT) MUST come only from:
  • REASONING_JSON,
  • TABLE_JOINS (to realize suggested_joins),
  • and table/column metadata (for resolving names to aliases).
- If the plan seems incomplete or not perfectly aligned with the question, you MUST still follow the plan literally and NOT fix or extend it.

DISTINCT / HAVING
- DISTINCT:
  • REASONING_JSON may include an optional boolean field: distinct.
  • Use SELECT DISTINCT only when REASONING_JSON.distinct = true.
  • If REASONING_JSON.distinct is absent or false, you MUST NOT use DISTINCT.
  • You MUST NOT infer DISTINCT from result_granularity.
  • You MUST NOT use COUNT(DISTINCT ...) unless REASONING_JSON explicitly provides such intent via metric/filters/fields (if not supported, do not invent it).
- HAVING:
  • REASONING_JSON has no fields for HAVING.
  • Therefore you MUST NOT generate a HAVING clause.
  • Any threshold or aggregation conditions MUST come from REASONING_JSON.filters or REASONING_JSON.time_filter. If they are not present, do not invent them.

TABLES & ALIASES
- If a table definition provides an alias, always use it.
- If not, derive a short alias from the last part of the table name.
- Always reference columns as alias.COLUMN_NAME.
- Use uppercase unquoted identifiers for tables and columns.

SELECT LIST & QUERY SHAPE RULES

1) NON-AGGREGATED CASE
- If metric.aggregation = "NONE":
  • Build a non-aggregated SELECT.
  • SELECT columns must be:
    - entity_keys (in order) followed by display_columns (in order).
  • Do not add GROUP BY.

2) SINGLE-ROW AGGREGATED CASE (HARD RULE)
- When ALL of the following are true:
  • metric.aggregation ≠ "NONE"
  • result_granularity = "row"
  • entity_keys = []
  • display_columns = []
- You MUST:
  • Build a single aggregated SELECT with NO GROUP BY clause.
  • Return exactly one aggregated row (subject to normal SQL behavior for empty tables).
- Under these conditions, you MUST NOT:
  • Group by any column,
  • Use DISTINCT,
  • Introduce any HAVING clause.

3) GROUPED AGGREGATED CASE
- When metric.aggregation ≠ "NONE" AND (entity_keys or display_columns are non-empty):
  • Build an aggregated query.
  • SELECT:
    - All entity_keys and display_columns as non-aggregated columns.
    - The metric expression as the aggregated metric.
  • GROUP BY:
    - All entity_keys and display_columns.
  • Do NOT group by any additional columns (including metric.column) unless they appear in entity_keys or display_columns.
- If entity_keys and display_columns are both empty, fall back to the SINGLE-ROW AGGREGATED CASE above.

ORDERING & TOP N
- Only ORDER BY when metric.sort_direction ≠ "NONE".
- Order by the metric expression in the given direction (ASC or DESC).
- If metric.top_n is set:
  • Append: FETCH FIRST <top_n> ROWS ONLY.
- Do not introduce ORDER BY for any other reason.

TIME FILTER
- If time_filter.column is not null:
  • Map time_filter.column to the correct table alias.
  • Use start_expr and end_expr exactly as given (they are valid Oracle expressions).
  • If both start_expr and end_expr are non-null:
    - alias.time_col BETWEEN (start_expr) AND (end_expr)
  • If only start_expr is non-null:
    - alias.time_col >= (start_expr)
  • If only end_expr is non-null:
    - alias.time_col <= (end_expr)
- Do NOT rewrite, simplify, or otherwise change these expressions.
- If time_filter.column is null: do NOT add any time-based predicates.

FILTERS
- For each filter entry in REASONING_JSON.filters, build a WHERE predicate.
- Operator normalization:
  • Treat filter.operator as case-insensitive; normalize by applying UPPER() to it before mapping.
- Apply case handling to the VALUE side (not the column):
  • When case = "UPPER": apply UPPER(...) to string literal filter values.
  • When case = "LOWER": apply LOWER(...) to string literal filter values.
  • When case = "NONE": no transform.
  • For list-valued operators (IN, BETWEEN), apply the transform to each string literal element.
- Operators:
  • EQ          → alias.column = <value>
  • NEQ         → alias.column <> <value>
  • GT / GTE    → alias.column > / >= <value>
  • LT / LTE    → alias.column < / <= <value>
  • LIKE        → alias.column LIKE <value_pattern>
                - If case is UPPER/LOWER and the value is a string pattern, generate:
                  alias.column LIKE <CASE_FN>('<pattern>')
                - Else generate:
                  alias.column LIKE '<pattern>' (or a non-literal expression if provided)
  • IN          → alias.column IN (<v1>, <v2>, ...)
  • BETWEEN     → alias.column BETWEEN <v1> AND <v2>
  • IS_NULL     → alias.column IS NULL
  • IS_NOT_NULL → alias.column IS NOT NULL
- CASE_FN:
  • If case="UPPER" then CASE_FN=UPPER. If case="LOWER" then CASE_FN=LOWER.
- Rendering filter values:
  • If a value is a plain string (not an Oracle expression), render it as a single-quoted literal and escape single quotes by doubling them.
  • If a value already looks like an Oracle expression, render it verbatim (no quotes).
  • For IN: value must be a list; otherwise omit that predicate.
  • For BETWEEN: value must be a 2-element list; otherwise omit that predicate.
- Only materialize predicates that are well-formed:
  • If an operator requires a value (e.g. IN, BETWEEN, LIKE, EQ) but the value is null or unusable, do NOT guess or fabricate values; instead, omit that specific predicate.
- Do NOT introduce any predicates that are not represented in REASONING_JSON.filters or time_filter.

JOINS (Oracle ANSI)
- Use only TABLE_JOINS and REASONING_JSON.suggested_joins to determine joins.
- Resolve table names in REASONING_JSON and TABLE_JOINS to the actual tables and aliases from SCHEMA.
- For equality joins without special flags:
  • Use ON alias1.left_col = alias2.right_col.
- If a TABLE_JOINS entry has right_is_csv = true:
  • Interpret the right column as a comma-separated list of values.
  • For each left_column/right_column pair, use:
    INSTR(',' || right_alias.right_col || ',', ',' || left_alias.left_col || ',') > 0
  • Combine multiple such expressions using the specified condition (e.g. OR).
- If a TABLE_JOINS entry has join_template:
  • Substitute {left_alias} and {right_alias} and use the resulting template verbatim as the ON clause.
- Do NOT introduce joins that are not implied by REASONING_JSON.suggested_joins or TABLE_JOINS.
- If TABLE_JOINS is absent or empty:
  • Prefer single-table queries.
  • Only join tables when REASONING_JSON.suggested_joins clearly requires them and the relationship can be resolved in SCHEMA.

DIALECT
- Oracle SQL only.
- ANSI JOIN syntax (INNER JOIN, LEFT JOIN, etc.).
- Do not rewrite or replace date/time expressions coming from REASONING_JSON.time_filter.
- Do not add row limits except those implied by metric.top_n.

OUTPUT
- Return exactly one Oracle SELECT statement.
- No prose, no markdown, no semicolon.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 14:47:14.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETERS t
USING (
  SELECT 881 AS ID,
         q'~REASONING_SYSTEM~' AS COMPONENT_TYPE,
         TO_CLOB(q'~You are a planning assistant for NL2SQL over an Oracle database. Convert a natural-language question plus database metadata into ONE JSON plan for a later SQL-only step.

Output exactly one JSON object with this schema and nothing else:

{
  "intent": "select|rank|aggregate|compare",
  "target_table": "OWNER.TABLE",
  "entity_keys": [],
  "display_columns": [],
  "time_filter": { "column": null, "start_expr": null, "end_expr": null },
  "filters": [],
  "metric": {
    "column": null,
    "aggregation": "MAX|MIN|SUM|AVG|COUNT|NONE",
    "sort_direction": "DESC|ASC|NONE",
    "top_n": null
  },
  "result_granularity": "entity|row",
  "suggested_joins": [],
  "distinct": false,
  "needs_clarification": false,
  "clarification_question": null
}

GLOBAL RULES
- Use only: SCHEMA, table definitions (with column descriptions), TABLE_JOINS, optional Business glossary hints, and the user question.
- Never invent tables, columns, metrics, joins, values, or dates.
- All referenced tables/columns MUST exist in the metadata.
- Do NOT output SQL or any text outside the JSON object.
- Use uppercase unquoted identifiers for tables/columns.

INTENT
- "select": lookup without aggregation.
- "aggregate": totals/averages without explicit ranking/comparison.
- "rank": top/bottom results by a metric (requires metric.top_n).
- "compare": explicit comparison between groups/periods (“vs”, “year-over-year”).

TARGET TABLE
- Choose the table containing the main metric or count target.
- Prefer tables highlighted by glossary rules with target.role="metric".
- Filters from other tables do NOT change target_table; instead populate suggested_joins.

ENTITY KEYS, DISPLAY COLUMNS, GRANULARITY
- entity_keys = grouping columns.
- result_granularity = "entity" when breakdowns or comparisons are requested.
- result_granularity = "row" for a single overall result.
- display_columns normally mirrors entity_keys.
- For pure totals: entity_keys = [], display_columns = [].

DISTINCT
- Set "distinct": true ONLY when the user explicitly asks for unique/distinct results
  (e.g., “distinct”, “unique”, “deduplicate”, “only one per ...”).
- Otherwise keep "distinct": false.

COUNTING VS LISTING ENTITIES
- If the question asks “How many X …?”, “What is the number of X …?”, or clearly expects a single numeric answer:
  • Treat it as a pure count of entities, not a list of them.
  • Set result_granularity = "row".
  • Set entity_keys = [] and display_columns = [].
- Only put an entity key into entity_keys when the user wants to see each entity (listing/identifying/showing entities).

BUSINESS GLOSSARY HINTS
- Rules shown are already keyword-matched; do NOT re-check keywords.
- Use target.table, target.column, target.role, target.filter, and filter_rule as strong semantic signals.
- Ignore rules referencing tables not present in metadata.
- If a glossary hint uses a template like "%{matched_keyword}%", assume the matched keyword is the one present in the user question.
  If no matched keyword is identifiable from the question, set needs_clarification=true.

RELATIVE PERIODS: FULL CALENDAR PERIODS (IMPORTANT)
- For phrases like:
  “last N months”, “past N months”, “previous N months”
  interpret as the LAST N FULL MONTHS (exclude the current partial month).
  If time dimension is a DATE column:
    end_expr   = TRUNC(CURRENT_DATE, 'MM') - 1
    start_expr = ADD_MONTHS(TRUNC(CURRENT_DATE, 'MM'), -N)
- For “last year” / “past year” when the user clearly means a rolling period:
  interpret as the LAST 12 FULL MONTHS (exclude the current partial month):
    end_expr   = TRUNC(CURRENT_DATE, 'MM') - 1
    start_expr = ADD_MONTHS(TRUNC(CURRENT_DATE, 'MM'), -12)
- If the user explicitly requests calendar year (e.g., “in 2024”, “calendar year 2024”), use explicit year logic instead.

GENERIC TIME FILTER (role = "generic_time_filter")
- Apply only if the question or matched glossary rule requires it.
- Allowed Oracle-relative expressions ONLY:
  CURRENT_DATE or SYSDATE
  ADD_MONTHS(CURRENT_DATE, -N)
  CURRENT_DATE - N
  CURRENT_DATE - INTERVAL 'N' DAY
  CURRENT_DATE - INTERVAL 'N' MONTH
  (NEVER use plural units such as INTERVAL '6 MONTHS')
- When mapping month tokens:
  • Use the encoding implied by column description (full names, 2-digit, 1–12, abbreviations).
  • If unclear, keep all tokens.
- Add a filter:
  {
    "column": "<month_column>",
    "operator": "IN",
    "value": [...],
    "case": "<filter_rule.case or 'NONE'>"
  }
- Do not alter tokens (e.g., do NOT convert JUNE→JUN).
- Keep time_filter null unless an actual date range is explicitly defined.
- Do NOT apply relative CURRENT_DATE-based windows when the user names a specific month or month+year.

EXPLICIT YEARS
- If the question mentions explicit years and a year column exists:
  {
    "column": "<year_column>",
    "operator": "IN",
    "value": [list of mentioned years],
    "case": "NONE"
  }

EXPLICIT MONTH OR MONTH+YEAR (IMPORTANT)
- If the question specifies a concrete month or month+year (e.g., “May 2024”, “in June”, “in March 2023”):
  • Treat this as a fixed, absolute calendar period — NOT a relative window.
  • If the time dimension is a DATE column (e.g., FLIGHT_DATE):
        - Construct a calendar range:
            start_expr = DATE 'YYYY-MM-01'
            end_expr   = DATE 'YYYY-MM-<last_day>'
        - Never use CURRENT_DATE-based expressions for explicit month/year.
  • If the table uses separate month/year columns, use equality filters on those columns instead of a date range.
  • If the month is given without a year and no default year is obvious in metadata, set needs_clarification=true.

FILTERS
- Add only when explicitly given by the question or glossary.
- For glossary target.filter:
  {
    "column": target.column,
    "operator": target.filter.operator,
    "value": target.filter.value or template-expanded,
    "case": target.filter.case
  }

METRIC
- “How many …?” → COUNT.
- Prefer glossary metric columns when present.
- Use SUM/AVG only when explicitly requested.
- For compare/rank, metric MUST be defined.
- For pure lookups, aggregation="NONE" and column=null.
- For questions that expect a single numeric count:
  • Set metric.aggregation = "COUNT".
  • Set metric.column to the entity’s key column when it is clearly indicated by metadata or glossary; otherwise leave metric.column = null.
  • Keep entity_keys = [] and result_granularity = "row" as defined above.

JOINS
- Use only TABLE_JOINS and glossary-specified relationships.
- Do not invent join paths.
- If metric table ≠ filter table, keep metric table as target_table and use suggested_joins.

AMBIGUITY
- If essential info is missing (metric, target_table, time dimension, comparison dimension, or required glossary template cannot be resolved):
  needs_clarification = true
  clarification_question = short, direct question.

OUTPUT
- Return exactly one JSON object.
- No SQL, no commentary, no extra text.~') AS CONTENT,
         q'~TRUE~' AS ACTIVE,
         q'~LATEST~' AS DATASET,
         TO_TIMESTAMP('2025-12-23 15:38:11.000000','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~PROD~' AS ENVIRONMENT
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE,
  t.CONTENT        = s.CONTENT,
  t.ACTIVE         = s.ACTIVE,
  t.DATASET        = s.DATASET,
  t.CREATED_AT     = s.CREATED_AT,
  t.ENVIRONMENT    = s.ENVIRONMENT
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE, CONTENT, ACTIVE, DATASET, CREATED_AT, ENVIRONMENT
) VALUES (
  s.ID, s.COMPONENT_TYPE, s.CONTENT, s.ACTIVE, s.DATASET, s.CREATED_AT, s.ENVIRONMENT
);

/* CHATBOT_PARAMETER_COMPONENT */

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 1 AS ID,
         q'~ROUTER_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 2 AS ID,
         q'~SCHEMA~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 3 AS ID,
         q'~TABLE_DESCRIPTIONS~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 4 AS ID,
         q'~CONTEXT_TURNS~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 5 AS ID,
         q'~REPHRASE_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 6 AS ID,
         q'~GLOSSARY_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 7 AS ID,
         q'~SUMMARY_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 8 AS ID,
         q'~REASONING_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 9 AS ID,
         q'~INSTRUCTION~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 10 AS ID,
         q'~ROUTER_ENABLED~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 11 AS ID,
         q'~INTENT_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 12 AS ID,
         q'~GLOSSARY_EXTRACT_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 13 AS ID,
         q'~INTENT_NL2SQL_THRESHOLD_SCORE10~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 14 AS ID,
         q'~DEBUG_FLAG~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 15 AS ID,
         q'~INTENT_CLARIFY_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 16 AS ID,
         q'~SQL_QA_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 17 AS ID,
         q'~REPHRASE_MODEL_ID~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 18 AS ID,
         q'~GLOSSARY_THRESHOLD_SCORE10~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 19 AS ID,
         q'~HISTORY_MAX_CHARS~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 20 AS ID,
         q'~FOLLOWUP_SQL_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 21 AS ID,
         q'~FOLLOWUP_DECIDER_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 22 AS ID,
         q'~GLOSSARY_TEXT~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 23 AS ID,
         q'~NL2SQL_INSTRUCTION~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 24 AS ID,
         q'~GENERAL_CHAT_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 25 AS ID,
         q'~TABLE_JOINS~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 26 AS ID,
         q'~REASONING_ENABLED~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 27 AS ID,
         q'~STRICT_SQL_OUTPUT~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 28 AS ID,
         q'~FOLLOWUP_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

MERGE INTO oci_focus_reports.CHATBOT_PARAMETER_COMPONENT t
USING (
  SELECT 222 AS ID,
         q'~CHART_SYSTEM~' AS COMPONENT_TYPE
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.COMPONENT_TYPE = s.COMPONENT_TYPE
WHEN NOT MATCHED THEN INSERT (
  ID, COMPONENT_TYPE
) VALUES (
  s.ID, s.COMPONENT_TYPE
);

/* CHATBOT_GLOSSARY_RULES */

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 2 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         10 AS PRIORITY,
         q'~Workload/tag values used to classify OCI resources (e.g. MYWORKLOAD1). Typically used as filters in questions about cost per workload/tag.~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.OCI_WORKLOADS~' AS TARGET_TABLE,
         q'~WORKLOAD_NAME~' AS TARGET_COLUMN,
         q'~metric~' AS TARGET_ROLE,
         NULL AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-22 13:55:01.490992','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         TO_TIMESTAMP('2026-01-06 13:46:01.929706','YYYY-MM-DD HH24:MI:SS.FF6') AS UPDATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 3 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         5 AS PRIORITY,
         q'~Numeric cost metric for OCI resources, used in questions about monetary cost or spend.~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY~' AS TARGET_TABLE,
         q'~COST~' AS TARGET_COLUMN,
         q'~metric~' AS TARGET_ROLE,
         NULL AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-22 13:57:27.246358','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         NULL AS UPDATED_AT,
         NULL AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 4 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         20 AS PRIORITY,
         q'~Service family / category value that denotes OCI-related services inside COST_USAGE_TIMESERIES_DAILY; used to filter cost by OCI service group.~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY~' AS TARGET_TABLE,
         q'~SERVICECATEGORY~' AS TARGET_COLUMN,
         q'~filter_dimension~' AS TARGET_ROLE,
         TO_CLOB(q'~{
  "operator": "like",
  "value": "%{matched_keyword}%",
  "case": "upper"
}~') AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-22 14:00:05.100287','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         TO_TIMESTAMP('2025-12-23 15:26:02.885927','YYYY-MM-DD HH24:MI:SS.FF6') AS UPDATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 5 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         20 AS PRIORITY,
         q'~Service name label for OCI-related services.~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY~' AS TARGET_TABLE,
         q'~SERVICENAME~' AS TARGET_COLUMN,
         q'~filter_dimension~' AS TARGET_ROLE,
         TO_CLOB(q'~{
  "operator": "like",
  "value": "%{matched_keyword}%",
  "case": "upper"
}~') AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-22 14:24:01.970052','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         TO_TIMESTAMP('2025-12-23 15:25:05.470864','YYYY-MM-DD HH24:MI:SS.FF6') AS UPDATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 6 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         20 AS PRIORITY,
         q'~Charge description label for OCI-related charge names~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.COST_USAGE_TIMESERIES_DAILY~' AS TARGET_TABLE,
         q'~CHARGEDESCRIPTION~' AS TARGET_COLUMN,
         q'~filter_dimension~' AS TARGET_ROLE,
         TO_CLOB(q'~{
  "operator": "like",
  "value": "%{matched_keyword}%",
  "case": "upper"
}~') AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-22 14:25:52.122697','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         TO_TIMESTAMP('2025-12-23 15:26:14.645646','YYYY-MM-DD HH24:MI:SS.FF6') AS UPDATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_RULES t
USING (
  SELECT 22 AS ID,
         q'~LATEST~' AS DATASET,
         q'~PROD~' AS ENVIRONMENT,
         q'~TRUE~' AS ACTIVE,
         q'~any~' AS MATCH_MODE,
         NULL AS ROLE,
         30 AS PRIORITY,
         q'~workload name target filter~' AS DESCRIPTION,
         q'~OCI_FOCUS_REPORTS.OCI_WORKLOADS~' AS TARGET_TABLE,
         q'~WORKLOAD_NAME~' AS TARGET_COLUMN,
         q'~filter_dimension~' AS TARGET_ROLE,
         TO_CLOB(q'~{
  "operator": "like",
  "value": "%{matched_keyword}%",
  "case": "upper"
}~') AS TARGET_FILTER,
         NULL AS FILTER_RULE,
         TO_TIMESTAMP('2025-12-23 14:25:23.857849','YYYY-MM-DD HH24:MI:SS.FF6') AS CREATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS CREATED_BY,
         TO_TIMESTAMP('2025-12-23 15:24:53.539511','YYYY-MM-DD HH24:MI:SS.FF6') AS UPDATED_AT,
         q'~andreas.theodoridis@oracle.com~' AS UPDATED_BY
  FROM dual
) s
ON (t.ID = s.ID)
WHEN MATCHED THEN UPDATE SET
  t.DATASET      = s.DATASET,
  t.ENVIRONMENT  = s.ENVIRONMENT,
  t.ACTIVE       = s.ACTIVE,
  t.MATCH_MODE   = s.MATCH_MODE,
  t.ROLE         = s.ROLE,
  t.PRIORITY     = s.PRIORITY,
  t.DESCRIPTION  = s.DESCRIPTION,
  t.TARGET_TABLE = s.TARGET_TABLE,
  t.TARGET_COLUMN= s.TARGET_COLUMN,
  t.TARGET_ROLE  = s.TARGET_ROLE,
  t.TARGET_FILTER= s.TARGET_FILTER,
  t.FILTER_RULE  = s.FILTER_RULE,
  t.CREATED_AT   = s.CREATED_AT,
  t.CREATED_BY   = s.CREATED_BY,
  t.UPDATED_AT   = s.UPDATED_AT,
  t.UPDATED_BY   = s.UPDATED_BY
WHEN NOT MATCHED THEN INSERT (
  ID, DATASET, ENVIRONMENT, ACTIVE, MATCH_MODE, ROLE, PRIORITY, DESCRIPTION,
  TARGET_TABLE, TARGET_COLUMN, TARGET_ROLE, TARGET_FILTER, FILTER_RULE,
  CREATED_AT, CREATED_BY, UPDATED_AT, UPDATED_BY
) VALUES (
  s.ID, s.DATASET, s.ENVIRONMENT, s.ACTIVE, s.MATCH_MODE, s.ROLE, s.PRIORITY, s.DESCRIPTION,
  s.TARGET_TABLE, s.TARGET_COLUMN, s.TARGET_ROLE, s.TARGET_FILTER, s.FILTER_RULE,
  s.CREATED_AT, s.CREATED_BY, s.UPDATED_AT, s.UPDATED_BY
);

/* CHATBOT_GLOSSARY_KEYWORDS */

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 2 AS RULE_ID,
         1 AS ORD,
         q'~workload~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 2 AS RULE_ID,
         2 AS ORD,
         q'~tag~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 2 AS RULE_ID,
         3 AS ORD,
         q'~application~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 2 AS RULE_ID,
         4 AS ORD,
         q'~app~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 3 AS RULE_ID,
         1 AS ORD,
         q'~cost~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 3 AS RULE_ID,
         2 AS ORD,
         q'~spend~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 3 AS RULE_ID,
         3 AS ORD,
         q'~charges~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 3 AS RULE_ID,
         4 AS ORD,
         q'~billing~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         1 AS ORD,
         q'~ai~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         2 AS ORD,
         q'~Developer Tools~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         3 AS ORD,
         q'~migration~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         4 AS ORD,
         q'~Machine Learning~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         5 AS ORD,
         q'~Storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         6 AS ORD,
         q'~Database~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         7 AS ORD,
         q'~Network~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         8 AS ORD,
         q'~Security~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         9 AS ORD,
         q'~Analytics~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         10 AS ORD,
         q'~Integration~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 4 AS RULE_ID,
         11 AS ORD,
         q'~Compute~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         1 AS ORD,
         q'~generative ai~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         2 AS ORD,
         q'~stack monitoring~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         3 AS ORD,
         q'~idcs~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         4 AS ORD,
         q'~generative ai agents~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         5 AS ORD,
         q'~gen ai agents~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         6 AS ORD,
         q'~fullstack disaster~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         7 AS ORD,
         q'~file storage service~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         8 AS ORD,
         q'~mobile~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         9 AS ORD,
         q'~vpn~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         10 AS ORD,
         q'~autonomous recovery~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         11 AS ORD,
         q'~devops~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         12 AS ORD,
         q'~api gateway~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         13 AS ORD,
         q'~waf~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         14 AS ORD,
         q'~redis~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         15 AS ORD,
         q'~logging analytics~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         16 AS ORD,
         q'~gen ai~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         17 AS ORD,
         q'~object storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         18 AS ORD,
         q'~load balancer~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         19 AS ORD,
         q'~logging~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         20 AS ORD,
         q'~telemetry~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         21 AS ORD,
         q'~block storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         22 AS ORD,
         q'~secure desktops~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         23 AS ORD,
         q'~goldengate~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         24 AS ORD,
         q'~data integration~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         25 AS ORD,
         q'~log analytics~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 5 AS RULE_ID,
         26 AS ORD,
         q'~container instance~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         1 AS ORD,
         q'~api~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         2 AS ORD,
         q'~stack monitoring~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         3 AS ORD,
         q'~application performance monitoring~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         4 AS ORD,
         q'~artifact storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         5 AS ORD,
         q'~generic artifact~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         6 AS ORD,
         q'~container engine~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         7 AS ORD,
         q'~virtual machine~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         8 AS ORD,
         q'~outbound data transfer~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         9 AS ORD,
         q'~drg~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         10 AS ORD,
         q'~ai agents~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         11 AS ORD,
         q'~identity~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         12 AS ORD,
         q'~idcs~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         13 AS ORD,
         q'~cache~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         14 AS ORD,
         q'~app monitoring~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         15 AS ORD,
         q'~block volume~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         16 AS ORD,
         q'~database ocpu~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         17 AS ORD,
         q'~x5~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         18 AS ORD,
         q'~network~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         19 AS ORD,
         q'~fastconnect~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         20 AS ORD,
         q'~api calls~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         21 AS ORD,
         q'~image storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         22 AS ORD,
         q'~custom image storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         23 AS ORD,
         q'~database backup storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         24 AS ORD,
         q'~dbaas~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         25 AS ORD,
         q'~adw~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         26 AS ORD,
         q'~ocpu~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         27 AS ORD,
         q'~networking~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         28 AS ORD,
         q'~gpt~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         29 AS ORD,
         q'~container~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         30 AS ORD,
         q'~database storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         31 AS ORD,
         q'~memory~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         32 AS ORD,
         q'~x7~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         33 AS ORD,
         q'~monitoring~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         34 AS ORD,
         q'~generative ai~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         35 AS ORD,
         q'~ai embedding~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         36 AS ORD,
         q'~rag~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         37 AS ORD,
         q'~disaster recovery~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         38 AS ORD,
         q'~identity cloud service~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         39 AS ORD,
         q'~oci cache~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         40 AS ORD,
         q'~file storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         41 AS ORD,
         q'~exadata~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         42 AS ORD,
         q'~lb~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         43 AS ORD,
         q'~logging analytics~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         44 AS ORD,
         q'~cohere~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         45 AS ORD,
         q'~meta~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         46 AS ORD,
         q'~apm~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         47 AS ORD,
         q'~block storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         48 AS ORD,
         q'~volume backup~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         49 AS ORD,
         q'~object storage~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         50 AS ORD,
         q'~oke~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         51 AS ORD,
         q'~kubernetes~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         52 AS ORD,
         q'~vm standard~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         53 AS ORD,
         q'~bm~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         54 AS ORD,
         q'~x9~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         55 AS ORD,
         q'~load balancer~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         56 AS ORD,
         q'~logging~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         57 AS ORD,
         q'~full stack disaster recovery~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         58 AS ORD,
         q'~dr protection~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         59 AS ORD,
         q'~desktops~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         60 AS ORD,
         q'~iam~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         61 AS ORD,
         q'~atp~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         62 AS ORD,
         q'~monitoring ingestion~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         63 AS ORD,
         q'~monitoring retrieval~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         64 AS ORD,
         q'~fsdr~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         65 AS ORD,
         q'~secure desktops~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         66 AS ORD,
         q'~volume performance~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         67 AS ORD,
         q'~container instance~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         68 AS ORD,
         q'~database~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         69 AS ORD,
         q'~autonomous~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         70 AS ORD,
         q'~compute~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         71 AS ORD,
         q'~bare metal~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         72 AS ORD,
         q'~data transfer~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         73 AS ORD,
         q'~flexible load balancer~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         74 AS ORD,
         q'~ai inference~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

MERGE INTO oci_focus_reports.CHATBOT_GLOSSARY_KEYWORDS t
USING (
  SELECT 6 AS RULE_ID,
         75 AS ORD,
         q'~virtual desktop~' AS KEYWORD
  FROM dual
) s
ON (t.RULE_ID = s.RULE_ID AND t.ORD = s.ORD)
WHEN MATCHED THEN UPDATE SET
  t.KEYWORD = s.KEYWORD
WHEN NOT MATCHED THEN INSERT (
  RULE_ID, ORD, KEYWORD
) VALUES (
  s.RULE_ID, s.ORD, s.KEYWORD
);

